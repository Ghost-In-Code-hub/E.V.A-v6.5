@echo off
rem ============================================================================================
rem  J.A.R.V.I.S - one-click launcher. Double-click this file.
rem  Starts the backend (if not already running), waits for /api/health, opens the Electron UI,
rem  and stops the backend again when the window is closed (only if this script started it).
rem  Usage:  run.bat            normal start
rem          run.bat rebuild    rebuild the frontend first
rem ============================================================================================
setlocal EnableExtensions
title J.A.R.V.I.S Launcher

set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"
cd /d "%ROOT%" || goto :err_cd

set "BACKEND=%ROOT%\backend"
set "FRONT=%ROOT%\frontend"
set "VENV=%ROOT%\.venv"
set "VPY=%VENV%\Scripts\python.exe"
set "DATA=%ROOT%\data"
set "PORT=8765"
if defined JARVIS_PORT set "PORT=%JARVIS_PORT%"
set "HEALTH=http://127.0.0.1:%PORT%/api/health"
set "STARTED_BACKEND=0"
set "PYTHONUTF8=1"
set "PYTHONUNBUFFERED=1"
set "ELECTRON_RUN_AS_NODE="

echo.
echo   J.A.R.V.I.S  -  starting from "%ROOT%"
echo.

if not exist "%DATA%" mkdir "%DATA%"
if not exist "%ROOT%\.env" if exist "%ROOT%\.env.example" copy /y "%ROOT%\.env.example" "%ROOT%\.env" >nul

rem ---------- 1. Python virtual environment ----------
if exist "%VPY%" goto :have_venv
set "PY="
call :try_py "py -3.12"
call :try_py "py -3.11"
call :try_py "py -3.10"
call :try_py "python"
if not defined PY goto :err_python
echo [setup] Creating Python virtual environment using: %PY%
%PY% -m venv "%VENV%"
if errorlevel 1 goto :err_venv
:have_venv

rem ---------- 2. Python dependencies (only when requirements.txt changed) ----------
fc /b "%BACKEND%\requirements.txt" "%VENV%\requirements.installed.txt" >nul 2>&1
if not errorlevel 1 goto :py_deps_ok
echo [setup] Installing backend dependencies (first run or requirements changed)...
"%VPY%" -m pip install --disable-pip-version-check -r "%BACKEND%\requirements.txt"
if errorlevel 1 goto :err_pip
copy /y "%BACKEND%\requirements.txt" "%VENV%\requirements.installed.txt" >nul
echo [setup] Optional features (voice, browser, vision) are installed by setup.bat.
:py_deps_ok

rem ---------- 3. Frontend: install / hand model / build when missing OR when the app version changed ----------
if /i "%~1"=="rebuild" if exist "%FRONT%\dist\VERSION" del /q "%FRONT%\dist\VERSION"
set "NEED_INSTALL=0"
set "NEED_BUILD=0"
if not exist "%FRONT%\node_modules\electron\dist\electron.exe" set "NEED_INSTALL=1"
fc /b "%FRONT%\package.json" "%FRONT%\node_modules\.package.installed.json" >nul 2>&1
if errorlevel 1 set "NEED_INSTALL=1"
fc /b "%ROOT%\VERSION" "%FRONT%\dist\VERSION" >nul 2>&1
if errorlevel 1 set "NEED_BUILD=1"
if "%NEED_INSTALL%"=="1" set "NEED_BUILD=1"
if "%NEED_BUILD%"=="0" goto :front_ok
where node >nul 2>&1
if errorlevel 1 goto :err_node
where npm >nul 2>&1
if errorlevel 1 goto :err_node
if "%NEED_INSTALL%"=="0" goto :front_model
echo [setup] Installing frontend dependencies ...
pushd "%FRONT%"
call npm install --no-audit --no-fund
if errorlevel 1 popd & goto :err_npm
popd
copy /y "%FRONT%\package.json" "%FRONT%\node_modules\.package.installed.json" >nul
:front_model
if exist "%FRONT%\public\models\hand_landmarker.task" goto :front_build
if not exist "%FRONT%\public\models" mkdir "%FRONT%\public\models"
echo [setup] Downloading the hand-tracking model (one time, about 8 MB) ...
curl.exe -L -f -s -S -o "%FRONT%\public\models\hand_landmarker.task" "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"
if errorlevel 1 echo [warn] Could not download the hand model - hand gestures stay off until it is available. & del /q "%FRONT%\public\models\hand_landmarker.task" >nul 2>&1
:front_build
echo [setup] Building the interface ...
pushd "%FRONT%"
call npm run build
if errorlevel 1 popd & goto :err_build
popd
:front_ok
where node >nul 2>&1
if errorlevel 1 goto :err_node
where npm >nul 2>&1
if errorlevel 1 goto :err_node
if exist "%FRONT%\node_modules\electron\dist\electron.exe" goto :front_build
echo [setup] Installing frontend dependencies (first run)...
pushd "%FRONT%"
call npm install --no-audit --no-fund
if errorlevel 1 popd & goto :err_npm
popd
:front_build
if exist "%FRONT%\dist\index.html" goto :front_ok
echo [setup] Building the interface...
pushd "%FRONT%"
call npm run build
if errorlevel 1 popd & goto :err_build
popd
:front_ok

rem ---------- 4. Backend: reuse a running Jarvis, refuse a foreign program on the port, else start ----------
curl.exe -s -m 2 "%HEALTH%" 2>nul | findstr /r /c:"service.*jarvis" >nul
if not errorlevel 1 goto :backend_reused
netstat -ano | findstr /r /c:":%PORT% .*LISTENING" >nul
if not errorlevel 1 goto :err_port

echo [start] Starting backend on 127.0.0.1:%PORT% ...
if exist "%DATA%\backend.pid" del /q "%DATA%\backend.pid" >nul 2>&1
set "JARVIS_ROOT=%ROOT%"
set "JARVIS_DATA=%DATA%"
set "JARVIS_PORT=%PORT%"
start "JARVIS Backend" /min /d "%BACKEND%" cmd /c ""%VPY%" -m app.run ^>^> "%DATA%\backend.log" 2^>^&1"
set "STARTED_BACKEND=1"

rem ---------- 5. Wait for readiness (up to ~60 s) ----------
for /l %%i in (1,1,60) do call :probe && goto :backend_ready
goto :err_backend

:backend_reused
echo [start] A Jarvis backend is already running on port %PORT% - reusing it.
:backend_ready
echo [start] Backend is healthy.

rem ---------- 6. Desktop window (blocks until the window is closed) ----------
set "JARVIS_ROOT=%ROOT%"
set "JARVIS_DATA=%DATA%"
set "JARVIS_PORT=%PORT%"
echo [start] Opening J.A.R.V.I.S ...
start "" /wait "%FRONT%\node_modules\electron\dist\electron.exe" "%FRONT%"

rem ---------- 7. Clean shutdown of what we started ----------
if "%STARTED_BACKEND%"=="0" goto :done
echo [stop] Stopping backend ...
set "TOK="
if exist "%DATA%\session_token" set /p TOK=<"%DATA%\session_token"
curl.exe -s -m 3 -X POST -H "X-Jarvis-Token: %TOK%" "http://127.0.0.1:%PORT%/api/shutdown" >nul 2>&1
for /l %%i in (1,1,8) do call :gone && goto :done
if exist "%DATA%\backend.pid" for /f "usebackq delims=" %%p in ("%DATA%\backend.pid") do taskkill /PID %%p /T /F >nul 2>&1
:done
endlocal
exit /b 0

rem ------------------------------------------------------------------------------------------
:try_py
if defined PY exit /b 0
%~1 -c "import sys; sys.exit(0 if (3,10) <= sys.version_info[:2] <= (3,12) else 1)" >nul 2>&1
if not errorlevel 1 set "PY=%~1"
exit /b 0

:probe
curl.exe -s -m 2 "%HEALTH%" 2>nul | findstr /r /c:"service.*jarvis" >nul
if not errorlevel 1 exit /b 0
timeout /t 1 /nobreak >nul
exit /b 1

:gone
curl.exe -s -m 1 "%HEALTH%" >nul 2>&1
if errorlevel 1 exit /b 0
timeout /t 1 /nobreak >nul
exit /b 1

rem ------------------------------------------------------------------------------------------
:err_cd
echo ERROR: cannot enter the project folder "%ROOT%".
goto :fail
:err_python
echo ERROR: Python 3.10, 3.11 or 3.12 was not found.
echo        Install Python 3.12 from https://www.python.org/downloads/ (tick "Add python.exe to PATH"), then run this file again.
echo        Newer versions (3.13+) are not supported yet because some optional packages have no wheels for them.
goto :fail
:err_venv
echo ERROR: could not create the virtual environment in "%VENV%".
goto :fail
:err_pip
echo ERROR: installing backend dependencies failed (see the messages above).
echo        Check your internet connection / proxy and run this file again.
goto :fail
:err_node
echo ERROR: Node.js (with npm) is required for the first run to install and build the interface.
echo        Install the LTS version from https://nodejs.org/ then run this file again.
goto :fail
:err_npm
echo ERROR: "npm install" failed (see the messages above).
goto :fail
:err_build
echo ERROR: building the interface failed (see the messages above).
goto :fail
:err_port
echo ERROR: port %PORT% is in use by another program that is not Jarvis.
echo        Close that program or set JARVIS_PORT to another number (for example: set JARVIS_PORT=8766) and run again.
goto :fail
:err_backend
echo ERROR: the backend did not become healthy within 60 seconds. Last lines of data\backend.log:
echo ------------------------------------------------------------
powershell -NoProfile -Command "if (Test-Path -LiteralPath '%DATA%\backend.log') { Get-Content -LiteralPath '%DATA%\backend.log' -Tail 25 }"
echo ------------------------------------------------------------
if exist "%DATA%\backend.pid" for /f "usebackq delims=" %%p in ("%DATA%\backend.pid") do taskkill /PID %%p /T /F >nul 2>&1
goto :fail
:fail
echo.
pause
endlocal
exit /b 1
