# J.A.R.V.I.S V6.5

A voice-first desktop assistant for Windows: Python/FastAPI backend, React + Three.js interface in Electron,
OpenRouter (one API key, no model id) plus optional OpenAI/Anthropic/Ollama, voice in/out, local clap wake, hand-gesture volume control,
and permission-gated browser/desktop/file/WhatsApp tools.

Reference art: `docs/assetsreferenceblue_jarvis_hud.png` (startup HUD) and `docs/assetsreferenceorange_energy_core.png` (energy core).

---------------------------------------------------------------------------------------------------

## 1. Honest status — read this first

This project was written and unit-tested in a **Linux sandbox without internet and without a display**.
So what is *verified* and what is *not* is spelled out below. Nothing here was run on real Windows hardware yet.

| Area | Implemented | Verified in the sandbox | Needs on your PC |
|---|---|---|---|
| State machine, event bus, settings, secret redaction, audit log | yes | **unit-tested** | – |
| Provider adapters (OpenAI / Anthropic / Ollama): message + tool conversion, SSE/NDJSON stream parsing, error mapping | yes | **unit-tested** against recorded-shape chunks | real API key to confirm live streaming |
| Orchestrator + tool loop, cancellation, confirmations, e-stop, error recovery | yes | **tested end-to-end with scripted fake providers** | – |
| Tool registry (permissions, arg validation, duplicate guard, timeouts), calculator, file sandbox, app launcher | yes | **unit-tested** (real subprocess launch tested) | Windows apps (Chrome, Notepad…) |
| Memory (SQLite), retention, redaction, disable | yes | **unit-tested** | – |
| Clap detector, VAD/utterance collector | yes | **tested with synthetic signals** (clap, speech-like, sustained noise, cooldown, noisy room, sensitivity) | **tune sensitivity with your mic/room** |
| Gesture engine + volume controller | yes | **tested with synthetic landmarks** (jitter, single-frame jump, re-arm, cooldown, sensitivity) | webcam + MediaPipe; pycaw for system volume |
| Voice pipeline wiring (clap → listen → STT → AI → TTS) | yes | **tested with fake STT/TTS** | real STT/TTS credentials + microphone |
| FastAPI app (auth token, origin check, body limit, WebSockets) | yes | tests written, **skipped** (FastAPI not installable offline) | run `pytest` after setup |
| Browser agent (Playwright), desktop agent (UI Automation), screenshots | yes | integration tests written, **skipped** | run them on Windows (below) |
| WhatsApp (Cloud API + WhatsApp Web) | yes | prepare/confirm/decline logic tested with mocks | credentials / a logged-in WhatsApp Web session; **WhatsApp Web selectors may need adjusting** |
| React/Three.js UI, startup HUD (transparent, full-screen), sharper orb, Dynamic Island (Framer Motion), settings | written | **not compiled, not rendered**; only plain-TS helpers and syntax were checked | `setup.bat` builds it; **visual polish needs your feedback** |
| Instant math ("3428*897", "write ten plus five", "15 percent of 200") | yes | **tested** (31 cases incl. word numbers, unsafe input, no-AI-call proof) | – |
| Hand gestures **inside the app** (MediaPipe Tasks WASM; no Python packages) + orb steering | yes | gesture logic **tested** (9 Node tests, same scenarios as the Python engine) | webcam + the 8 MB hand model (downloaded once by `run.bat`/`setup.bat`); **never run against a real camera** |
| Streamed speech (first sentence spoken while the model is still writing) | yes | **tested** (ordering, failure, cancel, audio-before-final-response) | real TTS + speakers |
| OpenRouter provider (auto model, latency routing, key test, STT) | yes | request building/parsing **unit-tested**; **never called live** | your OpenRouter key; if `openrouter/auto` is ever retired the app falls back to `openrouter/auto-beta` automatically |
| Electron shell (transparent frameless window, island overlay window), `run.bat`, `setup.bat` | written | syntax + static checks only; **never executed** | first run on Windows |

**Not implemented (by design, with reason)**
- **Spoken wake phrase** — it needs an on-device speech recogniser; none is bundled, and streaming your voice to a cloud service while idle would break the privacy rule. The UI shows this as unavailable. Wake = **clap detector** (opt-in) or the **TALK button**.
- **Resizing by dragging window edges** — Windows does not allow it for transparent windows; use maximise/restore (▢) or fullscreen instead.
- **Live partial transcription** — the bundled recogniser (Whisper-style API) is request/response. You see live *voice-activity* feedback, then the final transcript.
- Voice barge-in by *speaking* over Jarvis — echo makes this unreliable without a hardware echo canceller. Use STOP, `Esc`, **clap**, or `Ctrl+Alt+S`.

If a feature is unavailable on your machine, the app says exactly why in the boot log and in Settings. It never fakes a result.

---------------------------------------------------------------------------------------------------

## 2. Install (Windows 10/11)

Prerequisites: **Python 3.10–3.12** (3.12 recommended, tick *Add to PATH*), **Node.js LTS**, internet for the first run.
`curl.exe` ships with Windows 10 1803+.

1. Unzip the project anywhere (spaces in the path are fine).
2. Double-click **`setup.bat`** (recommended, once). It creates `.venv`, installs core + optional packages one by one
   (and lists any that failed), installs the frontend and builds it.
3. Double-click **`run.bat`**. It starts the backend, waits for `/api/health`, opens the window, and stops the backend when you close it.
4. On first start the app asks for your **OpenRouter API key** (get one at openrouter.ai/keys). Paste it, press *Save & Connect* — done. **No model id, no provider choice**: OpenRouter's `openrouter/auto` router picks a model per request (with `provider.sort=latency` for speed), and the same key does speech-to-text.

`run.bat` alone also works for the core app (it installs core dependencies when `requirements.txt` changes, and builds the UI if missing).
`run.bat rebuild` forces a UI rebuild. No administrator rights, no execution-policy changes.

### Configuration
The key is stored in `.env` (backend only, git-ignored): paste it in the app, or edit `.env` (see `.env.example`). The app never shows a saved key again.
Advanced users can still use other providers (`AI_PROVIDER=openai|anthropic|ollama` + `*_MODEL` in `.env`) or pin an OpenRouter model with `OPENROUTER_MODEL`; nothing in the UI asks for a model.
Non-secret settings live in `data/settings.json`.

Speech: **recognition** uses OpenRouter's `/audio/transcriptions` with your same key (the transcription model is discovered automatically).
**Output** can be `edge` (free neural voices incl. Urdu `ur-PK-*`, needs internet), `openai`, or `sapi` (offline Windows voices).
English, Urdu and Roman Urdu are supported to the extent the chosen services support them.

---------------------------------------------------------------------------------------------------

## 3. Using it

| Action | How |
|---|---|
| Talk | the mic starts automatically (MIC LIVE shown); press **TALK**, or **clap** (on by default; both configurable) |
| Type | bottom input bar (works with no microphone at all) |
| Stop | **STOP** button / `Esc` / say "stop" |
| Emergency stop | **E-STOP** or global `Ctrl+Alt+S` — cancels the task, denies pending approvals, blocks all tools until your next request |
| Volume by gesture | **On by default** (CAM LIVE shows while the camera is active). **Open palm moving up/down** = volume; **the orb follows your hand** (turns toward it, grows on an open palm, shrinks on a fist). Runs inside the app, so no Python/MediaPipe install is needed; the first run downloads an 8 MB model. Controls Windows volume (falls back to Jarvis' own volume if unavailable) |
| Maths | say or type `3428*897`, `3428 times 897`, `what is twelve plus five`, `write 10`, `15 percent of 200`: answered **instantly on your PC** (no AI call) in a big result card and spoken |
| Computer control | **On by default** (browser, desktop, files, WhatsApp) but gated: file access needs allowed folders, apps need the approved list, and consequential actions need your approval. Switch anything off in Settings → Computer control |
| Minimise | **—** hides the window and the **Dynamic Island** appears at the top-centre of the screen (always-on-top, only while minimised; toggle in Settings → Interface). Click the island to expand it; mic / stop / open buttons work |

The **Dynamic Island** (top-centre) shows real state: blue standby dot → orange listening waveform (live mic level) / thinking spinner / speaking bars (real audio amplitude) / computer-control actions such as "OPENING CHROME" / green "TASK COMPLETE" / red errors / stop indicator. It is never permanently expanded.

Indicators: **MIC LIVE**, **CAMERA LIVE** and **CONTROLLING PC** appear in the top bar whenever active.
Core colours: blue/cyan = standby; orange/gold = listening, processing, executing, speaking (pulse follows real audio level); red = interrupted/error.

### Safety model
- Tools come only from an explicit registry (no shell tool exists). Disabled capabilities are not even offered to the model.
- Consequential actions ask you first: writing/overwriting/deleting files, downloads, clicks on buttons such as Send/Submit/Buy/Delete/Pay, submitting forms, sending WhatsApp messages (recipient and text are shown). No answer within 120 s = denied. Optional "confirm every action".
- Ambiguous browser targets or WhatsApp contacts are errors, never guesses. Tool results carry verification evidence (page changed? field value matches? window found?) and the model is instructed not to claim success without it.
- Web pages, files and screenshots are wrapped/treated as untrusted data.
- Backend binds to `127.0.0.1` only (refuses other hosts unless `JARVIS_ALLOW_REMOTE=1`), per-launch session token on every API/WebSocket call, narrow CORS/origin check, 1 MB request limit.
- Secrets never reach the renderer, logs, audit trail or stored conversations (redaction + write-only endpoints). Raw audio and webcam frames are never stored. Microphone audio goes only to the local backend; it is sent to the STT provider only after a wake event and a finished utterance.
- Closing the UI turns the microphone off and denies pending approvals.

---------------------------------------------------------------------------------------------------

## 4. Layout

```
run.bat / setup.bat / .env.example / README.md
backend/app/
  core/       config, state machine, event bus, security (redaction, audit, path/URL rules)
  providers/  openai / anthropic / ollama adapters + gateway
  brain/      orchestrator (tool loop), context builder
  tools/      registry, calculator, app launcher, files, browser+desktop tools, whatsapp
  computer/   browser_agent (Playwright), desktop_agent (UI Automation), verification
  voice/      wake_detector (clap), voice_activity, session_manager, transcription, synthesis
  vision/     gesture_classifier, hand_tracker (MediaPipe), volume_controller (pycaw)
  memory/     SQLite conversation memory
  tasks/      task + confirmation managers
  services/   assistant_service (wires everything)   api/  routes + websockets   main.py, run.py
backend/tests/   183 tests; frontend/tests/ gesture tests
frontend/        Vite + React + TypeScript + React Three Fiber; electron/ main + preload
data/            created at runtime: settings, memory.db, audit.jsonl, session_token, backend.log (git-ignored)
```
Deviations from the suggested layout: stdlib `sqlite3` instead of SQLAlchemy (fewer dependencies, same behaviour); `unittest`-style tests (run by both `unittest` and `pytest`).

---------------------------------------------------------------------------------------------------

## 5. Tests

```
.venv\Scripts\python.exe -m pytest backend           (or: cd backend && ..\.venv\Scripts\python -m unittest discover -s tests -t .)
```
Sandbox result when written: **183 backend tests (169 passed, 14 skipped, 0 failed)** + **9 frontend gesture tests (9 passed)** via `cd frontend && npm test` (skips = tests needing FastAPI, Playwright, mss, pywinauto, uvicorn).
After `setup.bat` on Windows the skipped ones run too: API/WebSocket auth tests, real Chromium navigation/click/verify/screenshot against a local test page, real screen capture, and Notepad launch + window verification.
No real WhatsApp message is ever sent by tests; no API credits are used.

---------------------------------------------------------------------------------------------------

## 6. Troubleshooting

| Symptom | Fix |
|---|---|
| "Python 3.10, 3.11 or 3.12 was not found" | install Python 3.12, tick *Add to PATH*; 3.13+ lacks wheels for MediaPipe |
| "Node.js is required" | install Node LTS (first run only) |
| Window opens but boot log says BACKEND FAIL | open `data\backend.log`; port busy → `set JARVIS_PORT=8766` then `run.bat` |
| "port 8765 is in use by another program" | close it or change `JARVIS_PORT` |
| AI says "not configured" | paste your OpenRouter key (Settings → AI → *Test key*). No model needed |
| Island does not appear on minimise | Settings → Interface → "Dynamic Island when minimised"; it is shown only after the intro has finished |
| No speech output | Settings → Voice: provider status line shows why (edge-tts missing/offline, key missing) |
| Mic permission denied / not found | Windows Settings → Privacy → Microphone; pick the device in Settings → Voice |
| Clap never/always triggers | adjust sensitivity (higher = more sensitive); keep the mic off speakers; cooldown prevents repeats |
| Gestures unavailable | `setup.bat` must install `mediapipe` (Python ≤3.12); close other apps using the camera |
| System volume gesture does nothing | `pycaw` missing → use "Jarvis speech volume" or rerun `setup.bat` |
| Browser tools fail to launch | install Chrome/Edge, or choose *Bundled Chromium* and run `.venv\Scripts\python -m playwright install chromium` |
| `npm install` fails | check proxy/internet; rerun `setup.bat` |
| UI looks old after updating | `run.bat` rebuilds automatically when the `VERSION` file changes; or run `run.bat rebuild` |
| Gestures do nothing | needs internet once for the hand model (`frontend\public\models\hand_landmarker.task`); check Settings → Vision and that CAM LIVE is on |
| Black UI / low FPS | Settings → Interface → quality *Low* and lower particle density |
