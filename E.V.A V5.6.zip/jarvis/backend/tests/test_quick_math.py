import unittest
from app.brain.quick_math import quick_math as q, words_to_numbers as w
from tests.fakes import FakeProvider, collect, text, wait_for
from tests.test_service import make, states
from app.core.state import State


class TestQuickMath(unittest.TestCase):
    def test_user_example(self):
        for t in ("3428*897", "3428 * 897", "3428 x 897", "what is 3,428 times 897", "3428 multiplied by 897", "Jarvis, calculate 3428 \u00d7 897"):
            r = q(t); self.assertIsNotNone(r, t); self.assertEqual(r.value, 3074916, t); self.assertEqual(r.display, "3,074,916")
        self.assertEqual(q("3428*897").text, "3,428 \u00d7 897 = 3,074,916"); self.assertIn("times", q("3428*897").spoken)

    def test_write_a_number(self):
        for t, v in (("write 10", 10), ("type 42", 42), ("write ten", 10), ("Jarvis, write twenty five", 25)): self.assertEqual(q(t).value, v, t)
        self.assertIsNone(q("10")); self.assertIsNone(q("hello 10"))   # a bare number is NOT an instruction

    def test_operators_and_words(self):
        cases = {"2+2": 4, "10 - 3 + 2": 9, "100/8": 12.5, "what is twelve divided by 5": 2.4, "ten plus ten": 20, "2 to the power of 10": 1024, "7 squared": 49,
                 "fifteen percent of 200": 30, "(2+3)*4": 20, "1,000,000 / 8": 125000, "two thousand five hundred minus one hundred": 2400, "write twenty five plus seven": 32, "17 mod 5": 2}
        for t, v in cases.items(): self.assertAlmostEqual(q(t).value, v, msg=t)

    def test_not_math_goes_to_the_ai(self):
        for t in ("tell me a joke", "open chrome", "I have 3 apples", "how are you", "call mom at 5", "what is the weather like", "hi", "5 plus", "2 + 2 apples", "", "x" * 200,
                  "what is 5 plus", "search for 2024 election", "open chrome and search 10 things"):
            self.assertIsNone(q(t), t)

    def test_unsafe_and_edge_inputs(self):
        for t in ("__import__('os')", "2**9999999", "1/0", "9**9**9", "open('x')"): self.assertIsNone(q(t), t)

    def test_word_numbers(self):
        self.assertEqual(w("two thousand five hundred"), "2500"); self.assertEqual(w("three hundred and twenty one thousand"), "321000")
        self.assertEqual(w("twenty five times three"), "25 times 3")


class TestFastPath(unittest.IsolatedAsyncioTestCase):
    async def test_math_never_calls_the_ai_and_is_spoken(self):
        svc, prov = make([[text("SHOULD NOT BE USED")]]); ev = collect(svc.bus); await svc.start()
        await svc.handle_text("3428*897")
        self.assertTrue(await wait_for(lambda: svc.state.state == State.SPEAKING, 3))
        evs = ev(); self.assertEqual(prov.calls, [])
        c = [e for e in evs if e["type"] == "calc"][0]; self.assertEqual((c["expression"], c["value"]), ("3,428 \u00d7 897", "3,074,916"))
        self.assertEqual([e for e in evs if e["type"] == "response_final"][0]["text"], "3,428 \u00d7 897 = 3,074,916")
        self.assertTrue([e for e in evs if e["type"] == "audio" and e["data"]])
        await svc.speech_finished(); self.assertTrue(await wait_for(lambda: svc.state.state == State.STANDBY)); await svc.shutdown()

    async def test_conversation_context_keeps_math_turns(self):
        svc, prov = make([[text("Yes, that is 3 million.")]]); await svc.start()
        r = await svc.handle_text("3428*897"); await wait_for(lambda: svc.state.state == State.SPEAKING); await svc.speech_finished(); await wait_for(lambda: svc.state.state == State.STANDBY)
        await svc.handle_text("is that about three million?"); await wait_for(lambda: len(prov.calls) == 1)
        ctx = prov.calls[0]["messages"]; self.assertTrue(any("3,074,916" in (m.get("content") or "") for m in ctx)); await svc.shutdown()

if __name__ == "__main__":
    unittest.main()
