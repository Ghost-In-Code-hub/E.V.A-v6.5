"""Test doubles. No network, no API charges."""
from __future__ import annotations

import asyncio

from app.providers.base import Provider, ProviderError


class FakeProvider(Provider):
    """Scripted provider: each call to stream() consumes one script (list of events)."""
    name = "openai"

    def __init__(self, scripts, configured=True, delay=0.0):
        self.scripts, self._configured, self.delay, self.calls = list(scripts), configured, delay, []

    def configured(self):
        return (True, "") if self._configured else (False, "OPENAI_API_KEY is not set")

    async def stream(self, messages, tools, system, *, model, timeout):
        self.calls.append({"messages": [dict(m) for m in messages], "tools": [t["name"] for t in tools], "system": system})
        script = self.scripts.pop(0) if self.scripts else [{"type": "text", "text": "ok"}]
        for ev in script:
            if self.delay: await asyncio.sleep(self.delay)
            if isinstance(ev, Exception): raise ev
            yield ev
        yield {"type": "done"}

    async def list_models(self, timeout=15):
        if not self._configured: raise ProviderError("OPENAI_API_KEY is not set", "not_configured")
        return ["fake-model"]


class FakeSynth:
    name = "fake"
    def __init__(self, ok=True): self.ok = ok
    def configured(self): return (True, "") if self.ok else (False, "no tts")
    async def synth(self, text, language, voice="", **_): return b"FAKEAUDIO", "audio/mpeg"


class FakeTranscriber:
    name = "fake"
    def __init__(self, text="hello jarvis"): self.text = text
    def configured(self): return True, ""
    async def transcribe(self, wav, language="en", timeout=60): return self.text


def text(t): return {"type": "text", "text": t}
def call(name, args, id="c1"): return {"type": "tool_call", "id": id, "name": name, "arguments": args}


async def wait_for(pred, timeout=3.0):
    end = asyncio.get_event_loop().time() + timeout
    while asyncio.get_event_loop().time() < end:
        if pred(): return True
        await asyncio.sleep(0.01)
    return False


def collect(bus):
    q, out = bus.subscribe(), []
    def drain():
        while not q.empty(): out.append(q.get_nowait())
        return out
    return drain
