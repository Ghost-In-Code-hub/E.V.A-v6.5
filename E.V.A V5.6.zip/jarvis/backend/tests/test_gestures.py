import unittest
from app.vision.gesture_classifier import GestureEngine, GestureConfig, classify_pose


def hand(cx, cy, open_=True):
    lm = [(cx, cy)] * 21
    lm = list(lm)
    lm[0] = (cx, cy + 0.12)
    for base, dx in zip((5, 9, 13, 17), (-0.06, -0.02, 0.02, 0.06)):
        lm[base] = (cx + dx, cy + 0.02)
        lm[base + 1] = (cx + dx, cy - 0.03)      # pip
        lm[base + 3] = (cx + dx, cy - 0.14) if open_ else (cx + dx, cy + 0.03)  # tip
    return lm


def sweep(eng, y0, y1, secs, fps=30, start=0.0, x=0.5):
    out, n = [], int(secs * fps)
    for i in range(n + 1):
        t = start + i / fps
        r = eng.update(hand(x, y0 + (y1 - y0) * i / n), t)
        if r: out.append(r)
    return out, start + secs


class TestGestures(unittest.TestCase):
    def test_pose(self):
        self.assertEqual(classify_pose(hand(.5, .5, True)), "open_palm")
        self.assertEqual(classify_pose(hand(.5, .5, False)), "fist")
        self.assertEqual(classify_pose(None), "none")

    def test_up_and_down(self):
        e = GestureEngine(); r, _ = sweep(e, 0.7, 0.3, 0.6); self.assertEqual(r, ["up"])
        e = GestureEngine(); r, _ = sweep(e, 0.3, 0.7, 0.6); self.assertEqual(r, ["down"])

    def test_jitter_never_triggers(self):
        e = GestureEngine(); fired = []
        for i in range(300):
            fired.append(e.update(hand(0.5, 0.5 + (0.006 if i % 2 else -0.006)), i / 30))
        self.assertFalse(any(fired))

    def test_single_noisy_frame_does_not_trigger(self):
        e = GestureEngine()
        for i in range(10): e.update(hand(.5, .7), i / 30)
        self.assertIsNone(e.update(hand(.5, .2), 10 / 30))

    def test_fist_motion_ignored(self):
        e = GestureEngine(); r = []
        for i in range(30): r.append(e.update(hand(.5, .7 - i * 0.015, False), i / 30))
        self.assertFalse(any(r))

    def test_one_sweep_one_event_even_if_hand_keeps_moving(self):
        e = GestureEngine(); r, t = sweep(e, 0.8, 0.2, 1.2)
        self.assertEqual(r, ["up"])

    def test_requires_rearm_before_next_gesture(self):
        e = GestureEngine(); r, t = sweep(e, 0.7, 0.3, 0.5)
        self.assertEqual(r, ["up"])
        r2, t = sweep(e, 0.3, 0.7, 0.5, start=t + 0.05)       # immediate reverse, still disarmed/cooldown
        self.assertEqual(r2, [])
        for i in range(25): e.update(hand(.5, .7), t + 0.1 + i / 30)  # hold steady -> re-arm
        r3, _ = sweep(e, 0.7, 0.3, 0.5, start=t + 2.0)
        self.assertEqual(r3, ["up"])

    def test_hand_leaving_frame_rearms(self):
        e = GestureEngine(); sweep(e, 0.7, 0.3, 0.5)
        for i in range(30): e.update(None, 1.0 + i / 30)
        r, _ = sweep(e, 0.3, 0.7, 0.5, start=3.0)
        self.assertEqual(r, ["down"])

    def test_sensitivity(self):
        small = lambda s: sweep(GestureEngine(GestureConfig(sensitivity=s)), 0.55, 0.40, 0.5)[0]
        self.assertEqual(small(0.0), [])
        self.assertEqual(small(1.0), ["up"])

if __name__ == "__main__":
    unittest.main()
