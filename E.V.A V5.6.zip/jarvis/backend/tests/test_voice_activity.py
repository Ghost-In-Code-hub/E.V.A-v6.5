import unittest
import numpy as np
from app.voice.voice_activity import UtteranceCollector, pcm16_to_float, float_to_wav

SR = 16000
rng = np.random.default_rng(3)
quiet = lambda s: (rng.standard_normal(int(SR * s)) * 0.002).astype(np.float32)
voice = lambda s: (0.2 * np.sin(2 * np.pi * 180 * np.arange(int(SR * s)) / SR) + rng.standard_normal(int(SR * s)) * 0.01).astype(np.float32)


def feed_all(c, x):
    for i in range(0, len(x), 480):
        st = c.feed(x[i:i + 480])
        if st != "collecting": return st
    return c.status


class TestUtterance(unittest.TestCase):
    def test_ends_after_silence_timeout(self):
        c = UtteranceCollector(silence_s=1.0)
        self.assertEqual(feed_all(c, np.concatenate([quiet(0.3), voice(1.0), quiet(1.5)])), "done")
        self.assertGreater(len(c.audio()), SR)

    def test_no_speech_times_out(self):
        self.assertEqual(feed_all(UtteranceCollector(no_speech_s=2.0), quiet(4)), "no_speech")

    def test_short_pause_does_not_end(self):
        c = UtteranceCollector(silence_s=1.4)
        self.assertEqual(feed_all(c, np.concatenate([voice(0.5), quiet(0.6), voice(0.5)])), "collecting")

    def test_max_length(self):
        self.assertEqual(feed_all(UtteranceCollector(max_s=2.0), voice(5)), "done")

    def test_pcm_and_wav(self):
        x = np.array([0, 16384, -16384], dtype="<i2")
        f = pcm16_to_float(x.tobytes())
        self.assertAlmostEqual(float(f[1]), 0.5, places=3)
        self.assertTrue(float_to_wav(f).startswith(b"RIFF"))

if __name__ == "__main__":
    unittest.main()
