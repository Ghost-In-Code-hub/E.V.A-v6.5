import asyncio, json, os, tempfile, unittest
from pathlib import Path
from app.core import config as cfg
from app.core.events import EventBus
from app.core.security import AuditLog, path_allowed, redact, redact_obj, url_allowed
from app.core.state import InvalidTransition, State, StateMachine


class TestState(unittest.IsolatedAsyncioTestCase):
    async def test_happy_path_cycle(self):
        sm = StateMachine(); seen = []
        sm.subscribe(lambda o, n, d: seen.append(n.value))
        for s in (State.STANDBY, State.LISTENING, State.PROCESSING, State.EXECUTING, State.PROCESSING, State.SPEAKING, State.STANDBY):
            self.assertTrue(await sm.set(s))
        self.assertEqual(seen, ["STANDBY", "LISTENING", "PROCESSING", "EXECUTING", "PROCESSING", "SPEAKING", "STANDBY"])

    async def test_illegal_transition_rejected(self):
        sm = StateMachine(); await sm.set(State.STANDBY)
        self.assertFalse(await sm.set(State.SPEAKING))
        self.assertEqual(sm.state, State.STANDBY)
        with self.assertRaises(InvalidTransition): await sm.set(State.EXECUTING, strict=True)

    async def test_error_recoverable(self):
        sm = StateMachine(); await sm.set(State.STANDBY); await sm.set(State.PROCESSING); await sm.set(State.ERROR)
        self.assertTrue(await sm.set(State.STANDBY))

    async def test_every_state_has_exit(self):
        from app.core.state import ALLOWED
        for s, outs in ALLOWED.items(): self.assertTrue(outs, s)

    async def test_interrupt_from_speaking(self):
        sm = StateMachine(); await sm.set(State.STANDBY); await sm.set(State.PROCESSING); await sm.set(State.SPEAKING)
        self.assertTrue(await sm.set(State.INTERRUPTED)); self.assertTrue(await sm.set(State.LISTENING))


class TestEvents(unittest.IsolatedAsyncioTestCase):
    async def test_unknown_event_rejected(self):
        with self.assertRaises(ValueError): EventBus().make("nonsense")

    async def test_slow_consumer_does_not_block(self):
        bus = EventBus(maxsize=3); q = bus.subscribe()
        for i in range(10): await bus.emit("log", message=str(i))
        self.assertEqual(q.qsize(), 3)
        self.assertEqual((await q.get())["message"], "7")


class TestConfig(unittest.TestCase):
    def setUp(self):
        self.d = Path(tempfile.mkdtemp())

    def test_defaults_valid(self):
        self.assertEqual(cfg.validate_settings(cfg.deep_merge(cfg.DEFAULTS, {})), [])

    def test_validation_messages(self):
        s = cfg.SettingsStore(self.d / "s.json")
        errs = s.update({"voice": {"clap": {"sensitivity": 3}}, "ai": {"provider": "bogus"}})
        self.assertTrue(any("clap.sensitivity" in e for e in errs)); self.assertTrue(any("ai.provider" in e for e in errs))
        self.assertEqual(s["ai"]["provider"], "openrouter")  # unchanged on error

    def test_persistence(self):
        p = self.d / "s.json"
        s = cfg.SettingsStore(p); self.assertEqual(s.update({"interface": {"quality": "low"}}), [])
        self.assertEqual(cfg.SettingsStore(p)["interface"]["quality"], "low")

    def test_app_map_edit_can_remove_entries(self):
        s = cfg.SettingsStore(self.d / "s.json")
        s.update({"computer": {"apps": {"a": "x", "b": "y"}}}); s.update({"computer": {"apps": {"a": "x"}}})
        self.assertEqual(s["computer"]["apps"], {"a": "x"})

    def test_env_roundtrip_and_no_newline_injection(self):
        p = self.d / ".env"; p.write_text("# c\nAI_PROVIDER=openai\nOPENAI_API_KEY=\n")
        cfg.write_env_values({"OPENAI_API_KEY": "sk-test-1234567890abcdef"}, p)
        self.assertEqual(cfg.parse_env(p.read_text())["OPENAI_API_KEY"], "sk-test-1234567890abcdef")
        self.assertIn("AI_PROVIDER=openai", p.read_text())
        with self.assertRaises(ValueError): cfg.write_env_values({"X": "a\nEVIL=1"}, p)
        with self.assertRaises(ValueError): cfg.write_env_values({"bad key": "1"}, p)
        os.environ.pop("OPENAI_API_KEY", None)

    def test_secret_status_is_boolean_only(self):
        os.environ["OPENAI_API_KEY"] = "sk-secret-value-123456"
        try:
            st = cfg.secret_status()
            self.assertIs(st["OPENAI_API_KEY"], True)
            self.assertNotIn("sk-secret", json.dumps(st))
        finally: os.environ.pop("OPENAI_API_KEY")

    def test_env_comment_parsing(self):
        self.assertEqual(cfg.parse_env("AI_PROVIDER=openai          # openai | anthropic")["AI_PROVIDER"], "openai")


class TestSecurity(unittest.TestCase):
    def test_redaction(self):
        for s in ("key sk-ant-api03-abcdefghijklmnop", "sk-proj-abcdefghijklmnopqrstuv", "Authorization: Bearer abcdefghijklmnopqrstuvwxyz", 'api_key="hunter2hunter2"'):
            self.assertIn("[REDACTED]", redact(s)); self.assertNotIn("abcdefghijkl", redact(s)); self.assertNotIn("hunter2", redact(s))

    def test_redacts_known_env_secret(self):
        os.environ["ANTHROPIC_API_KEY"] = "custom-format-secret-9999"
        try: self.assertNotIn("custom-format", redact("oops custom-format-secret-9999 leaked"))
        finally: os.environ.pop("ANTHROPIC_API_KEY")

    def test_redact_obj_keys(self):
        self.assertEqual(redact_obj({"api_key": "abc", "ok": "fine"}), {"api_key": "[REDACTED]", "ok": "fine"})

    def test_path_allowlist(self):
        d = Path(tempfile.mkdtemp()); (d / "a.txt").write_text("x")
        self.assertIsNotNone(path_allowed(d / "a.txt", [str(d)]))
        self.assertIsNone(path_allowed(d / ".." / "etc" / "passwd", [str(d)]))
        self.assertIsNone(path_allowed("/etc/passwd", [str(d)]))
        self.assertIsNone(path_allowed(d / "a.txt", []))

    def test_symlink_escape_blocked(self):
        d = Path(tempfile.mkdtemp()); out = Path(tempfile.mkdtemp()); (out / "secret.txt").write_text("s")
        try: os.symlink(out, d / "link")
        except OSError: self.skipTest("symlinks unavailable")
        self.assertIsNone(path_allowed(d / "link" / "secret.txt", [str(d)]))

    def test_url_rules(self):
        self.assertTrue(url_allowed("https://example.com/x")[0])
        for bad in ("file:///C:/x", "javascript:alert(1)", "data:text/html,hi", "chrome://settings", "http://"):
            self.assertFalse(url_allowed(bad)[0], bad)
        self.assertFalse(url_allowed("https://evil.com", ["example.com"])[0])
        self.assertTrue(url_allowed("https://docs.example.com", ["example.com"])[0])

    def test_audit_never_stores_images_or_secrets(self):
        a = AuditLog(Path(tempfile.mkdtemp()) / "a.jsonl")
        a.write("t", image_b64="AAAA", token="abc12345", note="Bearer abcdefghijklmnopqrstu")
        line = a.path.read_text()
        self.assertNotIn("AAAA", line); self.assertNotIn("abc12345", line); self.assertNotIn("abcdefghijklmnopqrstu", line)

    def test_audit_retention(self):
        a = AuditLog(Path(tempfile.mkdtemp()) / "a.jsonl")
        a.path.write_text(json.dumps({"ts": "2000-01-01T00:00:00", "kind": "old"}) + "\n")
        a.write("new")
        self.assertEqual(a.purge_older_than(30), 1)
        self.assertEqual(len(a.path.read_text().splitlines()), 1)

if __name__ == "__main__":
    unittest.main()
