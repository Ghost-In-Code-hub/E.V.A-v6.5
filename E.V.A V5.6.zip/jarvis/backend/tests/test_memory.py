import tempfile, time, unittest
from pathlib import Path
from app.memory.database import Memory


class TestMemory(unittest.TestCase):
    def setUp(self): self.m = Memory(Path(tempfile.mkdtemp()) / "m.db")

    def test_roundtrip_and_title(self):
        c = self.m.create_conversation()
        self.m.add_message(c, "user", "What is the weather in Lahore?"); self.m.add_message(c, "assistant", "Sunny.")
        self.assertEqual([x["role"] for x in self.m.messages(c)], ["user", "assistant"])
        self.assertTrue(self.m.list_conversations()[0]["title"].startswith("What is the weather"))

    def test_tool_calls_persist(self):
        c = self.m.create_conversation()
        self.m.add_message(c, "user", "2+2")
        self.m.add_message(c, "assistant", "", tool_calls=[{"id": "1", "name": "calculator", "arguments": {"expression": "2+2"}}])
        self.m.add_message(c, "tool", "2+2 = 4", tool_call_id="1", name="calculator")
        msgs = self.m.messages(c)
        self.assertEqual(msgs[1]["tool_calls"][0]["name"], "calculator"); self.assertEqual(msgs[2]["tool_call_id"], "1")

    def test_window_never_starts_with_orphan_tool_result(self):
        c = self.m.create_conversation()
        self.m.add_message(c, "assistant", "", tool_calls=[{"id": "1", "name": "x", "arguments": {}}])
        self.m.add_message(c, "tool", "r", tool_call_id="1", name="x"); self.m.add_message(c, "assistant", "done")
        self.assertNotEqual(self.m.messages(c, limit=2)[0]["role"], "tool")

    def test_secrets_not_stored(self):
        c = self.m.create_conversation(); self.m.add_message(c, "user", "my key is sk-abcdefghijklmnopqrstuv")
        self.assertNotIn("sk-abcdef", self.m.messages(c)[0]["content"])

    def test_disabled_memory_stores_nothing(self):
        self.m.configure(False, 30); c = self.m.create_conversation()
        self.m.add_message(c, "user", "hi"); self.assertEqual(self.m.messages(c), [])
        self.assertFalse(self.m.set_preference("a", "b"))

    def test_delete(self):
        c = self.m.create_conversation(); self.m.add_message(c, "user", "hi")
        self.assertTrue(self.m.delete_conversation(c)); self.assertEqual(self.m.messages(c), []); self.assertFalse(self.m.delete_conversation(c))

    def test_retention(self):
        c = self.m.create_conversation(); self.m.add_message(c, "user", "old")
        self.m._db.execute("UPDATE conversations SET updated=?", (time.time() - 40 * 86400,)); self.m._db.commit()
        self.assertEqual(self.m.purge_expired(), 1)

    def test_preferences_and_search(self):
        self.m.set_preference("language", "Urdu"); self.assertEqual(self.m.preferences(), {"language": "Urdu"})
        c = self.m.create_conversation(); self.m.add_message(c, "user", "remember the project codename is Falcon")
        self.assertEqual(len(self.m.search("Falcon")), 1); self.assertEqual(self.m.search("zzz"), [])

if __name__ == "__main__":
    unittest.main()
