"""Static checks of run.bat / setup.bat (we cannot execute cmd.exe off-Windows, so these verify structure,
quoting for paths with spaces, absence of risky commands and label integrity)."""
import importlib.util, os, re, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
FILES = {n: (ROOT / n).read_bytes().decode("utf-8") for n in ("run.bat", "setup.bat")}
PATH_VARS = ("ROOT", "BACKEND", "FRONT", "VENV", "VPY", "DATA")


def lines(name): return FILES[name].split("\r\n")


class TestLaunchers(unittest.TestCase):
    def test_crlf_line_endings(self):
        for n, t in FILES.items():
            self.assertNotRegex(t.replace("\r\n", ""), r"[\r\n]", n)  # no bare CR or LF

    def test_root_from_script_dir_and_cd(self):
        for n in FILES: self.assertIn('set "ROOT=%~dp0"', FILES[n]); self.assertIn('cd /d "%ROOT%"', FILES[n])

    def test_every_path_variable_use_is_quoted(self):
        for n in FILES:
            for i, l in enumerate(lines(n), 1):
                s = l.strip()
                if s.lower().startswith(("rem", "echo", "set ", "::")) or not s: continue
                l = l.replace('cmd /c ""', 'cmd /c "')   # idiom: cmd /c ""path" args" -> outer wrapper quote + quoted path
                for m in re.finditer(r"%(" + "|".join(PATH_VARS) + r")%", l):
                    self.assertEqual(l[:m.start()].count('"') % 2, 1, f"{n}:{i} unquoted %{m.group(1)}%: {l.strip()}")

    def test_no_risky_system_changes(self):
        for n, t in FILES.items():
            for bad in ("Set-ExecutionPolicy", "RunAs", "reg add", "netsh", "-ExecutionPolicy", "bypass", "defender", "/f /v"):
                self.assertNotIn(bad.lower(), t.lower(), f"{n} contains {bad}")

    def test_goto_targets_exist(self):
        for n, t in FILES.items():
            labels = set(re.findall(r"^:(\w+)", t, re.M)); labels.add("eof")
            for g in re.findall(r"goto\s+:(\w+)", t, re.I): self.assertIn(g, labels, f"{n}: goto :{g}")
            for c in re.findall(r"call\s+:(\w+)", t, re.I): self.assertIn(c, labels, f"{n}: call :{c}")

    def test_run_bat_flow(self):
        t = FILES["run.bat"]
        for needle in ("-m venv", "requirements.installed.txt", "curl.exe", "/api/health", "app.run", "electron.exe", "/api/shutdown", "taskkill", "backend.pid", "STARTED_BACKEND"):
            self.assertIn(needle, t)
        self.assertRegex(t, r"(?i)3,10\) <= sys.version_info\[:2\] <= \(3,12")  # version gate
        self.assertNotIn("EnableDelayedExpansion", t)                          # paths containing '!' stay safe

    def test_pip_install_is_conditional_on_changed_requirements(self):
        t = FILES["run.bat"]; i = t.index("pip install"); self.assertIn("fc /b", t[:i]); self.assertIn("goto :py_deps_ok", t[:i])

    def test_rebuilds_ui_when_version_or_dependencies_change_and_fetches_hand_model(self):
        r = FILES["run.bat"]
        for needle in ("VERSION", "package.installed.json", "NEED_BUILD", "hand_landmarker.task", "storage.googleapis.com/mediapipe-models"): self.assertIn(needle, r)
        self.assertLess(r.index("hand_landmarker.task"), r.index("npm run build"))      # model must exist BEFORE vite copies public/ into dist
        self.assertIn("hand_landmarker.task", FILES["setup.bat"]); self.assertTrue((ROOT / "VERSION").read_text().strip())

    def test_only_stops_backend_it_started(self):
        t = FILES["run.bat"]; self.assertIn('if "%STARTED_BACKEND%"=="0" goto :done', t)

    def test_no_duplicate_backend_when_running(self):
        t = FILES["run.bat"]; self.assertLess(t.index("goto :backend_reused"), t.index('start "JARVIS Backend"'))

    def test_foreign_port_use_detected(self):
        self.assertIn("err_port", FILES["run.bat"])

    def test_backend_refuses_non_loopback_host(self):
        if importlib.util.find_spec("uvicorn") is None or importlib.util.find_spec("fastapi") is None: self.skipTest("uvicorn/fastapi not installed")
        os.environ["JARVIS_HOST"] = "0.0.0.0"
        try:
            from app import run
            self.assertEqual(run.main(), 2)
        finally: os.environ.pop("JARVIS_HOST")

    def test_setup_installs_extras_individually(self):
        t = FILES["setup.bat"]; self.assertIn("requirements-extras.txt", t); self.assertIn(":extra", t); self.assertIn("setup_failures.txt", t)

    def test_extras_have_no_env_markers_and_core_numpy_pinned_for_mediapipe(self):
        ex = (ROOT / "backend" / "requirements-extras.txt").read_text()
        for l in ex.splitlines():
            if l.strip() and not l.startswith("#"): self.assertNotIn(";", l)
        self.assertIn("numpy>=1.26,<2", (ROOT / "backend" / "requirements.txt").read_text())

    def test_gitignore_protects_secrets(self):
        g = (ROOT / ".gitignore").read_text(); self.assertIn(".env", g.splitlines()); self.assertIn("data/", g)
        self.assertEqual([l for l in (ROOT / ".env.example").read_text().splitlines() if re.match(r"\w+_(KEY|TOKEN)=\S", l)], [])

    def test_no_secrets_or_storage_of_keys_in_frontend_source(self):
        for f in (ROOT / "frontend" / "src").rglob("*.ts*"):
            t = f.read_text()
            self.assertNotRegex(t, r"sk-[A-Za-z0-9]{12,}", str(f)); self.assertNotIn("localStorage", t, str(f))

if __name__ == "__main__":
    unittest.main()
