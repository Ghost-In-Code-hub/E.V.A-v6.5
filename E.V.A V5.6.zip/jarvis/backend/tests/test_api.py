"""HTTP/WebSocket API tests. Require fastapi+httpx (installed by setup.bat); skipped otherwise."""
import importlib.util, json, tempfile, unittest
from pathlib import Path

HAVE = importlib.util.find_spec("fastapi") is not None and importlib.util.find_spec("httpx") is not None


@unittest.skipUnless(HAVE, "fastapi/httpx not installed in this environment")
class TestAPI(unittest.TestCase):
    def setUp(self):
        from fastapi.testclient import TestClient
        from app.main import create_app
        from app.services.assistant_service import AssistantService
        from tests.fakes import FakeProvider, FakeSynth, FakeTranscriber, text
        d = Path(tempfile.mkdtemp())
        svc = AssistantService(d, providers={"openai": FakeProvider([[text("pong")]])}, synth_factory=lambda n: FakeSynth(), transcriber_factory=lambda n: FakeTranscriber())
        svc.settings.data["ai"]["models"]["openai"] = "m"
        self.app = create_app(svc, token="T" * 20, port=8765)
        self.c = TestClient(self.app); self.c.__enter__()
        self.h = {"X-Jarvis-Token": "T" * 20}

    def tearDown(self): self.c.__exit__(None, None, None)

    def test_health_public_and_minimal(self):
        r = self.c.get("/api/health"); self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()["service"], "jarvis"); self.assertNotIn("settings", r.json())

    def test_token_required(self):
        self.assertEqual(self.c.get("/api/status").status_code, 401)
        self.assertEqual(self.c.get("/api/status", headers={"X-Jarvis-Token": "wrong"}).status_code, 401)
        self.assertEqual(self.c.get("/api/status", headers={"X-Jarvis-Token": "ünï"}).status_code, 401)
        self.assertEqual(self.c.get("/api/status", headers=self.h).status_code, 200)

    def test_foreign_origin_blocked(self):
        r = self.c.get("/api/status", headers={**self.h, "Origin": "http://evil.example"}); self.assertEqual(r.status_code, 403)

    def test_oversized_body(self):
        r = self.c.post("/api/chat", headers={**self.h, "Content-Length": "2000000"}, content=b"x"); self.assertEqual(r.status_code, 413)

    def test_chat_validation(self):
        self.assertEqual(self.c.post("/api/chat", headers=self.h, json={"text": ""}).status_code, 422)
        self.assertEqual(self.c.post("/api/chat", headers=self.h, json={"text": "x" * 5000}).status_code, 422)
        r = self.c.post("/api/chat", headers=self.h, json={"text": "ping"}); self.assertEqual(r.status_code, 200); self.assertIn("conversation_id", r.json())

    def test_secrets_are_write_only(self):
        r = self.c.put("/api/secrets", headers=self.h, json={"OPENAI_API_KEY": "sk-test-apitest-123456789"})
        self.assertEqual(r.json(), {"secrets": {"OPENAI_API_KEY": True, "ANTHROPIC_API_KEY": False, "WHATSAPP_TOKEN": False}})
        for path in ("/api/status", "/api/settings"):
            self.assertNotIn("sk-test-apitest", self.c.get(path, headers=self.h).text)
        self.c.put("/api/secrets", headers=self.h, json={"OPENAI_API_KEY": ""})
        self.assertEqual(self.c.put("/api/secrets", headers=self.h, json={"OLLAMA_BASE_URL": "file:///x"}).status_code, 422)

    def test_settings_validation_422(self):
        self.assertEqual(self.c.put("/api/settings", headers=self.h, json={"patch": {"voice": {"clap": {"sensitivity": 5}}}}).status_code, 422)
        self.assertEqual(self.c.put("/api/settings", headers=self.h, json={"patch": {"interface": {"quality": "low"}}}).status_code, 200)

    def test_ws_requires_token_and_streams_state(self):
        from starlette.websockets import WebSocketDisconnect
        with self.assertRaises(WebSocketDisconnect):
            with self.c.websocket_connect("/ws?token=bad"): pass
        with self.c.websocket_connect("/ws?token=" + "T" * 20) as ws:
            types = [ws.receive_json()["type"] for _ in range(3)]
            self.assertEqual(types, ["connection", "state", "capabilities"])
            ws.send_json({"type": "chat", "text": "ping"})
            seen = set()
            for _ in range(30):
                seen.add(ws.receive_json()["type"])
                if "response_final" in seen: break
            self.assertIn("response_final", seen)
            ws.send_json({"type": "nonsense"}); self.assertEqual(ws.receive_json()["type"], "error")

    def test_ws_disconnect_turns_mic_off(self):
        with self.c.websocket_connect("/ws?token=" + "T" * 20) as ws:
            [ws.receive_json() for _ in range(3)]; ws.send_json({"type": "mic", "enabled": True})
            while ws.receive_json()["type"] != "mic": pass
        self.assertFalse(self.app.state.service.voice.mic_enabled)

    def test_unknown_conversation_and_confirmation(self):
        self.assertEqual(self.c.post("/api/confirmations/nope", headers=self.h, json={"approved": True}).status_code, 404)

if __name__ == "__main__":
    unittest.main()
