import os, sys, tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("JARVIS_DATA", tempfile.mkdtemp(prefix="jarvis_test_"))
