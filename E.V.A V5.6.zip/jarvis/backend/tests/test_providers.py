import json, os, tempfile, unittest
from pathlib import Path
from app.core import config as cfg
from app.providers.anthropic_provider import AnthropicStreamParser, to_anthropic_messages, to_anthropic_tools
from app.providers.base import ProviderError, http_error, parse_args
from app.providers.gateway import ProviderGateway
from app.providers.ollama_provider import to_ollama_messages
from app.providers.openai_provider import OpenAIProvider, OpenAIStreamParser, to_openai_messages, to_openai_tools

HIST = [
    {"role": "user", "content": "What is 2+2?"},
    {"role": "assistant", "content": "", "tool_calls": [{"id": "c1", "name": "calculator", "arguments": {"expression": "2+2"}}]},
    {"role": "tool", "tool_call_id": "c1", "name": "calculator", "content": "2+2 = 4"},
    {"role": "user", "content": "[screenshot]", "images": ["QUJD"]},
]


class TestOpenAI(unittest.TestCase):
    def test_message_conversion(self):
        m = to_openai_messages(HIST, "sys")
        self.assertEqual(m[0], {"role": "system", "content": "sys"})
        self.assertEqual(m[2]["tool_calls"][0]["function"]["arguments"], '{"expression": "2+2"}')
        self.assertEqual(m[3], {"role": "tool", "tool_call_id": "c1", "content": "2+2 = 4"})
        self.assertEqual(m[4]["content"][1]["image_url"]["url"], "data:image/png;base64,QUJD")

    def test_tools(self):
        t = to_openai_tools([{"name": "a", "description": "d", "parameters": {"type": "object"}}])
        self.assertEqual(t[0]["type"], "function"); self.assertEqual(t[0]["function"]["name"], "a")

    def test_stream_text_tool_usage(self):
        p, evs = OpenAIStreamParser(), []
        chunks = [{"choices": [{"delta": {"content": "Hel"}}]}, {"choices": [{"delta": {"content": "lo"}}]},
                  {"choices": [{"delta": {"tool_calls": [{"index": 0, "id": "call_1", "function": {"name": "calculator", "arguments": '{"expres'}}]}}]},
                  {"choices": [{"delta": {"tool_calls": [{"index": 0, "function": {"arguments": 'sion":"1+1"}'}}]}}]},
                  {"choices": [], "usage": {"prompt_tokens": 10, "completion_tokens": 5}}]
        for c in chunks: evs += p.feed(c)
        evs += p.finish()
        self.assertEqual("".join(e["text"] for e in evs if e["type"] == "text"), "Hello")
        tc = [e for e in evs if e["type"] == "tool_call"][0]
        self.assertEqual((tc["id"], tc["name"], tc["arguments"]), ("call_1", "calculator", {"expression": "1+1"}))
        self.assertEqual([e for e in evs if e["type"] == "usage"][0]["output_tokens"], 5)

    def test_parallel_tool_calls_ordered(self):
        p = OpenAIStreamParser()
        p.feed({"choices": [{"delta": {"tool_calls": [{"index": 1, "id": "b", "function": {"name": "y", "arguments": "{}"}}, {"index": 0, "id": "a", "function": {"name": "x", "arguments": "{}"}}]}}]})
        self.assertEqual([e["name"] for e in p.finish()], ["x", "y"])

    def test_malformed_args_do_not_crash(self):
        self.assertIn("_parse_error", parse_args("{broken"))


class TestAnthropic(unittest.TestCase):
    def test_conversion_merges_tool_result_and_image(self):
        m = to_anthropic_messages(HIST)
        self.assertEqual([x["role"] for x in m], ["user", "assistant", "user"])
        self.assertEqual(m[1]["content"][0]["type"], "tool_use")
        self.assertEqual(m[2]["content"][0]["type"], "tool_result")  # tool_result must come first
        self.assertEqual(m[2]["content"][1]["type"], "image")
        self.assertEqual(to_anthropic_tools([{"name": "a", "description": "d", "parameters": {"x": 1}}])[0]["input_schema"], {"x": 1})

    def test_stream(self):
        p, evs = AnthropicStreamParser(), []
        seq = [("message_start", {"type": "message_start", "message": {"usage": {"input_tokens": 12}}}),
               ("content_block_start", {"type": "content_block_start", "index": 0, "content_block": {"type": "text"}}),
               ("content_block_delta", {"type": "content_block_delta", "index": 0, "delta": {"type": "text_delta", "text": "Hi"}}),
               ("content_block_start", {"type": "content_block_start", "index": 1, "content_block": {"type": "tool_use", "id": "tu1", "name": "calculator"}}),
               ("content_block_delta", {"type": "content_block_delta", "index": 1, "delta": {"type": "input_json_delta", "partial_json": '{"expression"'}}),
               ("content_block_delta", {"type": "content_block_delta", "index": 1, "delta": {"type": "input_json_delta", "partial_json": ': "3*3"}'}}),
               ("content_block_stop", {"type": "content_block_stop", "index": 1}),
               ("message_delta", {"type": "message_delta", "usage": {"output_tokens": 9}})]
        for e, d in seq: evs += p.feed(e, d)
        self.assertEqual(evs[0], {"type": "text", "text": "Hi"})
        self.assertEqual(evs[1]["arguments"], {"expression": "3*3"})
        self.assertEqual(evs[2], {"type": "usage", "input_tokens": 12, "output_tokens": 9})

    def test_error_event(self):
        with self.assertRaises(ProviderError): AnthropicStreamParser().feed("error", {"type": "error", "error": {"message": "overloaded"}})


class TestOllama(unittest.TestCase):
    def test_conversion(self):
        m = to_ollama_messages(HIST, "sys")
        self.assertEqual(m[2]["tool_calls"][0]["function"]["arguments"], {"expression": "2+2"})
        self.assertEqual(m[3]["role"], "tool"); self.assertEqual(m[4]["images"], ["QUJD"])


class TestErrorsAndGateway(unittest.IsolatedAsyncioTestCase):
    def test_http_error_kinds(self):
        for code, kind in ((401, "auth"), (403, "auth"), (429, "rate_limit"), (400, "bad_request"), (503, "server")):
            self.assertEqual(http_error(code, "x").kind, kind)

    async def test_missing_credentials_clear_message(self):
        os.environ.pop("OPENAI_API_KEY", None)
        st = cfg.SettingsStore(Path(tempfile.mkdtemp()) / "s.json"); st.data["ai"]["provider"] = "openai"
        g = ProviderGateway(st)
        ok, why = g.ready(); self.assertFalse(ok); self.assertIn("OPENAI_API_KEY", why)
        with self.assertRaises(ProviderError) as cm:
            async for _ in g.stream([], [], ""): pass
        self.assertEqual(cm.exception.kind, "not_configured")
        t = await g.test("openai"); self.assertFalse(t["ok"]); self.assertEqual(t["kind"], "not_configured")

    async def test_openai_provider_still_needs_a_model_but_openrouter_does_not(self):
        os.environ["OPENAI_API_KEY"] = "sk-test-aaaaaaaaaaaa"; os.environ.pop("OPENAI_MODEL", None)
        try:
            st = cfg.SettingsStore(Path(tempfile.mkdtemp()) / "s.json"); st.data["ai"]["provider"] = "openai"
            ok, why = ProviderGateway(st).ready(); self.assertFalse(ok); self.assertIn("OPENAI_MODEL", why)
        finally: os.environ.pop("OPENAI_API_KEY")

    def test_status_never_contains_key(self):
        os.environ["OPENAI_API_KEY"] = "sk-test-zzzzzzzzzzzz"
        try: self.assertNotIn("sk-test", json.dumps(ProviderGateway(cfg.SettingsStore(Path(tempfile.mkdtemp()) / "s.json")).status()))
        finally: os.environ.pop("OPENAI_API_KEY")

if __name__ == "__main__":
    unittest.main()
