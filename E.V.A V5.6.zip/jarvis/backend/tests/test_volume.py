import unittest
from app.vision.volume_controller import AssistantVolume, VolumeController


class Fake:
    name = "system"
    def __init__(self, v): self.v = v
    def get(self): return self.v
    def set(self, v): self.v = v


class TestVolume(unittest.TestCase):
    def test_assistant_steps_and_clamps(self):
        a = AssistantVolume(0.95); c = VolumeController(a, step=0.1)
        self.assertEqual(c.change("up")["level"], 1.0)
        a.set(0.05); self.assertEqual(c.change("down")["level"], 0.0)

    def test_targets_are_independent(self):
        a, s = AssistantVolume(0.5), Fake(0.3)
        VolumeController(a, s, target="system", step=0.1).change("up")
        self.assertEqual(a.get(), 0.5); self.assertAlmostEqual(s.get(), 0.4)
        VolumeController(a, s, target="assistant", step=0.1).change("down")
        self.assertAlmostEqual(a.get(), 0.4); self.assertAlmostEqual(s.get(), 0.4)

    def test_system_unavailable(self):
        with self.assertRaises(RuntimeError): VolumeController(AssistantVolume(), None, "system").change("up")

    def test_bad_direction(self):
        with self.assertRaises(ValueError): VolumeController(AssistantVolume()).change("left")

if __name__ == "__main__":
    unittest.main()
