import unittest
import numpy as np
from app.voice.wake_detector import ClapDetector

SR = 16000
rng = np.random.default_rng(7)


def ambient(sec, level=0.004):
    return (rng.standard_normal(int(SR * sec)) * level).astype(np.float32)


def clap(amp=0.5, tau=0.015, dur=0.12):
    t = np.arange(int(SR * dur)) / SR
    return (rng.standard_normal(len(t)) * amp * np.exp(-t / tau)).astype(np.float32)


def run(det, *parts):
    hits = []
    for p in parts:
        for i in range(0, len(p), 512):
            hits += det.process(p[i:i + 512])
    return hits


class TestClap(unittest.TestCase):
    def test_detects_clap(self):
        self.assertEqual(len(run(ClapDetector(), ambient(1), clap(), ambient(0.5))), 1)

    def test_ignores_silence_and_quiet_noise(self):
        self.assertEqual(run(ClapDetector(), ambient(3)), [])

    def test_loudness_alone_is_not_a_clap_sustained_noise(self):
        loud = (rng.standard_normal(SR) * 0.4).astype(np.float32)
        self.assertEqual(run(ClapDetector(), ambient(1), loud, ambient(0.5)), [])

    def test_ignores_loud_low_frequency_tone(self):
        t = np.arange(SR // 2) / SR
        tone = (0.6 * np.sin(2 * np.pi * 220 * t)).astype(np.float32)
        det = ClapDetector()
        self.assertEqual(run(det, ambient(1), tone, ambient(0.3)), [])
        self.assertGreater(det.rejected["narrowband"], 0)

    def test_ignores_speech_like_harmonics(self):
        t = np.arange(SR) / SR
        v = sum(np.sin(2 * np.pi * 140 * k * t) / k for k in range(1, 12)).astype(np.float32) * 0.2
        self.assertEqual(run(ClapDetector(), ambient(1), v, ambient(0.3)), [])

    def test_cooldown_suppresses_double_trigger(self):
        det = ClapDetector(cooldown_s=2.0)
        hits = run(det, ambient(1), clap(), ambient(0.3), clap(), ambient(0.5))
        self.assertEqual(len(hits), 1)
        self.assertGreater(det.rejected["cooldown"], 0)

    def test_second_clap_after_cooldown_triggers(self):
        hits = run(ClapDetector(cooldown_s=1.0), ambient(1), clap(), ambient(1.5), clap(), ambient(0.5))
        self.assertEqual(len(hits), 2)

    def test_ambient_noise_floor_adapts(self):
        noisy = ambient(3, 0.03)  # steady noisy room must not trigger
        self.assertEqual(run(ClapDetector(), noisy), [])
        self.assertEqual(len(run(ClapDetector(), noisy, clap(0.9), ambient(0.3, 0.03))), 1)

    def test_sensitivity_changes_threshold(self):
        weak = clap(0.09)
        low = run(ClapDetector(sensitivity=0.0), ambient(1), weak, ambient(0.3))
        high = run(ClapDetector(sensitivity=1.0), ambient(1), weak, ambient(0.3))
        self.assertEqual(low, [])
        self.assertEqual(len(high), 1)

    def test_chunk_size_independent(self):
        det = ClapDetector()
        sig = np.concatenate([ambient(1), clap(), ambient(0.5)])
        hits = []
        for i in range(0, len(sig), 97):
            hits += det.process(sig[i:i + 97])
        self.assertEqual(len(hits), 1)


if __name__ == "__main__":
    unittest.main()
