"""Integration tests that need real components. Each skips itself (with the reason) when the component is absent.
Run them on your PC after setup.bat:  .venv\\Scripts\\python -m unittest tests.test_integration_windows -v"""
import asyncio, importlib.util, tempfile, threading, unittest
from functools import partial
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path

PAGE = """<html><head><title>Jarvis Test Page</title></head><body>
<h1>Test</h1><label for=q>Query</label><input id=q placeholder="Type here">
<button id=a onclick="document.getElementById('out').innerText='Clicked A'">Alpha</button>
<button onclick="document.getElementById('out').innerText='Clicked B'">Beta</button>
<button>Dup</button><button>Dup</button><div id=out>nothing</div></body></html>"""
have = lambda m: importlib.util.find_spec(m) is not None


def serve():
    d = Path(tempfile.mkdtemp()); (d / "index.html").write_text(PAGE)
    srv = HTTPServer(("127.0.0.1", 0), partial(SimpleHTTPRequestHandler, directory=str(d)))
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, f"http://127.0.0.1:{srv.server_port}/index.html"


@unittest.skipUnless(have("playwright"), "playwright not installed")
class TestBrowser(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        from app.core import config as cfg
        from app.computer.browser_agent import BrowserAgent
        self.s = cfg.SettingsStore(Path(tempfile.mkdtemp()) / "s.json")
        self.s.data["computer"]["browser_channel"] = ""      # bundled chromium (`playwright install chromium`)
        self.b = BrowserAgent(self.s, Path(tempfile.mkdtemp())); self.srv, self.url = serve()

    async def asyncTearDown(self): await self.b.close(); self.srv.shutdown()

    async def test_navigate_click_verify_type_screenshot(self):
        from app.computer.browser_agent import BrowserError
        try: r = await self.b.open_url(self.url)
        except BrowserError as e: self.skipTest(str(e))
        self.assertTrue(r["verified"]); self.assertEqual(r["snapshot"]["title"], "Jarvis Test Page")
        c = await self.b.click("Alpha"); self.assertTrue(c["page_changed"]); self.assertIn("Clicked A", (await self.b.snapshot(False))["text"])
        with self.assertRaises(BrowserError) as cm: await self.b.click("Dup")          # ambiguity is an error, not a guess
        self.assertIn("ambiguous", str(cm.exception))
        with self.assertRaises(BrowserError): await self.b.click("Nonexistent")
        t = await self.b.type_text("Query", "hello"); self.assertTrue(t["verified"])
        s1 = await self.b.screenshot(); self.assertTrue(s1["png"].startswith(b"\x89PNG")); self.assertTrue(s1["new"])
        self.assertFalse((await self.b.screenshot())["new"])                           # unchanged page: not re-sent
        with self.assertRaises(BrowserError): await self.b.open_url("file:///C:/Windows/win.ini")
        with self.assertRaises(BrowserError): await self.b.open_url("javascript:alert(1)")


@unittest.skipUnless(have("mss"), "mss not installed")
class TestScreenshot(unittest.IsolatedAsyncioTestCase):
    async def test_capture_png(self):
        from app.core import config as cfg
        from app.computer.desktop_agent import DesktopAgent, DesktopError
        d = DesktopAgent(cfg.SettingsStore(Path(tempfile.mkdtemp()) / "s.json"))
        try: r = await d.screenshot()
        except Exception as e: self.skipTest(f"no display available: {type(e).__name__}")
        self.assertTrue(r["png"].startswith(b"\x89PNG"))


@unittest.skipUnless(have("pywinauto"), "pywinauto (Windows) not installed")
class TestDesktop(unittest.IsolatedAsyncioTestCase):
    async def test_open_notepad_verify_window_and_type(self):
        from app.core import config as cfg
        from app.computer.desktop_agent import DesktopAgent
        from app.tools import app_launcher
        from app.tools.registry import ToolContext
        s = cfg.SettingsStore(Path(tempfile.mkdtemp()) / "s.json"); s.data["computer"].update(enabled=True, desktop_enabled=True)
        d = DesktopAgent(s); res = await app_launcher._open({"name": "notepad"}, ToolContext(s, services={"desktop": d}))
        self.assertTrue(res["ok"] and res["verified"], res["summary"])
        await d.type_text("Notepad", "jarvis test")
        info = await d.inspect("Notepad"); self.assertTrue(info["controls"])  # window is inspectable; text content is verified visually via screen_capture

if __name__ == "__main__":
    unittest.main()
