"""End-to-end assistant flow with scripted fake providers (no network, no API charges)."""
import asyncio, tempfile, unittest
from pathlib import Path
from app.core.state import State
from app.providers.base import ProviderError
from app.services.assistant_service import AssistantService, is_stop_command
from tests.fakes import FakeProvider, FakeSynth, FakeTranscriber, call, collect, text, wait_for

import numpy as np
from app.core.config import deep_merge as cfg_merge


def make(scripts, *, configured=True, delay=0.0, synth_ok=True, **settings):
    d = Path(tempfile.mkdtemp())
    prov = FakeProvider(scripts, configured, delay)
    svc = AssistantService(d, providers={"openai": prov}, synth_factory=lambda n: FakeSynth(synth_ok), transcriber_factory=lambda n: FakeTranscriber())
    svc.settings.data["ai"]["models"]["openai"] = "fake-model"
    svc.settings.data["ai"]["provider"] = "openai"
    # baseline for tests: every opt-in capability OFF (the shipped defaults turn them on)
    svc.settings.data["computer"].update(enabled=False, browser_enabled=False, desktop_enabled=False, files_enabled=False, whatsapp_enabled=False)
    svc.settings.data["vision"]["gestures_enabled"] = False
    svc.settings.data["voice"]["clap"]["enabled"] = False
    for k, v in settings.items():
        if isinstance(v, dict) and k in svc.settings.data: svc.settings.data[k] = cfg_merge(svc.settings.data[k], v)
        else: svc.settings.data[k].update(v)
    return svc, prov


def states(events): return [e["state"] for e in events if e["type"] == "state"]


class TestFlow(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self): self.svc = None
    async def asyncTearDown(self):
        if self.svc: await self.svc.shutdown()

    async def boot(self, *a, **k):
        self.svc, prov = make(*a, **k); self.ev = collect(self.svc.bus); await self.svc.start(); return self.svc, prov

    async def test_text_reply_then_speaking_then_standby(self):
        svc, prov = await self.boot([[text("Good "), text("evening.")]])
        r = await svc.handle_text("hello")
        self.assertTrue(await wait_for(lambda: svc.state.state == State.SPEAKING))
        evs = self.ev()
        self.assertEqual([e["text"] for e in evs if e["type"] == "response_delta"], ["Good ", "evening."])
        self.assertEqual([e for e in evs if e["type"] == "response_final"][0]["text"], "Good evening.")
        self.assertEqual([e for e in evs if e["type"] == "audio"][0]["mime"], "audio/mpeg")
        evs = list(evs)
        await svc.speech_finished()
        self.assertTrue(await wait_for(lambda: svc.state.state == State.STANDBY))
        evs = self.ev()
        self.assertEqual(states(evs)[-3:], ["PROCESSING", "SPEAKING", "STANDBY"])
        self.assertEqual([e["last"] for e in evs if e["type"] == "audio"], [False, True])   # one chunk + end marker
        # persisted
        self.assertEqual([m["role"] for m in svc.memory.messages(r["conversation_id"])], ["user", "assistant"])

    async def test_missing_credentials_is_an_error_not_a_fake_answer(self):
        svc, _ = await self.boot([], configured=False)
        await svc.handle_text("hello")
        self.assertTrue(await wait_for(lambda: svc.state.state == State.ERROR))
        evs = self.ev()
        err = [e for e in evs if e["type"] == "error"][0]
        self.assertIn("OPENAI_API_KEY", err["message"]); self.assertTrue(err["recoverable"])
        self.assertFalse([e for e in evs if e["type"] == "response_final"])
        self.assertTrue(await wait_for(lambda: svc.state.state == State.STANDBY, 5))  # recovers by itself

    async def test_provider_failure_recoverable(self):
        svc, _ = await self.boot([[ProviderError("Rate limited (429)", "rate_limit")]])
        await svc.handle_text("hi"); self.assertTrue(await wait_for(lambda: svc.state.state == State.ERROR))
        self.assertEqual([e for e in self.ev() if e["type"] == "error"][0]["kind"], "rate_limit")

    async def test_tool_loop_executes_calculator_and_feeds_result_back(self):
        svc, prov = await self.boot([[call("calculator", {"expression": "6*7"})], [text("It is 42.")]])
        await svc.handle_text("use your calculator tool on the area of the field")
        self.assertTrue(await wait_for(lambda: svc.state.state == State.SPEAKING))
        evs = self.ev()
        self.assertIn("EXECUTING", states(evs))
        tr = [e for e in evs if e["type"] == "tool_result"][0]; self.assertTrue(tr["ok"]); self.assertIn("42", tr["summary"])
        second = prov.calls[1]["messages"]; self.assertEqual(second[-1]["role"], "tool"); self.assertIn("42", second[-1]["content"])

    async def test_denied_tool_reported_to_model_not_executed(self):
        svc, prov = await self.boot([[call("browser_open_url", {"url": "https://example.com"})], [text("Browser control is disabled.")]])
        await svc.handle_text("open example.com")
        self.assertTrue(await wait_for(lambda: svc.state.state == State.SPEAKING))
        self.assertNotIn("browser_open_url", prov.calls[0]["tools"])  # not even offered while disabled
        tr = [e for e in self.ev() if e["type"] == "tool_result"][0]; self.assertFalse(tr["ok"])

    async def test_confirmation_flow_approve_and_decline(self):
        d = tempfile.mkdtemp()
        for approve in (True, False):
            svc, _ = make([[call("write_file", {"path": f"{d}/n{approve}.txt", "content": "x"})], [text("Done.")]], computer={"enabled": True, "files_enabled": True, "allowed_dirs": [d]})
            ev = collect(svc.bus); await svc.start()
            await svc.handle_text("write a file")
            def pending(): return [e for e in ev() if e["type"] == "confirmation_request"]
            self.assertTrue(await wait_for(lambda: bool(pending())))
            self.assertEqual(svc.state.state, State.EXECUTING)
            self.assertFalse((Path(d) / f"n{approve}.txt").exists())  # nothing happens before approval
            req = pending()[0]; self.assertIn("n", req["prompt"])
            await svc.confirm(req["id"], approve)
            self.assertTrue(await wait_for(lambda: svc.state.state == State.SPEAKING))
            self.assertEqual((Path(d) / f"n{approve}.txt").exists(), approve)
            await svc.shutdown()

    async def test_stop_cancels_running_task_and_confirmation(self):
        d = tempfile.mkdtemp()
        svc, _ = make([[call("write_file", {"path": f"{d}/z.txt", "content": "x"})], [text("never")]], computer={"enabled": True, "files_enabled": True, "allowed_dirs": [d]})
        self.svc = svc; ev = collect(svc.bus); await svc.start()
        await svc.handle_text("write")
        self.assertTrue(await wait_for(lambda: svc.confirmations.pending == 1))
        await svc.stop("test", emergency=True)
        self.assertEqual(svc.state.state, State.STANDBY); self.assertFalse(svc.tasks.running)
        self.assertFalse((Path(d) / "z.txt").exists())
        s = states(ev()); self.assertIn("INTERRUPTED", s); self.assertTrue(svc.registry.estop)
        await svc.handle_text("hi again")  # next request clears the e-stop
        self.assertTrue(await wait_for(lambda: not svc.registry.estop))

    async def test_stop_while_speaking_emits_interrupt_for_audio(self):
        svc, _ = await self.boot([[text("Long answer")]])
        await svc.handle_text("hi"); await wait_for(lambda: svc.state.state == State.SPEAKING); self.ev()
        await svc.stop("button")
        evs = self.ev(); self.assertTrue([e for e in evs if e["type"] == "interrupted"]); self.assertEqual(svc.state.state, State.STANDBY)

    async def test_new_request_cancels_obsolete_one(self):
        svc, prov = await self.boot([[text("first")], [text("second")]], delay=0.3)
        await svc.handle_text("one"); await asyncio.sleep(0.1)
        await svc.handle_text("two")
        self.assertTrue(await wait_for(lambda: svc.state.state == State.SPEAKING, 4))
        finals = [e["text"] for e in self.ev() if e["type"] == "response_final"]; self.assertEqual(finals, ["second"])

    async def test_text_stop_command_does_not_call_ai(self):
        svc, prov = await self.boot([[text("x")]])
        self.assertEqual((await svc.handle_text("Jarvis, stop!"))["handled"], "stop"); self.assertEqual(prov.calls, [])
        self.assertTrue(is_stop_command("stop talking")); self.assertFalse(is_stop_command("stop the timer at five"))

    async def test_tts_unavailable_degrades_to_text(self):
        svc, _ = await self.boot([[text("hello")]], synth_ok=False)
        await svc.handle_text("hi"); self.assertTrue(await wait_for(lambda: svc.state.state == State.STANDBY and any(e["type"] == "response_final" for e in self.ev())))

    async def test_speech_watchdog_returns_to_standby_if_frontend_silent(self):
        svc, _ = await self.boot([[text("hello")]])
        await svc.handle_text("hi"); await wait_for(lambda: svc.state.state == State.SPEAKING)
        self.assertTrue(await wait_for(lambda: svc._speech_watch is not None))

    async def test_capabilities_are_honest_and_leak_no_secrets(self):
        import os, json
        os.environ["OPENAI_API_KEY"] = "sk-test-leakcheck-12345"
        try:
            svc, _ = await self.boot([]); c = svc.capabilities(); blob = json.dumps(c)
            self.assertNotIn("sk-test", blob); self.assertTrue(c["secrets"]["OPENAI_API_KEY"])
            self.assertFalse(c["wake_phrase"]["available"]); self.assertIn("reason", c["wake_phrase"])
            self.assertEqual(c["ai"]["model"], "fake-model")
        finally: os.environ.pop("OPENAI_API_KEY")

    async def test_images_only_latest_sent_and_not_persisted(self):
        from app.brain.context_builder import keep_latest_images_only
        m = [{"role": "user", "content": "a", "images": ["1"]}, {"role": "user", "content": "b", "images": ["2"]}]
        keep_latest_images_only(m); self.assertNotIn("images", m[0]); self.assertEqual(m[1]["images"], ["2"])


class TestVoiceFlow(unittest.IsolatedAsyncioTestCase):
    rng = np.random.default_rng(1)

    def pcm(self, x): return (np.clip(x, -1, 1) * 32767).astype("<i2").tobytes()
    def clap(self):
        t = np.arange(1920) / 16000; return (self.rng.standard_normal(1920) * 0.5 * np.exp(-t / 0.015)).astype(np.float32)
    def quiet(self, s): return (self.rng.standard_normal(int(16000 * s)) * 0.003).astype(np.float32)
    def voice(self, s): return (0.2 * np.sin(2 * np.pi * 180 * np.arange(int(16000 * s)) / 16000)).astype(np.float32)

    async def feed(self, svc, x):
        for i in range(0, len(x), 1024): await svc.feed_audio(self.pcm(x[i:i + 1024]))

    async def test_clap_disabled_by_default_and_mic_off_ignored(self):
        svc, _ = make([]); await svc.start()
        await svc.set_mic(True); await self.feed(svc, np.concatenate([self.quiet(1), self.clap(), self.quiet(.3)]))
        self.assertEqual(svc.state.state, State.STANDBY)   # clap detector is opt-in
        await svc.shutdown()

    async def test_clap_wakes_listening_then_full_voice_turn(self):
        svc, _ = make([[text("Hi there")]], voice={"clap": {"enabled": True, "sensitivity": 0.5, "cooldown_s": 2.0}, "silence_timeout_s": 0.6})
        svc.voice.apply_settings(); ev = collect(svc.bus); await svc.start(); await svc.set_mic(True)
        await self.feed(svc, np.concatenate([self.quiet(1), self.clap(), self.quiet(0.2)]))
        self.assertEqual(svc.state.state, State.LISTENING)
        self.assertTrue([e for e in ev() if e["type"] == "wake" and e["source"] == "clap"])
        await self.feed(svc, np.concatenate([self.voice(0.8), self.quiet(1.0)]))
        self.assertTrue(await wait_for(lambda: svc.state.state == State.SPEAKING))
        e = ev(); self.assertEqual([x for x in e if x["type"] == "transcript_final"][0]["text"], "hello jarvis")
        self.assertEqual(states(e)[:3], ["LISTENING", "PROCESSING", "SPEAKING"][:3] if states(e)[0] == "LISTENING" else states(e)[:3])
        await svc.shutdown()

    async def test_button_wake_requires_mic_and_reports_error(self):
        svc, _ = make([]); ev = collect(svc.bus); await svc.start()
        await svc.wake("button"); self.assertEqual(svc.state.state, State.STANDBY)
        self.assertEqual([e for e in ev() if e["type"] == "error"][0]["kind"], "mic_off")
        await svc.set_mic(True); await svc.wake("button"); self.assertEqual(svc.state.state, State.LISTENING)
        await svc.shutdown()

    async def test_no_speech_returns_to_standby(self):
        svc, _ = make([], voice={"no_speech_timeout_s": 1.0}); await svc.start(); await svc.set_mic(True); await svc.wake("button")
        await self.feed(svc, self.quiet(2)); self.assertEqual(svc.state.state, State.STANDBY); await svc.shutdown()

    async def test_clap_interrupts_speech_and_relistens(self):
        svc, _ = make([[text("long speech")]], voice={"clap": {"enabled": True, "sensitivity": 0.5, "cooldown_s": 2.0}}); svc.voice.apply_settings()
        await svc.start(); await svc.set_mic(True)
        await svc.handle_text("hi"); self.assertTrue(await wait_for(lambda: svc.state.state == State.SPEAKING))
        await self.feed(svc, np.concatenate([self.quiet(1), self.clap(), self.quiet(.2)]))
        self.assertEqual(svc.state.state, State.LISTENING); await svc.shutdown()

    async def test_mic_off_stops_listening(self):
        svc, _ = make([]); await svc.start(); await svc.set_mic(True); await svc.wake("button")
        await svc.set_mic(False); self.assertEqual(svc.state.state, State.STANDBY); await svc.shutdown()

    async def test_gesture_changes_assistant_volume_and_emits(self):
        svc, _ = make([], vision={"volume_target": "assistant", "volume_step": 0.1}); ev = collect(svc.bus); await svc.start()
        before = svc.assistant_volume.get(); await svc.on_gesture("down")
        self.assertAlmostEqual(svc.assistant_volume.get(), before - 0.1, places=2)
        e = ev(); self.assertTrue([x for x in e if x["type"] == "gesture"]); self.assertEqual([x for x in e if x["type"] == "volume"][0]["target"], "assistant")
        await svc.shutdown()

    async def test_system_volume_unavailable_falls_back_to_assistant_volume(self):
        svc, _ = make([], vision={"volume_target": "system"}); ev = collect(svc.bus); await svc.start()
        if svc.system_volume.available()[0]: self.skipTest("pycaw present")
        before = svc.assistant_volume.get(); await svc.on_gesture("up")
        e = ev(); self.assertFalse([x for x in e if x["type"] == "error"])
        self.assertEqual([x for x in e if x["type"] == "volume"][0]["target"], "assistant"); self.assertGreaterEqual(svc.assistant_volume.get(), before)
        await svc.shutdown()

    async def test_settings_update_validated_and_applied(self):
        svc, _ = make([]); await svc.start()
        self.assertTrue(await svc.update_settings({"voice": {"clap": {"sensitivity": 9}}}))
        self.assertEqual(await svc.update_settings({"voice": {"clap": {"enabled": True, "sensitivity": 0.9}}}), [])
        self.assertAlmostEqual(svc.voice.clap.ratio, 10 - 6.5 * 0.9); await svc.shutdown()

if __name__ == "__main__":
    unittest.main()
