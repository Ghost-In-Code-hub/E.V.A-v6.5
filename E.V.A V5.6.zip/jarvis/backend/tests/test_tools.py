import asyncio, tempfile, unittest
from pathlib import Path
from app.core import config as cfg
from app.tools import app_launcher, calculator, file_operations, web, whatsapp
from app.tools.registry import Tool, ToolContext, ToolRegistry, result, validate_args
from app.computer.desktop_agent import validate_hotkey
from app.computer.verification import ScreenshotCache, diff_state


def mk(**computer):
    s = cfg.SettingsStore(Path(tempfile.mkdtemp()) / "s.json")
    base = dict(enabled=False, browser_enabled=False, desktop_enabled=False, files_enabled=False, whatsapp_enabled=False)
    s.update({"computer": {**base, **computer}})
    reg = ToolRegistry(s)
    for mod in (calculator, app_launcher, file_operations, web, whatsapp):
        for t in mod.tools(): reg.register(t)
    return s, reg


class TestCalculator(unittest.TestCase):
    def test_values(self):
        for e, v in (("2+3*4", 14), ("(2+3)*4", 20), ("2^10", 1024), ("10/4", 2.5), ("-5+2", -3), ("7%3", 1), ("sqrt(144)", 12)):
            self.assertEqual(calculator.safe_eval(e), v, e)

    def test_rejects_code(self):
        for e in ("__import__('os').system('echo hi')", "open('x')", "(lambda: 1)()", "[1,2]", "'a'*5", "9**9**9", "a+1", "x=1"):
            with self.assertRaises((ValueError, SyntaxError, TypeError)): calculator.safe_eval(e)


class TestRegistry(unittest.IsolatedAsyncioTestCase):
    async def test_unknown_tool(self):
        s, r = mk(); res = await r.execute("rm_rf", {}, ToolContext(s))
        self.assertEqual(res["code"], "unknown_tool")

    async def test_no_shell_tool_exists(self):
        s, r = mk()
        for n in r.names(): self.assertNotIn(n, ("shell", "run_command", "exec", "powershell", "cmd", "python"))

    async def test_calculator_through_registry(self):
        s, r = mk(); res = await r.execute("calculator", {"expression": "12*12"}, ToolContext(s))
        self.assertTrue(res["ok"]); self.assertEqual(res["value"], 144)

    async def test_arg_validation(self):
        s, r = mk()
        self.assertEqual((await r.execute("calculator", {}, ToolContext(s)))["code"], "invalid_args")
        self.assertEqual((await r.execute("calculator", {"expression": 5}, ToolContext(s)))["code"], "invalid_args")
        self.assertEqual((await r.execute("calculator", {"expression": "1", "x": 1}, ToolContext(s)))["code"], "invalid_args")
        self.assertIsNotNone(validate_args({"properties": {"n": {"type": "integer"}}}, {"n": True}))

    async def test_disabled_capabilities_denied_and_hidden(self):
        s, r = mk()
        names = [t["name"] for t in r.specs()]
        self.assertIn("calculator", names); self.assertNotIn("browser_click", names); self.assertNotIn("write_file", names)
        res = await r.execute("browser_open_url", {"url": "https://example.com"}, ToolContext(s))
        self.assertEqual(res["code"], "permission_denied")

    async def test_master_switch_beats_individual_switch(self):
        s, r = mk(enabled=False, files_enabled=True)
        self.assertEqual((await r.execute("list_directory", {"path": "."}, ToolContext(s)))["code"], "permission_denied")

    async def test_confirmation_declined_blocks_action(self):
        d = tempfile.mkdtemp(); s, r = mk(enabled=True, files_enabled=True, allowed_dirs=[d])
        async def no(prompt, details): return False
        res = await r.execute("write_file", {"path": f"{d}/a.txt", "content": "hi"}, ToolContext(s, confirm=no))
        self.assertEqual(res["code"], "declined"); self.assertFalse((Path(d) / "a.txt").exists())

    async def test_confirmation_approved_runs_and_verifies(self):
        d = tempfile.mkdtemp(); s, r = mk(enabled=True, files_enabled=True, allowed_dirs=[d]); prompts = []
        async def yes(prompt, details): prompts.append(prompt); return True
        res = await r.execute("write_file", {"path": f"{d}/a.txt", "content": "hi"}, ToolContext(s, confirm=yes))
        self.assertTrue(res["ok"] and res["verified"]); self.assertEqual((Path(d) / "a.txt").read_text(), "hi"); self.assertEqual(len(prompts), 1)

    async def test_overwrite_warns(self):
        d = tempfile.mkdtemp(); (Path(d) / "a.txt").write_text("old"); s, r = mk(enabled=True, files_enabled=True, allowed_dirs=[d]); prompts = []
        async def yes(p, _): prompts.append(p); return True
        await r.execute("write_file", {"path": f"{d}/a.txt", "content": "new"}, ToolContext(s, confirm=yes))
        self.assertIn("OVERWRITE", prompts[0])

    async def test_confirmation_required_even_without_channel(self):
        d = tempfile.mkdtemp(); s, r = mk(enabled=True, files_enabled=True, allowed_dirs=[d])
        res = await r.execute("delete_file", {"path": f"{d}/x"}, ToolContext(s))
        self.assertEqual(res["code"], "no_confirm")

    async def test_file_sandbox(self):
        d = tempfile.mkdtemp(); s, r = mk(enabled=True, files_enabled=True, allowed_dirs=[d])
        self.assertEqual((await r.execute("read_file", {"path": "/etc/passwd"}, ToolContext(s)))["code"], "path_denied")
        (Path(d) / "n.txt").write_text("hello"); res = await r.execute("read_file", {"path": f"{d}/n.txt"}, ToolContext(s))
        self.assertTrue(res["ok"]); self.assertIn("untrusted_file_content", res["summary"])

    async def test_no_allowed_dirs_means_no_access(self):
        s, r = mk(enabled=True, files_enabled=True)
        self.assertEqual((await r.execute("read_file", {"path": "x"}, ToolContext(s)))["code"], "path_denied")

    async def test_risky_click_needs_confirmation_safe_click_does_not(self):
        t = r_tool = mk(enabled=True, browser_enabled=True)[1].get("browser_click")
        self.assertIsNotNone(t.confirm({"target": "Place order"})); self.assertIsNotNone(t.confirm({"target": "Delete account"}))
        self.assertIsNone(t.confirm({"target": "Next page"}))
        tt = mk()[1].get("browser_type")
        self.assertIsNotNone(tt.confirm({"target": "Message", "text": "hi", "submit": True})); self.assertIsNone(tt.confirm({"target": "Search", "text": "x", "submit": True}))

    async def test_duplicate_action_prevention(self):
        s, r = mk(); n = {"c": 0}
        async def h(a, c): n["c"] += 1; return result(True, "done")
        r.register(Tool("once", "x", {"type": "object", "properties": {}}, h, idempotent=False, read_only=False))
        a = await r.execute("once", {}, ToolContext(s)); b = await r.execute("once", {}, ToolContext(s))
        self.assertTrue(a["ok"]); self.assertEqual(b["code"], "duplicate"); self.assertEqual(n["c"], 1)

    async def test_estop_blocks_everything_until_cleared(self):
        s, r = mk(); r.trigger_estop()
        self.assertEqual((await r.execute("calculator", {"expression": "1+1"}, ToolContext(s)))["code"], "estop")
        r.clear_estop(); self.assertTrue((await r.execute("calculator", {"expression": "1+1"}, ToolContext(s)))["ok"])

    async def test_timeout_and_exceptions_contained(self):
        s, r = mk()
        async def slow(a, c): await asyncio.sleep(5)
        async def boom(a, c): raise RuntimeError("kaboom")
        r.register(Tool("slow", "x", {"type": "object", "properties": {}}, slow, timeout=0.05)); r.register(Tool("boom", "x", {"type": "object", "properties": {}}, boom))
        self.assertEqual((await r.execute("slow", {}, ToolContext(s)))["code"], "timeout")
        self.assertEqual((await r.execute("boom", {}, ToolContext(s)))["code"], "exception")

    async def test_cancellation_propagates(self):
        s, r = mk()
        async def slow(a, c): await asyncio.sleep(5)
        r.register(Tool("slow2", "x", {"type": "object", "properties": {}}, slow, timeout=10))
        t = asyncio.create_task(r.execute("slow2", {}, ToolContext(s))); await asyncio.sleep(0.05); t.cancel()
        with self.assertRaises(asyncio.CancelledError): await t

    async def test_audit_trail(self):
        from app.core.security import AuditLog
        s, r = mk(); a = AuditLog(Path(tempfile.mkdtemp()) / "a.jsonl")
        await r.execute("calculator", {"expression": "1+1"}, ToolContext(s, audit=a))
        self.assertIn("tool_call", a.path.read_text()); self.assertIn("tool_result", a.path.read_text())


class TestApps(unittest.IsolatedAsyncioTestCase):
    def test_unapproved_app(self):
        p, why = app_launcher.resolve_app("regedit", {}); self.assertIsNone(p); self.assertIn("not an approved", why)

    def test_approved_but_missing(self):
        p, why = app_launcher.resolve_app("vscode", {})
        if p is None: self.assertIn("not found", why)

    def test_user_configured_app(self):
        exe = Path(tempfile.mkdtemp()) / "My App.exe"; exe.write_text("x")
        p, _ = app_launcher.resolve_app("myapp", {"myapp": str(exe)}); self.assertEqual(p, str(exe))  # path with spaces
        p, why = app_launcher.resolve_app("ghost", {"ghost": "C:/nope/ghost.exe"}); self.assertIsNone(p); self.assertIn("does not exist", why)

    async def test_open_unapproved_via_registry(self):
        s, r = mk(enabled=True, desktop_enabled=True)
        res = await r.execute("open_application", {"name": "powershell"}, ToolContext(s)); self.assertFalse(res["ok"]); self.assertEqual(res["code"], "not_found")

    async def test_launch_real_process_and_report(self):
        import sys
        s, r = mk(enabled=True, desktop_enabled=True, apps={"py": sys.executable})
        res = await r.execute("open_application", {"name": "py"}, ToolContext(s))
        self.assertTrue(res["ok"]); self.assertFalse(res["verified"])  # honest: process ran, window not verified


class TestWhatsApp(unittest.IsolatedAsyncioTestCase):
    async def test_status_reports_missing_config(self):
        import os
        for k in ("WHATSAPP_TOKEN", "WHATSAPP_PHONE_NUMBER_ID"): os.environ.pop(k, None)
        s, r = mk(enabled=True, whatsapp_enabled=True)
        res = await r.execute("whatsapp_status", {}, ToolContext(s)); self.assertFalse(res["cloud_api_configured"]); self.assertIn("NOT configured", res["summary"])

    async def test_cloud_prepare_requires_config_and_phone(self):
        import os
        s, r = mk(enabled=True, whatsapp_enabled=True); ctx = ToolContext(s, services={})
        self.assertEqual((await r.execute("whatsapp_prepare_message", {"contact": "+923001234567", "message": "hi", "channel": "cloud"}, ctx))["code"], "not_configured")
        os.environ["WHATSAPP_TOKEN"] = "tok" * 5; os.environ["WHATSAPP_PHONE_NUMBER_ID"] = "123"
        try:
            self.assertEqual((await r.execute("whatsapp_prepare_message", {"contact": "Ali", "message": "hi", "channel": "cloud"}, ctx))["code"], "bad_recipient")
            ok = await r.execute("whatsapp_prepare_message", {"contact": "+92 300 1234567", "message": "hi", "channel": "cloud"}, ctx)
            self.assertTrue(ok["ok"]); self.assertIn("NOT SENT", ok["summary"])
            asked = []
            async def no(p, d): asked.append(p); return False
            res = await r.execute("whatsapp_send_prepared", {"message_id": ok["message_id"]}, ToolContext(s, confirm=no, services={}))
            self.assertEqual(res["code"], "declined"); self.assertIn("+923001234567", asked[0]); self.assertIn("hi", asked[0])
        finally:
            os.environ.pop("WHATSAPP_TOKEN"); os.environ.pop("WHATSAPP_PHONE_NUMBER_ID")

    async def test_send_unknown_id_and_no_channel(self):
        s, r = mk(enabled=True, whatsapp_enabled=True)
        self.assertEqual((await r.execute("whatsapp_send_prepared", {"message_id": "zzz"}, ToolContext(s)))["code"], "no_confirm")

    async def test_disabled_by_default(self):
        s, r = mk(); self.assertEqual((await r.execute("whatsapp_status", {}, ToolContext(s)))["code"], "permission_denied")


class TestVerification(unittest.TestCase):
    def test_screenshot_dedupe(self):
        c = ScreenshotCache(); self.assertTrue(c.is_new("s", b"a")); self.assertFalse(c.is_new("s", b"a")); self.assertTrue(c.is_new("s", b"b")); self.assertTrue(c.is_new("other", b"b"))

    def test_diff(self):
        self.assertFalse(diff_state({"u": 1}, {"u": 1})["changed"]); self.assertEqual(diff_state({"u": 1, "t": 1}, {"u": 2, "t": 1})["fields"], ["u"])

    def test_hotkey_policy(self):
        self.assertIsNone(validate_hotkey(["ctrl", "s"]))
        for bad in (["win", "r"], ["alt", "f4"], ["ctrl", "alt", "delete"], []): self.assertIsNotNone(validate_hotkey(bad))

if __name__ == "__main__":
    unittest.main()
