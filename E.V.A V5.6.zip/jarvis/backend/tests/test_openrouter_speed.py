import asyncio, json, os, tempfile, unittest
from pathlib import Path
from app.core import config as cfg
from app.core.state import State
from app.providers.base import ProviderError
from app.providers.gateway import ProviderGateway
from app.providers.openai_provider import OpenAIStreamParser
from app.providers.openrouter_provider import DEFAULT_MODELS, OpenRouterProvider, build_body, candidate_models
from app.voice.speech_pipeline import SpeechPipeline, split_sentences
from app.voice.transcription import build_openrouter_stt_body, get_transcriber, pick_stt_model
from tests.fakes import FakeProvider, FakeSynth, FakeTranscriber, collect, text, wait_for
from tests.test_service import make, states


class TestDefaults(unittest.TestCase):
    def test_openrouter_default_and_no_model_needed(self):
        s = cfg.SettingsStore(Path(tempfile.mkdtemp()) / "s.json"); self.assertEqual(s["ai"]["provider"], "openrouter")
        os.environ["OPENROUTER_API_KEY"] = "sk-or-v1-testtesttesttest"; os.environ.pop("OPENROUTER_MODEL", None)
        try:
            g = ProviderGateway(s); self.assertEqual(g.model(), ""); self.assertEqual(g.ready(), (True, ""))   # key alone is enough
        finally: os.environ.pop("OPENROUTER_API_KEY")

    def test_missing_key_message_is_plain(self):
        os.environ.pop("OPENROUTER_API_KEY", None)
        ok, why = ProviderGateway(cfg.SettingsStore(Path(tempfile.mkdtemp()) / "s.json")).ready()
        self.assertFalse(ok); self.assertIn("OpenRouter API key", why); self.assertNotIn("model", why.lower())

    def test_features_enabled_by_default(self):
        d = cfg.DEFAULTS
        self.assertTrue(d["vision"]["gestures_enabled"]); self.assertTrue(d["voice"]["clap"]["enabled"]); self.assertTrue(d["voice"]["auto_mic"])
        self.assertTrue(d["computer"]["enabled"] and d["computer"]["browser_enabled"] and d["computer"]["desktop_enabled"])
        self.assertTrue(d["interface"]["island_overlay"]); self.assertEqual(cfg.validate_settings(cfg.deep_merge(d, {})), [])

    def test_openrouter_key_is_a_secret(self):
        from app.core.security import redact
        self.assertIn("OPENROUTER_API_KEY", cfg.SECRET_KEYS); self.assertNotIn("v1-abcdefghijkl", redact("key sk-or-v1-abcdefghijklmnopqrstu"))


class TestOpenRouter(unittest.IsolatedAsyncioTestCase):
    def test_models_chain_without_user_model(self):
        os.environ.pop("OPENROUTER_MODEL", None)
        self.assertEqual(candidate_models(""), list(DEFAULT_MODELS)); self.assertEqual(DEFAULT_MODELS[0], "openrouter/auto")

    def test_advanced_pin_via_env_only(self):
        os.environ["OPENROUTER_MODEL"] = "some/model"
        try: self.assertEqual(candidate_models(""), ["some/model"])
        finally: os.environ.pop("OPENROUTER_MODEL")

    def test_request_body_asks_for_fastest_provider_and_tools(self):
        b = build_body([{"role": "user", "content": "hi"}], [{"name": "t", "description": "d", "parameters": {"type": "object"}}], "sys", "openrouter/auto")
        self.assertEqual(b["provider"], {"sort": "latency"}); self.assertTrue(b["stream"]); self.assertEqual(b["tools"][0]["function"]["name"], "t")
        self.assertEqual(b["messages"][0]["role"], "system")

    def test_mid_stream_error_surfaces(self):
        with self.assertRaises(ProviderError): OpenAIStreamParser().feed({"error": {"message": "upstream failed", "code": 502}})

    def test_stt_model_picked_automatically(self):
        self.assertEqual(pick_stt_model(["x/y", "openai/whisper-large-v3"]), "openai/whisper-large-v3"); self.assertEqual(pick_stt_model([]), "openai/whisper-1")
        b = build_openrouter_stt_body(b"RIFFxx", "openai/whisper-1", "ur"); self.assertEqual(b["language"], "ur"); self.assertEqual(b["input_audio"]["format"], "wav")
        self.assertEqual(get_transcriber("openrouter").name, "openrouter")

    async def test_key_test_uses_validate_not_model_list(self):
        class P(OpenRouterProvider):
            async def validate_key(self, timeout=15): return {"label": "my key"}
        os.environ["OPENROUTER_API_KEY"] = "sk-or-v1-testtesttesttest"
        try:
            r = await ProviderGateway(cfg.SettingsStore(Path(tempfile.mkdtemp()) / "s.json"), {"openrouter": P()}).test("openrouter")
            self.assertTrue(r["ok"]); self.assertEqual(r["models"], [])
        finally: os.environ.pop("OPENROUTER_API_KEY")

    async def test_bad_key_reports_auth(self):
        class P(OpenRouterProvider):
            async def validate_key(self, timeout=15): raise ProviderError("Authentication failed (401)", "auth")
        os.environ["OPENROUTER_API_KEY"] = "sk-or-v1-testtesttesttest"
        try: r = await ProviderGateway(cfg.SettingsStore(Path(tempfile.mkdtemp()) / "s.json"), {"openrouter": P()}).test("openrouter"); self.assertEqual(r["kind"], "auth")
        finally: os.environ.pop("OPENROUTER_API_KEY")


class TestSentences(unittest.TestCase):
    def test_splitting(self):
        self.assertEqual(split_sentences("Hello there my friend. How are", True), (["Hello there my friend."], "How are"))
        self.assertEqual(split_sentences("Hi. Ok. Now we continue talking here. Done", True)[0], ["Hi. Ok. Now we continue talking here."])
        self.assertEqual(split_sentences("tail without end", True, final=True), (["tail without end"], ""))
        self.assertEqual(split_sentences("اردو جملہ مکمل ہے۔ اگلا", True)[0], ["اردو جملہ مکمل ہے۔"])
        long = "word " * 80; out, rest = split_sentences(long, False); self.assertTrue(out and all(len(x) <= 260 for x in out))
        self.assertEqual(split_sentences("Version 3.5 is out now. Next", True)[0], ["Version 3.5 is out now."])


class SlowSynth(FakeSynth):
    def __init__(self, delays): super().__init__(); self.delays, self.n = delays, 0
    async def synth(self, text, language, voice="", **_):
        d = self.delays[self.n % len(self.delays)]; self.n += 1; await asyncio.sleep(d); return text.encode(), "audio/mpeg"


class TestPipeline(unittest.IsolatedAsyncioTestCase):
    async def run_pipe(self, synth, chunks, **kw):
        got, errs = [], []
        async def emit(seq, audio, mime, text, last): got.append((seq, text, last))
        async def err(m): errs.append(m)
        p = SpeechPipeline(synth, "en", "", emit, err, **kw)
        for c in chunks: p.feed(c)
        await p.finish(); return got, errs

    async def test_in_order_even_if_later_sentence_finishes_first(self):
        got, _ = await self.run_pipe(SlowSynth([0.15, 0.01, 0.01]), ["First sentence is long enough. ", "Second sentence is also long enough. ", "Third one ends the answer here."])
        self.assertEqual([g[0] for g in got], [0, 1, 2, 3]); self.assertEqual([g[2] for g in got], [False, False, False, True]); self.assertTrue(got[0][1].startswith("First"))

    async def test_nothing_to_say_emits_nothing(self):
        got, _ = await self.run_pipe(FakeSynth(), ["   ", "```"]); self.assertEqual(got, [])

    async def test_synth_failure_reported_once_and_stops(self):
        class Bad(FakeSynth):
            async def synth(self, *a, **k): raise ProviderError("tts down", "network")
        got, errs = await self.run_pipe(Bad(), ["One sentence that is long enough. ", "Another sentence that is long enough. "])
        self.assertEqual(got, []); self.assertEqual(errs, ["tts down"])

    async def test_cancel_stops_everything(self):
        got, errs = [], []
        async def emit(*a): got.append(a)
        async def err(m): errs.append(m)
        p = SpeechPipeline(SlowSynth([5]), "en", "", emit, err); p.feed("A long enough sentence to speak now. "); await asyncio.sleep(0.05); p.cancel(); await asyncio.sleep(0.05)
        self.assertEqual(got, [])


class TestServiceSpeed(unittest.IsolatedAsyncioTestCase):
    async def test_speech_starts_before_model_finishes(self):
        """The first sentence must be sent to the speaker while the model is still generating the rest."""
        svc, _ = make([[text("The first sentence is ready now. "), text("Second part arrives later on. "), text("And a third.")]], delay=0.25)
        ev = collect(svc.bus); await svc.start(); await svc.handle_text("go")
        self.assertTrue(await wait_for(lambda: any(e["type"] == "audio" for e in ev()), 3))
        evs = ev(); first_audio = next(i for i, e in enumerate(evs) if e["type"] == "audio")
        self.assertFalse(any(e["type"] == "response_final" for e in evs[:first_audio]), "audio must precede the final response event")
        self.assertEqual(svc.state.state, State.SPEAKING); await svc.stop("t"); await svc.shutdown()

    async def test_tool_call_after_speech_keeps_working(self):
        from tests.fakes import call
        svc, _ = make([[text("Let me calculate that for you. "), call("calculator", {"expression": "2+2"})], [text("The answer is four.")]])
        ev = collect(svc.bus); await svc.start(); await svc.handle_text("please run the calculator tool for me")
        self.assertTrue(await wait_for(lambda: any(e["type"] == "response_final" for e in ev()), 3))
        evs = ev(); self.assertTrue([e for e in evs if e["type"] == "tool_result" and e["ok"]]); self.assertIn("EXECUTING", states(evs))
        await svc.speech_finished(); self.assertTrue(await wait_for(lambda: svc.state.state == State.STANDBY)); await svc.shutdown()

    async def test_tts_failure_never_blocks_the_text_answer(self):
        svc, _ = make([[text("Here is a perfectly good text answer.")]], synth_ok=False)
        ev = collect(svc.bus); await svc.start(); await svc.handle_text("hi")
        self.assertTrue(await wait_for(lambda: svc.state.state == State.STANDBY and any(e["type"] == "response_final" for e in ev()), 3)); await svc.shutdown()

    async def test_stop_mid_speech_cancels_pipeline(self):
        svc, _ = make([[text("A long enough first sentence to speak. "), text("More text keeps coming for a while. ")]], delay=0.2)
        await svc.start(); await svc.handle_text("go"); await wait_for(lambda: svc.state.state == State.SPEAKING, 3)
        await svc.stop("button"); self.assertEqual(svc.state.state, State.STANDBY); self.assertIsNone(svc._pipe); await svc.shutdown()

if __name__ == "__main__":
    unittest.main()
