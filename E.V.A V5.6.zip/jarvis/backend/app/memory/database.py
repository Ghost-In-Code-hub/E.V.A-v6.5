"""SQLite conversation memory (stdlib sqlite3). No raw audio, webcam frames or secrets are stored."""
from __future__ import annotations

import sqlite3
import threading
import time
import uuid
from pathlib import Path

from ..core.security import redact

SCHEMA = """
CREATE TABLE IF NOT EXISTS conversations(id TEXT PRIMARY KEY, title TEXT, created REAL, updated REAL);
CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT, conv_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    role TEXT NOT NULL, content TEXT NOT NULL, tool_calls TEXT, tool_call_id TEXT, name TEXT, ts REAL);
CREATE INDEX IF NOT EXISTS idx_msg_conv ON messages(conv_id, id);
CREATE TABLE IF NOT EXISTS preferences(key TEXT PRIMARY KEY, value TEXT NOT NULL, ts REAL);
"""


class Memory:
    def __init__(self, path: str | Path, enabled: bool = True, retention_days: int = 30):
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self.enabled, self.retention_days = enabled, retention_days
        self._lock = threading.Lock()
        self._db = sqlite3.connect(self.path, check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        self._db.execute("PRAGMA foreign_keys=ON")
        self._db.executescript(SCHEMA)

    def close(self): self._db.close()

    def configure(self, enabled: bool, retention_days: int):
        self.enabled, self.retention_days = enabled, retention_days

    def create_conversation(self, title: str = "New conversation") -> str:
        cid = uuid.uuid4().hex[:12]
        now = time.time()
        with self._lock, self._db:
            self._db.execute("INSERT INTO conversations VALUES(?,?,?,?)", (cid, title, now, now))
        return cid

    def add_message(self, conv_id: str, role: str, content: str, *, tool_calls=None, tool_call_id=None, name=None):
        if not self.enabled:
            return
        import json
        with self._lock, self._db:
            self._db.execute("INSERT INTO messages(conv_id,role,content,tool_calls,tool_call_id,name,ts) VALUES(?,?,?,?,?,?,?)",
                             (conv_id, role, redact(content), json.dumps(tool_calls) if tool_calls else None,
                              tool_call_id, name, time.time()))
            self._db.execute("UPDATE conversations SET updated=? WHERE id=?", (time.time(), conv_id))
            if role == "user":
                r = self._db.execute("SELECT title FROM conversations WHERE id=?", (conv_id,)).fetchone()
                if r and r["title"] == "New conversation":
                    self._db.execute("UPDATE conversations SET title=? WHERE id=?", (redact(content)[:60], conv_id))

    def messages(self, conv_id: str, limit: int = 40) -> list[dict]:
        import json
        with self._lock:
            rows = self._db.execute("SELECT * FROM (SELECT * FROM messages WHERE conv_id=? ORDER BY id DESC LIMIT ?) ORDER BY id",
                                    (conv_id, limit)).fetchall()
        out = []
        for r in rows:
            m = {"role": r["role"], "content": r["content"]}
            if r["tool_calls"]: m["tool_calls"] = json.loads(r["tool_calls"])
            if r["tool_call_id"]: m["tool_call_id"] = r["tool_call_id"]
            if r["name"]: m["name"] = r["name"]
            out.append(m)
        # never start a context window in the middle of a tool exchange
        while out and out[0]["role"] == "tool":
            out.pop(0)
        return out

    def list_conversations(self, limit: int = 50) -> list[dict]:
        with self._lock:
            return [dict(r) for r in self._db.execute("SELECT * FROM conversations ORDER BY updated DESC LIMIT ?", (limit,))]

    def delete_conversation(self, conv_id: str) -> bool:
        with self._lock, self._db:
            return self._db.execute("DELETE FROM conversations WHERE id=?", (conv_id,)).rowcount > 0

    def delete_all(self) -> None:
        with self._lock, self._db:
            self._db.execute("DELETE FROM conversations"); self._db.execute("DELETE FROM preferences")

    def search(self, query: str, limit: int = 8) -> list[dict]:
        like = f"%{query.replace('%', '').replace('_', '')}%"
        with self._lock:
            rows = self._db.execute("SELECT conv_id, role, content, ts FROM messages WHERE role IN ('user','assistant') AND content LIKE ? ORDER BY id DESC LIMIT ?", (like, limit)).fetchall()
        return [dict(r) for r in rows]

    def set_preference(self, key: str, value: str) -> bool:
        if not self.enabled: return False
        with self._lock, self._db:
            self._db.execute("INSERT INTO preferences VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, ts=excluded.ts",
                             (key[:80], redact(value)[:500], time.time()))
        return True

    def preferences(self) -> dict[str, str]:
        with self._lock:
            return {r["key"]: r["value"] for r in self._db.execute("SELECT key,value FROM preferences")}

    def purge_expired(self) -> int:
        if self.retention_days <= 0: return 0
        cutoff = time.time() - self.retention_days * 86400
        with self._lock, self._db:
            return self._db.execute("DELETE FROM conversations WHERE updated < ?", (cutoff,)).rowcount
