"""WhatsApp integration. Two independent paths:
  1. Official WhatsApp Business Cloud API  (needs WHATSAPP_TOKEN + WHATSAPP_PHONE_NUMBER_ID; recipient must be a phone number)
  2. Browser: an existing, user-authorised WhatsApp Web session in the controlled browser profile.
Sending is a two-step flow: *prepare* (nothing is sent) then *send_prepared* which ALWAYS asks the user to
approve the exact recipient + text. Ambiguous contacts are never sent to."""
from __future__ import annotations

import os
import re
import uuid

from ..computer.browser_agent import BrowserError
from .registry import Tool, ToolContext, result

PREPARED: dict[str, dict] = {}
PHONE_RE = re.compile(r"^\+?[0-9]{7,15}$")


def cloud_status() -> dict:
    t, p = bool(os.environ.get("WHATSAPP_TOKEN")), bool(os.environ.get("WHATSAPP_PHONE_NUMBER_ID"))
    return {"cloud_api_configured": t and p, "missing": [n for n, ok in (("WHATSAPP_TOKEN", t), ("WHATSAPP_PHONE_NUMBER_ID", p)) if not ok]}


async def _status(a, ctx):
    st = cloud_status()
    br = ctx.services.get("browser")
    web_ok = bool(br and br.available()[0])
    return result(True, f"Cloud API: {'configured' if st['cloud_api_configured'] else 'NOT configured (missing ' + ', '.join(st['missing']) + ')'}. "
                        f"WhatsApp Web via browser: {'available' if web_ok else 'unavailable (Playwright missing)'}; requires you to be already logged in.", **st)


async def _prepare(a, ctx):
    contact, message = a["contact"].strip(), a["message"].strip()
    if not message: return result(False, "Message is empty.")
    mode = a.get("channel", "web")
    if mode == "cloud":
        if not cloud_status()["cloud_api_configured"]:
            return result(False, f"WhatsApp Cloud API is not configured (missing {', '.join(cloud_status()['missing'])}).", code="not_configured")
        if not PHONE_RE.match(contact.replace(" ", "")):
            return result(False, "The Cloud API needs a phone number in international format (e.g. +923001234567).", code="bad_recipient")
        recipient = contact.replace(" ", "")
    else:
        br = ctx.services["browser"]
        try:
            await br.open_url("https://web.whatsapp.com/")
            page = br.page
            if await page.get_by_role("textbox", name=re.compile("search", re.I)).count() == 0:
                return result(False, "WhatsApp Web is not logged in. Scan the QR code in the opened browser window, then ask again.", code="not_logged_in")
            box = page.get_by_role("textbox", name=re.compile("search", re.I)).first
            await box.fill(contact)
            await page.wait_for_timeout(1500)
            rows = page.locator("[role='listitem'], [role='row']")
            n = await rows.count()
            names = []
            for i in range(min(n, 8)):
                t = (await rows.nth(i).inner_text()).split("\n")[0].strip()
                if t: names.append((i, t))
        except BrowserError as e:
            return result(False, str(e), code="action_failed")
        exact = [x for x in names if x[1].lower() == contact.lower()]
        if len(exact) != 1:
            cand = ", ".join(t for _, t in names[:6]) or "none"
            return result(False, f"Cannot choose a unique recipient for '{contact}'. Candidates: {cand}. Ask the user which one; nothing was prepared.", code="ambiguous_contact")
        recipient = exact[0][1]
        await rows.nth(exact[0][0]).click()
        await page.wait_for_timeout(800)
        compose = page.get_by_role("textbox", name=re.compile("type a message|message", re.I)).last
        await compose.fill(message)
        if (await compose.inner_text()).strip() != message:
            return result(False, "Could not place the message in the compose box.", code="verify_failed")
    mid = uuid.uuid4().hex[:8]
    PREPARED[mid] = {"channel": mode, "recipient": recipient, "message": message}
    return result(True, f"Prepared message {mid} to '{recipient}' via {mode}. NOT SENT. Call whatsapp_send_prepared to request the user's approval.", message_id=mid)


def _confirm_send(a):
    p = PREPARED.get(a.get("message_id", ""))
    if not p: return "Send WhatsApp message?"
    return f"SEND WhatsApp message to {p['recipient']}:\n\"{p['message'][:300]}\""


async def _send(a, ctx):
    p = PREPARED.pop(a["message_id"], None)
    if not p: return result(False, "Unknown or already-used message_id. Prepare the message again.", code="unknown_message")
    if p["channel"] == "cloud":
        import httpx
        url = f"https://graph.facebook.com/v21.0/{os.environ['WHATSAPP_PHONE_NUMBER_ID']}/messages"
        try:
            async with httpx.AsyncClient(timeout=30) as c:
                r = await c.post(url, headers={"Authorization": f"Bearer {os.environ['WHATSAPP_TOKEN']}"},
                                 json={"messaging_product": "whatsapp", "to": p["recipient"].lstrip("+"), "type": "text", "text": {"body": p["message"]}})
        except httpx.HTTPError as e:
            return result(False, f"Network error while sending; delivery status is UNKNOWN: {type(e).__name__}", code="uncertain")
        if r.status_code >= 400:
            return result(False, f"WhatsApp API rejected the message ({r.status_code}): {r.text[:200]}", code="api_error")
        return result(True, f"WhatsApp API accepted the message for {p['recipient']} (accepted by the API, not necessarily delivered).", verified=True)
    br = ctx.services["browser"]
    page = br.page
    compose = page.get_by_role("textbox", name=re.compile("type a message|message", re.I)).last
    if (await compose.inner_text()).strip() != p["message"]:
        return result(False, "Compose box content changed since preparation; not sent.", code="verify_failed")
    await compose.press("Enter")
    await page.wait_for_timeout(1500)
    still = (await compose.inner_text()).strip()
    if still:
        return result(False, "The message text is still in the compose box; sending is UNCERTAIN.", code="uncertain")
    return result(True, f"Message sent to {p['recipient']}: compose box cleared (delivery ticks not verified).", verified=True)


def tools() -> list[Tool]:
    obj = lambda p, r: {"type": "object", "properties": p, "required": r}
    s = {"type": "string"}
    return [
        Tool("whatsapp_status", "Report the real configuration status of the WhatsApp integrations.", obj({}, []), _status, "whatsapp"),
        Tool("whatsapp_prepare_message", "Resolve a contact and stage a WhatsApp message WITHOUT sending it. channel: 'web' (existing WhatsApp Web session) or 'cloud' (Business API, phone number required).",
             obj({"contact": s, "message": s, "channel": {"type": "string", "enum": ["web", "cloud"]}}, ["contact", "message"]), _prepare, "whatsapp", idempotent=False, read_only=False, timeout=60),
        Tool("whatsapp_send_prepared", "Send a previously prepared message. The user is always asked to approve recipient and text first.",
             obj({"message_id": s}, ["message_id"]), _send, "whatsapp", confirm=_confirm_send, idempotent=False, read_only=False, timeout=60),
    ]
