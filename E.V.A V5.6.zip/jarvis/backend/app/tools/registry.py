"""Explicit tool registry. The model can only call what is registered here, and every call passes
through: estop -> schema validation -> capability permission -> confirmation -> duplicate guard ->
timeout -> audit. There is deliberately NO generic shell tool."""
from __future__ import annotations

import asyncio
import hashlib
import json
import re
import time
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

RISKY_WORDS = re.compile(
    r"\b(send|submit|buy|purchase|pay|order|checkout|check out|delete|remove|confirm|transfer|post|publish|"
    r"sign out|log out|unsubscribe|save changes|install|grant|allow|deactivate|close account)\b", re.I)


@dataclass
class Tool:
    name: str
    description: str
    parameters: dict
    handler: Callable[[dict, "ToolContext"], Awaitable[dict]]
    capability: str = "none"          # none | files | browser | desktop | apps | whatsapp | memory
    confirm: Callable[[dict], str | None] | bool = False   # True=always, callable=returns prompt or None
    timeout: float = 30.0
    idempotent: bool = True            # non-idempotent calls are duplicate-guarded
    read_only: bool = True

    def spec(self) -> dict:
        return {"name": self.name, "description": self.description, "parameters": self.parameters}


@dataclass
class ToolContext:
    settings: Any
    audit: Any = None
    confirm: Callable[[str, dict], Awaitable[bool]] | None = None
    progress: Callable[[str], Awaitable[None]] | None = None
    services: dict = field(default_factory=dict)   # browser, desktop, memory, whatsapp, request_stop...
    cancel: asyncio.Event | None = None


def result(ok: bool, summary: str, **extra) -> dict:
    return {"ok": ok, "summary": summary, **extra}


_TYPES = {"string": str, "integer": int, "number": (int, float), "boolean": bool, "array": list, "object": dict}


def validate_args(schema: dict, args: dict) -> str | None:
    if not isinstance(args, dict):
        return "Arguments must be an object"
    props = schema.get("properties", {})
    for r in schema.get("required", []):
        if r not in args:
            return f"Missing required argument '{r}'"
    for k, v in args.items():
        if k not in props:
            return f"Unknown argument '{k}'"
        t = props[k].get("type")
        if t and not (isinstance(v, _TYPES[t]) and not (t in ("integer", "number") and isinstance(v, bool))):
            return f"Argument '{k}' must be of type {t}"
        if "enum" in props[k] and v not in props[k]["enum"]:
            return f"Argument '{k}' must be one of {props[k]['enum']}"
        if t == "string" and len(v) > 20000:
            return f"Argument '{k}' is too long"
    return None


def capability_allowed(settings, cap: str) -> tuple[bool, str]:
    c = settings["computer"]
    if cap == "none":
        return True, ""
    if cap == "memory":
        return (True, "") if settings["memory"]["enabled"] else (False, "Memory is disabled in settings")
    if not c["enabled"]:
        return False, "Computer control is disabled. Enable it in Settings > Computer control."
    flag = {"files": "files_enabled", "browser": "browser_enabled", "desktop": "desktop_enabled",
            "apps": "desktop_enabled", "whatsapp": "whatsapp_enabled"}.get(cap)
    if flag and not c[flag]:
        return False, f"The '{cap}' capability is disabled in Settings > Computer control."
    return True, ""


class ToolRegistry:
    def __init__(self, settings) -> None:
        self.settings = settings
        self._tools: dict[str, Tool] = {}
        self._recent: dict[str, float] = {}
        self.estop = False

    def register(self, tool: Tool) -> None:
        if tool.name in self._tools:
            raise ValueError(f"Duplicate tool {tool.name}")
        self._tools[tool.name] = tool

    def names(self) -> list[str]:
        return sorted(self._tools)

    def get(self, name: str) -> Tool | None:
        return self._tools.get(name)

    def specs(self, available_only: bool = True) -> list[dict]:
        """Tool specs offered to the model. Disabled capabilities are not offered at all."""
        return [t.spec() for t in self._tools.values()
                if not available_only or capability_allowed(self.settings, t.capability)[0]]

    def trigger_estop(self) -> None:
        self.estop = True

    def clear_estop(self) -> None:
        self.estop = False

    async def execute(self, name: str, args: dict, ctx: ToolContext) -> dict:
        tool = self._tools.get(name)
        audit = ctx.audit.write if ctx.audit else (lambda *a, **k: None)
        if not tool:
            return result(False, f"Unknown tool '{name}'. It is not in the registry.", code="unknown_tool")
        if self.estop:
            return result(False, "Emergency stop is active. No actions will be performed.", code="estop")
        err = validate_args(tool.parameters, args)
        if err:
            return result(False, f"Invalid arguments: {err}", code="invalid_args")
        ok, why = capability_allowed(self.settings, tool.capability)
        if not ok:
            audit("tool_denied", tool=name, reason=why)
            return result(False, why, code="permission_denied")

        prompt = None
        if tool.confirm is True:
            prompt = f"Allow Jarvis to run '{name}'?"
        elif callable(tool.confirm):
            prompt = tool.confirm(args)
        if prompt is None and self.settings["computer"]["confirm_all_actions"] and not tool.read_only:
            prompt = f"Allow Jarvis to run '{name}'?"
        if prompt:
            if not ctx.confirm:
                return result(False, "This action requires confirmation but no confirmation channel is available.", code="no_confirm")
            approved = await ctx.confirm(prompt, {"tool": name, "arguments": args})
            audit("confirmation", tool=name, approved=approved, prompt=prompt)
            if not approved:
                return result(False, "The user declined this action. Do not retry it.", code="declined")
            if self.estop:
                return result(False, "Emergency stop is active.", code="estop")

        if not tool.idempotent:
            key = name + hashlib.sha1(json.dumps(args, sort_keys=True, default=str).encode()).hexdigest()
            now = time.monotonic()
            if now - self._recent.get(key, -1e9) < 5.0:
                return result(False, "Duplicate action suppressed: the identical action was just performed.", code="duplicate")
            self._recent[key] = now
            self._recent = {k: v for k, v in self._recent.items() if now - v < 60}

        audit("tool_call", tool=name, arguments=args)
        try:
            res = await asyncio.wait_for(tool.handler(args, ctx), timeout=tool.timeout)
        except asyncio.TimeoutError:
            res = result(False, f"Tool '{name}' timed out after {tool.timeout:.0f}s", code="timeout")
        except asyncio.CancelledError:
            audit("tool_cancelled", tool=name)
            raise
        except Exception as e:  # tool bugs must not crash the assistant
            res = result(False, f"Tool '{name}' failed: {type(e).__name__}: {str(e)[:300]}", code="exception")
        audit("tool_result", tool=name, ok=res.get("ok"), summary=res.get("summary", "")[:500])
        return res
