from __future__ import annotations

import os
from pathlib import Path

from ..core.security import path_allowed
from .registry import Tool, ToolContext, result

MAX_READ = 200_000


def _p(ctx: ToolContext, raw: str):
    dirs = ctx.settings["computer"]["allowed_dirs"]
    if not dirs:
        return None, "No allowed directories are configured. Add one in Settings > Computer control."
    p = path_allowed(raw, dirs)
    return (p, "") if p else (None, "That path is outside the allowed directories.")


async def _read(args, ctx):
    p, why = _p(ctx, args["path"])
    if not p: return result(False, why, code="path_denied")
    if not p.is_file(): return result(False, f"Not a file: {p.name}")
    data = p.read_bytes()[:MAX_READ]
    try: text = data.decode("utf-8")
    except UnicodeDecodeError: return result(False, "File is not UTF-8 text.")
    return result(True, f"<untrusted_file_content path='{p.name}'>\n{text}\n</untrusted_file_content>", truncated=p.stat().st_size > MAX_READ)


async def _ls(args, ctx):
    p, why = _p(ctx, args["path"])
    if not p: return result(False, why, code="path_denied")
    if not p.is_dir(): return result(False, "Not a directory.")
    items = sorted(os.listdir(p))[:200]
    return result(True, "\n".join(("[dir] " if (p / i).is_dir() else "") + i for i in items) or "(empty)")


def _confirm_write(args):
    return f"Write {len(args.get('content',''))} characters to {args.get('path')}" + (" (this will OVERWRITE an existing file)" if Path(args.get("path", "")).expanduser().exists() else "") + "?"


async def _write(args, ctx):
    p, why = _p(ctx, args["path"])
    if not p: return result(False, why, code="path_denied")
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(args["content"], encoding="utf-8")
    ok = p.exists() and p.read_text(encoding="utf-8") == args["content"]
    return result(ok, f"Wrote {p.name} and re-read it: {'content matches' if ok else 'MISMATCH'}.", verified=ok)


async def _delete(args, ctx):
    p, why = _p(ctx, args["path"])
    if not p: return result(False, why, code="path_denied")
    if not p.is_file(): return result(False, "Only single files can be deleted (not folders).")
    p.unlink()
    return result(not p.exists(), f"Deleted {p.name}." if not p.exists() else "Delete failed.", verified=not p.exists())


def tools() -> list[Tool]:
    s = lambda **k: {"type": "object", "properties": {a: {"type": "string"} for a in k}, "required": list(k)}
    return [
        Tool("read_file", "Read a UTF-8 text file inside an allowed directory.", s(path=1), _read, capability="files"),
        Tool("list_directory", "List a directory inside an allowed directory.", s(path=1), _ls, capability="files"),
        Tool("write_file", "Create or overwrite a text file inside an allowed directory. Requires user confirmation.",
             s(path=1, content=1), _write, capability="files", confirm=_confirm_write, idempotent=False, read_only=False),
        Tool("delete_file", "Delete a single file inside an allowed directory. Requires user confirmation.",
             s(path=1), _delete, capability="files", confirm=lambda a: f"PERMANENTLY DELETE {a.get('path')}?", idempotent=False, read_only=False),
    ]
