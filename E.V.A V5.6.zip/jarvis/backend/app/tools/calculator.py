from __future__ import annotations

import ast
import math
import operator as op

from .registry import Tool, ToolContext, result

_BIN = {ast.Add: op.add, ast.Sub: op.sub, ast.Mult: op.mul, ast.Div: op.truediv, ast.FloorDiv: op.floordiv,
        ast.Mod: op.mod, ast.Pow: op.pow}
_UN = {ast.UAdd: op.pos, ast.USub: op.neg}
_FUNCS = {"sqrt": math.sqrt, "sin": math.sin, "cos": math.cos, "tan": math.tan, "log": math.log, "log10": math.log10,
          "exp": math.exp, "abs": abs, "round": round, "floor": math.floor, "ceil": math.ceil, "min": min, "max": max}
_CONST = {"pi": math.pi, "e": math.e}


def safe_eval(expr: str) -> float:
    if len(expr) > 300:
        raise ValueError("Expression too long")

    def ev(n):
        if isinstance(n, ast.Expression): return ev(n.body)
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)) and not isinstance(n.value, bool): return n.value
        if isinstance(n, ast.BinOp) and type(n.op) in _BIN:
            a, b = ev(n.left), ev(n.right)
            if isinstance(n.op, ast.Pow) and abs(b) > 1000: raise ValueError("Exponent too large")
            return _BIN[type(n.op)](a, b)
        if isinstance(n, ast.UnaryOp) and type(n.op) in _UN: return _UN[type(n.op)](ev(n.operand))
        if isinstance(n, ast.Name) and n.id in _CONST: return _CONST[n.id]
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in _FUNCS and not n.keywords:
            return _FUNCS[n.func.id](*[ev(a) for a in n.args])
        raise ValueError("Unsupported expression")

    return ev(ast.parse(expr.strip().replace("^", "**"), mode="eval"))


async def _calc(args, ctx: ToolContext):
    try:
        v = safe_eval(args["expression"])
    except ZeroDivisionError:
        return result(False, "Division by zero")
    except (ValueError, SyntaxError, TypeError, OverflowError) as e:
        return result(False, f"Cannot evaluate: {e}")
    return result(True, f"{args['expression']} = {v:g}" if isinstance(v, float) else f"{args['expression']} = {v}", value=v)


async def _now(args, ctx):
    import datetime as dt
    n = dt.datetime.now().astimezone()
    return result(True, n.strftime("%A, %d %B %Y, %H:%M:%S %Z"), iso=n.isoformat())


def tools() -> list[Tool]:
    return [
        Tool("calculator", "Evaluate an arithmetic expression exactly. Supports + - * / // % ** ( ), sqrt, sin, cos, tan, log, exp, pi, e.",
             {"type": "object", "properties": {"expression": {"type": "string"}}, "required": ["expression"]}, _calc),
        Tool("get_datetime", "Get the current local date and time.", {"type": "object", "properties": {}}, _now),
    ]
