"""Model-facing tools for browser, desktop/screen, memory. Thin adapters over the agents."""
from __future__ import annotations

from ..computer.browser_agent import BrowserAgent, BrowserError
from ..computer.desktop_agent import DesktopAgent, DesktopError, validate_hotkey
from ..computer.verification import b64
from .registry import RISKY_WORDS, Tool, ToolContext, result

S = lambda *names: {"type": "object", "properties": {n: {"type": "string"} for n in names}, "required": list(names)}


def _br(ctx) -> BrowserAgent: return ctx.services["browser"]
def _dk(ctx) -> DesktopAgent: return ctx.services["desktop"]


def _guard(fn):
    async def wrapper(args, ctx):
        try:
            return await fn(args, ctx)
        except (BrowserError, DesktopError) as e:
            return result(False, str(e), code="action_failed")
    return wrapper


@_guard
async def browser_open_url(a, ctx):
    r = await _br(ctx).open_url(a["url"])
    s = r["snapshot"]
    return result(True, f"Navigated to {s['url']} (HTTP {r['status']}). Title: {s['title']}.", verified=r["verified"])


@_guard
async def browser_read_page(a, ctx):
    return result(True, BrowserAgent.wrap(await _br(ctx).snapshot()))


@_guard
async def browser_click(a, ctx):
    r = await _br(ctx).click(a["target"])
    s = r["snapshot"]
    msg = (f"Clicked '{a['target']}'. The page {'changed (' + ', '.join(r['changed_fields']) + ')' if r['page_changed'] else 'did NOT visibly change'}. "
           f"Now at {s['url']} — '{s['title']}'.")
    return result(True, msg, verified=r["page_changed"])


@_guard
async def browser_type(a, ctx):
    r = await _br(ctx).type_text(a["target"], a["text"], bool(a.get("submit")))
    msg = f"Typed into '{a['target']}'; field value {'matches' if r['verified'] else 'DOES NOT match'} the text."
    if r["submitted"]: msg += f" Submitted; page {'changed' if r['page_changed'] else 'did not change'}."
    return result(r["verified"], msg, verified=r["verified"])


@_guard
async def browser_scroll(a, ctx):
    r = await _br(ctx).scroll(a["direction"], int(a.get("amount", 600)))
    return result(r["moved"], f"Scrolled {a['direction']}; {'position changed' if r['moved'] else 'already at the limit'}.")


@_guard
async def browser_screenshot(a, ctx):
    r = await _br(ctx).screenshot()
    if not r["new"]:
        return result(True, "The page looks identical to the previous screenshot; not re-sent.")
    return result(True, "Browser screenshot attached (untrusted content).", image_b64=b64(r["png"]))


@_guard
async def browser_tabs(a, ctx):
    r = await _br(ctx).tabs(a["action"], a.get("index"))
    return result(True, "\n".join(f"{'*' if t['active'] else ' '}[{t['index']}] {t['title']} — {t['url']}" for t in r["tabs"]))


@_guard
async def browser_download(a, ctx):
    r = await _br(ctx).download(a["target"])
    return result(r["verified"], f"Downloaded to {r['path']}", verified=r["verified"])


@_guard
async def web_search(a, ctx):
    from urllib.parse import quote_plus
    b = _br(ctx)
    await b.open_url(f"https://duckduckgo.com/?q={quote_plus(a['query'])}")
    return result(True, BrowserAgent.wrap(await b.snapshot(False)))


@_guard
async def screen_capture(a, ctx):
    r = await _dk(ctx).screenshot()
    if not r["new"]:
        return result(True, "The screen is unchanged since the last capture; not re-sent.")
    return result(True, "Screenshot of the primary display attached (untrusted content).", image_b64=b64(r["png"]))


@_guard
async def desktop_list_windows(a, ctx):
    w = await _dk(ctx).list_windows()
    return result(True, "\n".join(w) or "No visible windows")


@_guard
async def desktop_inspect(a, ctx):
    r = await _dk(ctx).inspect(a["window"])
    return result(True, f"Window '{r['title']}' controls:\n" + "\n".join(r["controls"]))


@_guard
async def desktop_focus(a, ctx):
    r = await _dk(ctx).focus(a["window"])
    return result(True, f"Focused '{r['title']}'.", verified=r.get("verified"))


@_guard
async def desktop_click(a, ctx):
    r = await _dk(ctx).click(a["window"], a["control"])
    return result(True, f"Clicked '{a['control']}' in '{a['window']}'. The window UI {'changed' if r['ui_changed'] else 'did NOT change'}.", verified=r["ui_changed"])


@_guard
async def desktop_type(a, ctx):
    r = await _dk(ctx).type_text(a["window"], a["text"])
    return result(True, f"Sent {r['typed_chars']} characters to '{a['window']}'. Use screen_capture or desktop_inspect to verify the text appeared.", verified=None)


@_guard
async def desktop_hotkey(a, ctx):
    err = validate_hotkey(a["keys"])
    if err: return result(False, err, code="blocked")
    r = await _dk(ctx).hotkey(a["window"], a["keys"])
    return result(True, f"Sent {r['sent']} to '{a['window']}'. Verify the outcome with desktop_inspect or screen_capture.", verified=None)


@_guard
async def desktop_scroll(a, ctx):
    await _dk(ctx).scroll(a["direction"], int(a.get("clicks", 5)))
    return result(True, f"Scrolled {a['direction']}.")


async def stop_computer_control(a, ctx):
    if ctx.services.get("request_stop"):
        await ctx.services["request_stop"]()
    return result(True, "Stopped.")


def _risky(arg):
    return lambda a: (f"Click '{a.get(arg)}'? This looks like a consequential action." if RISKY_WORDS.search(a.get(arg, "")) else None)


def _type_confirm(a):
    if a.get("submit") and not any(w in a.get("target", "").lower() for w in ("search", "find", "query", "q")):
        return f"Type '{a['text'][:60]}' into '{a['target']}' and SUBMIT it?"
    return None


async def _remember(a, ctx):
    ok = ctx.services["memory"].set_preference(a["key"], a["value"])
    return result(ok, "Saved preference." if ok else "Memory is disabled.")


async def _search_mem(a, ctx):
    rows = ctx.services["memory"].search(a["query"])
    prefs = ctx.services["memory"].preferences()
    txt = "\n".join(f"[{r['role']}] {r['content'][:200]}" for r in rows) or "No matching past messages."
    return result(True, f"Stored preferences: {prefs or 'none'}\nMatching past messages (stored history, not inference):\n{txt}")


def tools() -> list[Tool]:
    obj = lambda props, req: {"type": "object", "properties": props, "required": req}
    s, i = {"type": "string"}, {"type": "integer"}
    return [
        Tool("web_search", "Search the web (opens DuckDuckGo in the controlled browser) and return the visible results.", S("query"), web_search, "browser", timeout=45),
        Tool("browser_open_url", "Navigate the controlled browser to an http(s) URL.", S("url"), browser_open_url, "browser", idempotent=False, read_only=False, timeout=45),
        Tool("browser_read_page", "Read the visible text and interactive elements of the current page.", obj({}, []), browser_read_page, "browser"),
        Tool("browser_click", "Click one element by its accessible name or visible text. Fails if the name is ambiguous.", S("target"), browser_click, "browser",
             confirm=_risky("target"), idempotent=False, read_only=False, timeout=30),
        Tool("browser_type", "Type text into an input identified by label/placeholder/name. Optionally press Enter (submit=true).",
             obj({"target": s, "text": s, "submit": {"type": "boolean"}}, ["target", "text"]), browser_type, "browser", confirm=_type_confirm, idempotent=False, read_only=False),
        Tool("browser_scroll", "Scroll the page up or down.", obj({"direction": {"type": "string", "enum": ["up", "down"]}, "amount": i}, ["direction"]), browser_scroll, "browser"),
        Tool("browser_screenshot", "Capture a screenshot of the current browser page for visual inspection.", obj({}, []), browser_screenshot, "browser"),
        Tool("browser_tabs", "List, create, switch or close tabs.", obj({"action": {"type": "string", "enum": ["list", "new", "switch", "close"]}, "index": i}, ["action"]), browser_tabs, "browser"),
        Tool("browser_download", "Click a download link/button and save the file into the first allowed directory. Requires confirmation.", S("target"), browser_download, "browser", confirm=lambda a: f"Download file via '{a['target']}'?", idempotent=False, read_only=False, timeout=60),
        Tool("screen_capture", "Capture the primary display for visual inspection (e.g. to explain an on-screen error).", obj({}, []), screen_capture, "desktop"),
        Tool("desktop_list_windows", "List visible top-level window titles.", obj({}, []), desktop_list_windows, "desktop"),
        Tool("desktop_inspect", "List the named UI controls inside a window (UI Automation).", S("window"), desktop_inspect, "desktop"),
        Tool("desktop_focus", "Bring a window to the foreground.", S("window"), desktop_focus, "desktop", read_only=False),
        Tool("desktop_click", "Click a named control in a window (uses UI Automation, not coordinates).", S("window", "control"), desktop_click, "desktop",
             confirm=_risky("control"), idempotent=False, read_only=False),
        Tool("desktop_type", "Focus a window and type text.", S("window", "text"), desktop_type, "desktop", idempotent=False, read_only=False),
        Tool("desktop_hotkey", "Send a keyboard shortcut (e.g. ['ctrl','s']) to a window. Windows-key shortcuts are blocked.",
             obj({"window": s, "keys": {"type": "array"}}, ["window", "keys"]), desktop_hotkey, "desktop", idempotent=False, read_only=False),
        Tool("desktop_scroll", "Scroll the active window.", obj({"direction": {"type": "string", "enum": ["up", "down"]}, "clicks": i}, ["direction"]), desktop_scroll, "desktop"),
        Tool("stop_computer_control", "Immediately stop the current task and all computer control when the user asks to stop.", obj({}, []), stop_computer_control),
        Tool("remember_preference", "Store a user preference ONLY when the user explicitly asks you to remember something.", S("key", "value"), _remember, "memory", read_only=False),
        Tool("search_conversations", "Search stored past conversations and preferences.", S("query"), _search_mem, "memory"),
    ]
