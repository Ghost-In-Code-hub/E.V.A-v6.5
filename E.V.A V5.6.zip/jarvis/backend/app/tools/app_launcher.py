from __future__ import annotations

import asyncio
import os
import shutil
import subprocess
from pathlib import Path

from .registry import Tool, ToolContext, result

_PF = [os.environ.get("ProgramFiles", r"C:\Program Files"), os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
       os.environ.get("LOCALAPPDATA", "")]

# name -> (executables on PATH, candidate absolute paths, expected window title regex)
BUILTIN = {
    "chrome": (["chrome"], [r"Google\Chrome\Application\chrome.exe"], r".*Chrome.*"),
    "edge": (["msedge"], [r"Microsoft\Edge\Application\msedge.exe"], r".*Edge.*"),
    "notepad": (["notepad"], [], r".*Notepad.*"),
    "calculator": (["calc"], [], r".*Calculator.*"),
    "vscode": (["code"], [r"Programs\Microsoft VS Code\Code.exe", r"Microsoft VS Code\Code.exe"], r".*Visual Studio Code.*"),
}


def resolve_app(name: str, user_apps: dict[str, str]) -> tuple[str | None, str]:
    """Return (executable path, window-title regex) or (None, reason). Never uses a shell."""
    key = name.strip().lower()
    if key in user_apps:
        p = user_apps[key]
        return (p, ".*") if Path(p).exists() or shutil.which(p) else (None, f"Configured path for '{key}' does not exist: {p}")
    if key not in BUILTIN:
        known = ", ".join(sorted(set(BUILTIN) | set(user_apps)))
        return None, f"'{name}' is not an approved application. Approved: {known}. Add more in Settings > Computer control."
    exes, cands, title = BUILTIN[key]
    for e in exes:
        w = shutil.which(e)
        if w: return w, title
    for base in _PF:
        for c in cands:
            p = Path(base) / c
            if base and p.exists(): return str(p), title
    return None, f"'{name}' is approved but was not found on this PC. Set its path in Settings > Computer control."


async def _open(args, ctx: ToolContext):
    path, info = resolve_app(args["name"], ctx.settings["computer"]["apps"])
    if not path:
        return result(False, info, code="not_found")
    try:
        proc = subprocess.Popen([path], shell=False, close_fds=True, stdin=subprocess.DEVNULL,  # noqa: S603
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)  # detached from our pipes
    except OSError as e:
        return result(False, f"Could not start {args['name']}: {e}", code="launch_failed")
    await asyncio.sleep(1.5)
    exited = proc.poll()
    desktop = ctx.services.get("desktop")
    if desktop and desktop.available()[0]:
        wins = await desktop.list_windows(info)
        if wins:
            return result(True, f"Opened {args['name']}; window found: '{wins[0]}'.", verified=True)
        return result(True, f"Started {args['name']} but no matching window was detected yet.", verified=False)
    if exited not in (None, 0):
        return result(False, f"{args['name']} exited immediately with code {exited}.", code="exited")
    return result(True, f"Started {args['name']} (process running; window not verified because desktop automation is unavailable).", verified=False)


async def _list(args, ctx):
    apps = {}
    for n in sorted(set(BUILTIN) | set(ctx.settings["computer"]["apps"])):
        p, why = resolve_app(n, ctx.settings["computer"]["apps"])
        apps[n] = {"found": bool(p), "detail": p or why}
    return result(True, "; ".join(f"{n}: {'found' if v['found'] else 'NOT FOUND'}" for n, v in apps.items()), apps=apps)


def tools() -> list[Tool]:
    return [
        Tool("open_application", "Open an approved desktop application by name (e.g. chrome, edge, notepad, calculator, vscode, or a user-configured app).",
             {"type": "object", "properties": {"name": {"type": "string"}}, "required": ["name"]}, _open,
             capability="apps", idempotent=False, read_only=False, timeout=20),
        Tool("list_applications", "List approved applications and whether each is installed.",
             {"type": "object", "properties": {}}, _list, capability="apps"),
    ]
