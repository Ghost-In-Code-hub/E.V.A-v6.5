"""Entry point: python -m app.run  (started by run.bat). Binds to localhost only."""
from __future__ import annotations

import atexit
import logging
import os
import sys

import uvicorn

from .core import config as cfg
from .main import create_app


def main() -> int:
    cfg.load_env()
    host = os.environ.get("JARVIS_HOST", "127.0.0.1")
    port = int(os.environ.get("JARVIS_PORT", "8765"))
    if host not in ("127.0.0.1", "localhost", "::1") and os.environ.get("JARVIS_ALLOW_REMOTE") != "1":
        print(f"Refusing to bind to {host}: Jarvis is localhost-only unless JARVIS_ALLOW_REMOTE=1.", file=sys.stderr)
        return 2
    cfg.DATA_DIR.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    pid = cfg.DATA_DIR / "backend.pid"
    pid.write_text(str(os.getpid()))
    atexit.register(lambda: pid.unlink(missing_ok=True))
    app = create_app(port=port)
    server = uvicorn.Server(uvicorn.Config(app, host=host, port=port, log_level="info", ws_max_size=1_000_000))
    app.state.server_should_exit = lambda: setattr(server, "should_exit", True)
    server.run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
