"""Webcam hand tracking (OpenCV + MediaPipe Hands) in a worker thread. Only runs while explicitly enabled.
Frames are processed in memory and never stored or sent anywhere. Gesture logic lives in gesture_classifier."""
from __future__ import annotations

import asyncio
import logging
import threading
import time

from .gesture_classifier import GestureConfig, GestureEngine

log = logging.getLogger("jarvis.vision")
MAX_FPS = 15


class HandTracker:
    def __init__(self, loop: asyncio.AbstractEventLoop, on_gesture, on_status):
        self.loop, self.on_gesture, self.on_status = loop, on_gesture, on_status
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self.engine = GestureEngine()

    @staticmethod
    def available() -> tuple[bool, str]:
        try:
            import cv2, mediapipe  # noqa: F401
            return True, ""
        except Exception as e:
            return False, f"OpenCV/MediaPipe not installed ({type(e).__name__}). Run setup.bat."

    @property
    def running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    def set_sensitivity(self, s: float):
        self.engine.cfg.sensitivity = s

    def start(self, camera_index: int, sensitivity: float) -> tuple[bool, str]:
        ok, why = self.available()
        if not ok: return False, why
        if self.running: return True, ""
        self.engine = GestureEngine(GestureConfig(sensitivity=sensitivity))
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, args=(camera_index,), name="hand-tracker", daemon=True)
        self._thread.start()
        return True, ""

    def stop(self):
        self._stop.set()
        if self._thread: self._thread.join(timeout=3)
        self._thread = None

    def _status(self, **kw):
        asyncio.run_coroutine_threadsafe(self.on_status(**kw), self.loop)

    def _run(self, idx: int):
        import cv2, mediapipe as mp
        cap = cv2.VideoCapture(idx, cv2.CAP_DSHOW) if hasattr(cv2, "CAP_DSHOW") else cv2.VideoCapture(idx)
        if not cap.isOpened():
            self._status(active=False, error=f"Camera {idx} could not be opened (in use, missing or blocked by Windows privacy settings).")
            return
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640); cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        hands = mp.solutions.hands.Hands(max_num_hands=1, model_complexity=0, min_detection_confidence=0.6, min_tracking_confidence=0.5)
        self._status(active=True, error=None)
        last = 0.0
        try:
            while not self._stop.is_set():
                ok, frame = cap.read()
                if not ok:
                    self._status(active=False, error="Camera stopped delivering frames."); return
                now = time.monotonic()
                if now - last < 1.0 / MAX_FPS: continue
                last = now
                res = hands.process(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
                lm = [(p.x, p.y) for p in res.multi_hand_landmarks[0].landmark] if res.multi_hand_landmarks else None
                d = self.engine.update(lm, now)
                if d: asyncio.run_coroutine_threadsafe(self.on_gesture(d), self.loop)
        except Exception as e:
            log.exception("hand tracker crashed")
            self._status(active=False, error=f"Hand tracking error: {type(e).__name__}")
        finally:
            hands.close(); cap.release()
            self._status(active=False, error=None)
