"""Volume control. Two distinct targets: Jarvis' own speech volume, or the Windows system endpoint."""
from __future__ import annotations

import logging

log = logging.getLogger("jarvis.volume")


class AssistantVolume:
    """Jarvis speech volume (0..1). The frontend applies it to a GainNode."""
    name = "assistant"

    def __init__(self, level: float = 0.9):
        self.level = level

    def get(self) -> float: return self.level
    def set(self, v: float) -> None: self.level = v


class WindowsSystemVolume:
    """Master volume of the default render endpoint via pycaw (Windows Core Audio)."""
    name = "system"

    def __init__(self):
        self._ep = None

    def available(self) -> tuple[bool, str]:
        try:
            import pycaw.pycaw  # noqa: F401
            return True, ""
        except Exception as e:
            return False, f"pycaw unavailable: {e}"

    def _endpoint(self):
        from comtypes import CLSCTX_ALL
        from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
        dev = AudioUtilities.GetSpeakers()
        iface = dev.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
        return iface.QueryInterface(IAudioEndpointVolume) if hasattr(iface, "QueryInterface") else iface

    def get(self) -> float:
        return float(self._endpoint().GetMasterVolumeLevelScalar())

    def set(self, v: float) -> None:
        self._endpoint().SetMasterVolumeLevelScalar(float(v), None)


class VolumeController:
    def __init__(self, assistant: AssistantVolume, system=None, target: str = "assistant", step: float = 0.1):
        self.assistant, self.system, self.target, self.step = assistant, system, target, step

    def _backend(self):
        if self.target == "system":
            if self.system is None:
                raise RuntimeError("System volume control is not available on this machine")
            return self.system
        return self.assistant

    def change(self, direction: str) -> dict:
        if direction not in ("up", "down"):
            raise ValueError("direction must be 'up' or 'down'")
        b = self._backend()
        before = b.get()
        after = round(min(1.0, max(0.0, before + (self.step if direction == "up" else -self.step))), 3)
        b.set(after)
        confirmed = b.get()  # re-read: report what the endpoint actually holds
        return {"target": b.name, "direction": direction, "before": round(before, 3), "level": round(confirmed, 3)}
