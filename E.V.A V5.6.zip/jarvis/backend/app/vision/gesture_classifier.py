"""Hand gesture classification from 21 MediaPipe-style landmarks (pure python/math, no camera needed).

Volume gestures: an OPEN PALM that moves deliberately UP or DOWN. A single frame never triggers anything:
the palm must be held open for `min_open_s`, travel >= threshold within a window, then a cooldown applies and
the engine disarms until the hand is steady again (or leaves the frame), so one sweep = one step."""
from __future__ import annotations

import math
from collections import deque
from dataclasses import dataclass

WRIST = 0
FINGERS = {"index": (8, 6), "middle": (12, 10), "ring": (16, 14), "pinky": (20, 18)}  # (tip, pip)
PALM_IDS = (0, 5, 9, 13, 17)


def _d(a, b) -> float:
    return math.hypot(a[0] - b[0], a[1] - b[1])


def finger_states(lm: list[tuple[float, float]]) -> dict[str, bool]:
    w = lm[WRIST]
    return {n: _d(lm[t], w) > _d(lm[p], w) * 1.12 for n, (t, p) in FINGERS.items()}


def classify_pose(lm) -> str:
    """'open_palm' | 'fist' | 'other'. Rotation-invariant (distance based)."""
    if lm is None or len(lm) < 21:
        return "none"
    n = sum(finger_states(lm).values())
    return "open_palm" if n == 4 else "fist" if n == 0 else "other"


def palm_center(lm) -> tuple[float, float]:
    return (sum(lm[i][0] for i in PALM_IDS) / 5, sum(lm[i][1] for i in PALM_IDS) / 5)


@dataclass
class GestureConfig:
    sensitivity: float = 0.5      # 0..1 higher = smaller movement needed
    min_open_s: float = 0.25
    window_s: float = 0.7
    cooldown_s: float = 1.0
    steady_s: float = 0.35
    lost_s: float = 0.4

    @property
    def travel(self) -> float:    # normalized image height fraction (y grows downward)
        return 0.26 - 0.16 * min(1.0, max(0.0, self.sensitivity))


class GestureEngine:
    def __init__(self, cfg: GestureConfig | None = None):
        self.cfg = cfg or GestureConfig()
        self.hist: deque[tuple[float, float]] = deque()
        self.open_since: float | None = None
        self.last_fire = -1e9
        self.armed = True
        self.last_seen = -1e9
        self.debug = {"pose": "none"}

    def update(self, lm, t: float) -> str | None:
        """Feed landmarks (or None when no hand) with timestamp t. Returns 'up' | 'down' | None."""
        c = self.cfg
        pose = classify_pose(lm)
        self.debug = {"pose": pose}
        if pose == "none":
            if t - self.last_seen > c.lost_s:
                self.hist.clear(); self.open_since = None; self.armed = True
            return None
        self.last_seen = t
        if pose != "open_palm":
            self.hist.clear(); self.open_since = None
            if pose == "fist": self.armed = True   # closing the hand is a deliberate reset
            return None
        _, y = palm_center(lm)
        if self.open_since is None:
            self.open_since = t
        self.hist.append((t, y))
        while self.hist and t - self.hist[0][0] > c.window_s:
            self.hist.popleft()
        steady = [h for h in self.hist if t - h[0] <= c.steady_s]
        if not self.armed:
            if len(steady) >= 3 and max(h[1] for h in steady) - min(h[1] for h in steady) < 0.02 and t - self.last_fire > c.cooldown_s:
                self.armed = True
                self.hist.clear()          # forget the motion that preceded re-arming
            return None
        if t - self.open_since < c.min_open_s or t - self.last_fire < c.cooldown_s or len(self.hist) < 4:
            return None
        dy = self.hist[-1][1] - self.hist[0][1]
        ys = [h[1] for h in self.hist]
        steps = [b - a for a, b in zip(ys, ys[1:])]
        sign = 1 if dy > 0 else -1
        smooth = (max(abs(x) for x in steps) <= 0.5 * abs(dy)                      # not a single-frame jump
                  and sum(1 for x in steps if x * sign > 0.004) >= 3)              # sustained directional motion
        if abs(dy) >= c.travel and smooth:
            self.last_fire, self.armed = t, False
            self.hist.clear()
            return "down" if dy > 0 else "up"
        return None
