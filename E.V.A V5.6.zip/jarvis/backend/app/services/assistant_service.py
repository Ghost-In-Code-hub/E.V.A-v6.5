"""AssistantService: wires state machine, voice, vision, orchestration and tools together."""
from __future__ import annotations

import asyncio
import base64
import logging
import re
import time
from pathlib import Path

from ..brain.orchestrator import Orchestrator
from ..brain.quick_math import quick_math
from ..computer.browser_agent import BrowserAgent
from ..computer.desktop_agent import DesktopAgent
from ..core import config as cfg
from ..core.events import EventBus
from ..core.security import AuditLog, RedactingFilter, redact
from ..core.state import State, StateMachine
from ..memory.database import Memory
from ..providers.base import ProviderError
from ..providers.gateway import ProviderGateway
from ..tasks.manager import ConfirmationManager, TaskManager
from ..tools import app_launcher, calculator, file_operations, web, whatsapp
from ..tools.registry import ToolRegistry
from ..vision.hand_tracker import HandTracker
from ..vision.volume_controller import AssistantVolume, VolumeController, WindowsSystemVolume
from ..voice.session_manager import VoiceSession
from ..voice.speech_pipeline import SpeechPipeline
from ..voice.synthesis import detect_language, get_synth
from ..voice.transcription import get_transcriber

log = logging.getLogger("jarvis.service")
STOP_RE = re.compile(r"^(jarvis[, ]+)?(please[, ]+)?(stop|cancel|be quiet|quiet|shut up|enough|stop talking|stop speaking|stop controlling the computer|stop it|ruko|chup)[.! ]*$", re.I)
VERSION = "6.5.0"


def is_stop_command(text: str) -> bool:
    return bool(STOP_RE.match(text.strip()))


class AssistantService:
    def __init__(self, data_dir: Path | None = None, providers=None, synth_factory=get_synth, transcriber_factory=get_transcriber):
        cfg.load_env()
        self.data_dir = Path(data_dir or cfg.DATA_DIR)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.started = time.time()
        self.settings = cfg.SettingsStore(self.data_dir / "settings.json")
        self.bus, self.state = EventBus(), StateMachine()
        self.memory = Memory(self.data_dir / "memory.db", self.settings["memory"]["enabled"], self.settings["memory"]["retention_days"])
        self.audit = AuditLog(self.data_dir / "audit.jsonl", self.settings["privacy"]["audit_log"])
        self.registry = ToolRegistry(self.settings)
        self.confirmations = ConfirmationManager(self.bus)
        self.tasks = TaskManager(self.bus)
        self.gateway = ProviderGateway(self.settings, providers)
        self.browser, self.desktop = BrowserAgent(self.settings, self.data_dir), DesktopAgent(self.settings)
        self.services = {"browser": self.browser, "desktop": self.desktop, "memory": self.memory, "request_stop": lambda: self.stop("model request", emergency=True)}
        for mod in (calculator, app_launcher, file_operations, web, whatsapp):
            for t in mod.tools(): self.registry.register(t)
        self.orch = Orchestrator(self.settings, self.gateway, self.registry, self.memory, self.bus, self.state,
                                 self.confirmations, self.audit, self.services)
        self.voice = VoiceSession(self.settings)
        self.assistant_volume = AssistantVolume(self.settings["voice"]["speech_volume"])
        self.system_volume = WindowsSystemVolume()
        self.synth_factory, self.transcriber_factory = synth_factory, transcriber_factory
        self.tracker: HandTracker | None = None
        self._speech_watch: asyncio.Task | None = None
        self._pipe: SpeechPipeline | None = None
        self._sp = {"emitted": False, "closed": True, "played": False}
        self.camera_active = False
        self._gest_warned = False
        self.current_conv: str | None = None
        self.state.subscribe(self._on_state)
        for h in logging.getLogger().handlers: h.addFilter(RedactingFilter())

    # ---- lifecycle -----------------------------------------------------------------------------------
    async def start(self):
        self.tracker = HandTracker(asyncio.get_running_loop(), self.on_gesture, self.on_camera)
        self.memory.purge_expired()
        self.audit.purge_older_than(self.settings["privacy"]["audit_retention_days"])
        await self.state.set(State.STANDBY, "Ready")
        if self.settings["vision"]["gestures_enabled"]:
            await self.set_gestures(True)      # no-op unless engine == "python"
        asyncio.create_task(self.gateway.warm())          # pre-open the TLS connection so the first answer is fast
        log.info("Jarvis backend ready")

    async def shutdown(self):
        await self.tasks.cancel("shutdown")
        self.confirmations.deny_all()
        if self.tracker: await asyncio.to_thread(self.tracker.stop)
        await self.browser.close()
        self.memory.close()

    async def _on_state(self, old, new, detail):
        await self.bus.emit("state", state=new.value, previous=old.value, detail=detail)

    # ---- introspection (honest availability) -----------------------------------------------------------
    def capabilities(self) -> dict:
        ai_ok, ai_why = self.gateway.ready()
        v, c = self.settings["voice"], self.settings["computer"]
        stt_ok, stt_why = self.transcriber_factory(v["input_provider"]).configured()
        synth = self.synth_factory(v["output_provider"])
        tts_ok, tts_why = synth.configured() if synth else (False, "Speech output disabled")
        vol_ok, vol_why = self.system_volume.available()
        gest_ok, gest_why = HandTracker.available()
        return {
            "version": VERSION, "state": self.state.state.value,
            "ai": {"provider": self.gateway.active_name, "configured": ai_ok, "reason": ai_why, "model": self.gateway.model(), "providers": self.gateway.status()},
            "stt": {"provider": v["input_provider"], "configured": stt_ok, "reason": stt_why},
            "tts": {"provider": v["output_provider"], "configured": tts_ok, "reason": tts_why},
            "browser": {"available": self.browser.available()[0], "reason": self.browser.available()[1], "enabled": c["enabled"] and c["browser_enabled"]},
            "desktop": {"available": self.desktop.available()[0], "reason": self.desktop.available()[1], "enabled": c["enabled"] and c["desktop_enabled"]},
            "screen": {"available": self.desktop.screen_available()[0], "reason": self.desktop.screen_available()[1]},
            "gestures": {"available": gest_ok or self.settings["vision"]["engine"] == "browser", "reason": "" if self.settings["vision"]["engine"] == "browser" else gest_why,
                         "enabled": self.settings["vision"]["gestures_enabled"], "camera_active": self.camera_active, "engine": self.settings["vision"]["engine"]},
            "system_volume": {"available": vol_ok, "reason": vol_why},
            "whatsapp": whatsapp.cloud_status(),
            "clap": {"enabled": v["clap"]["enabled"]},
            "wake_phrase": {"available": False, "reason": "Needs an on-device speech recogniser; none is bundled. Use clap or the microphone button."},
            "mic": {"enabled": self.voice.mic_enabled},
            "tools": self.registry.names(), "secrets": cfg.secret_status(),
            "settings": self.settings.data,
        }

    def health(self) -> dict:
        return {"service": "jarvis", "status": "ok", "version": VERSION, "state": self.state.state.value,
                "uptime_s": round(time.time() - self.started, 1)}

    async def push_capabilities(self):
        await self.bus.emit("capabilities", **self.capabilities())

    # ---- settings --------------------------------------------------------------------------------------
    async def update_settings(self, patch: dict) -> list[str]:
        errs = self.settings.update(patch)
        if errs: return errs
        s = self.settings
        self.memory.configure(s["memory"]["enabled"], s["memory"]["retention_days"])
        self.audit.enabled = s["privacy"]["audit_log"]
        self.voice.apply_settings()
        self.assistant_volume.set(s["voice"]["speech_volume"])
        if self.tracker:
            self.tracker.set_sensitivity(s["vision"]["sensitivity"])
        want = s["vision"]["gestures_enabled"]
        if s["vision"]["engine"] == "python" and (want != bool(self.tracker and self.tracker.running) or "camera_index" in patch.get("vision", {})):
            await self.set_gestures(want)
        await self.push_capabilities()
        return []

    async def set_secrets(self, values: dict[str, str]):
        allowed = {k: v for k, v in values.items() if k in cfg.SECRET_KEYS}
        cfg.write_env_values({**allowed, **{k: v for k, v in values.items() if k in ("OLLAMA_BASE_URL", "OPENAI_BASE_URL", "WHATSAPP_PHONE_NUMBER_ID")}})
        self.audit.write("secrets_updated", keys=list(allowed))  # names only, never values
        asyncio.create_task(self.gateway.warm())                 # new key: validate + pre-warm the connection
        await self.push_capabilities()

    # ---- text / voice turns ------------------------------------------------------------------------------
    async def handle_text(self, text: str, conversation_id: str | None = None, source: str = "text") -> dict:
        text = text.strip()
        if is_stop_command(text):
            await self.stop("stop command")
            return {"task_id": None, "conversation_id": conversation_id, "handled": "stop"}
        conv = conversation_id or self.current_conv or self.memory.create_conversation()
        self.current_conv = conv
        if self.state.state == State.SPEAKING:
            await self.bus.emit("interrupted", reason="new request", emergency=False)  # cut off old speech immediately
        await self.bus.emit("transcript_final", text=text, source=source, conversation_id=conv)
        tid = await self.tasks.start(lambda cancel: self._turn(text, conv, cancel), text)
        return {"task_id": tid, "conversation_id": conv}

    async def _turn(self, text: str, conv: str, cancel: asyncio.Event):
        self._sp = {"emitted": False, "closed": False, "played": False}
        pipe = self._start_pipeline()
        try:
            qm = quick_math(text)
            final = await (self._quick_answer(qm, text, conv, pipe) if qm else self.orch.run_turn(text, conv, cancel, on_text=pipe.feed if pipe else None))
            if cancel.is_set():
                return
            if final is None:                      # error already emitted + ERROR state set
                if pipe: pipe.cancel()
                await asyncio.sleep(2.0)
                if self.state.state == State.ERROR: await self.state.set(State.STANDBY, "Recovered")
                return
            if pipe:
                await pipe.finish()
            self._sp["closed"] = True
            if self._sp["emitted"]: self._arm_speech_watchdog()
            await self._maybe_idle()
        except asyncio.CancelledError:
            if pipe: pipe.cancel()
            raise
        finally:
            if self._pipe is pipe: self._pipe = None

    async def _quick_answer(self, qm, text: str, conv: str, pipe) -> str:
        """Arithmetic is answered locally and instantly: no AI call, no network."""
        self.registry.clear_estop()
        await self.state.set(State.PROCESSING, "Calculating")
        self.orch._add(conv, {"role": "user", "content": text})
        await self.bus.emit("calc", expression=qm.expression, value=qm.display, text=qm.text)
        await self.bus.emit("response_delta", text=qm.text)
        if pipe: pipe.feed(qm.spoken)
        self.orch._add(conv, {"role": "assistant", "content": qm.text})
        await self.bus.emit("response_final", text=qm.text, conversation_id=conv)
        return qm.text

    def _start_pipeline(self) -> SpeechPipeline | None:
        v = self.settings["voice"]
        synth = self.synth_factory(v["output_provider"]) if v["speak_responses"] else None
        if not synth: return None
        ok, why = synth.configured()
        if not ok:
            asyncio.create_task(self.bus.emit("error", message=f"Speech output unavailable: {why}", kind="tts", recoverable=True))
            return None

        async def emit_audio(seq, audio, mime, text, last):
            if not last and self.state.state in (State.PROCESSING, State.EXECUTING):
                await self.state.set(State.SPEAKING, "Speaking")
            self._sp["emitted"] = True
            await self.bus.emit("audio", seq=seq, last=last, data=base64.b64encode(audio).decode() if audio else "", mime=mime, text=text,
                                volume=self.assistant_volume.get(), language=detect_language(text, v["language"]) if text else "")

        async def on_error(msg):
            await self.bus.emit("error", message=redact(msg)[:160], kind="tts", recoverable=True)

        self._pipe = SpeechPipeline(synth, v["language"], v["voice"], emit_audio, on_error)
        return self._pipe

    async def _maybe_idle(self):
        sp = self._sp
        if sp["closed"] and (not sp["emitted"] or sp["played"]) and self.state.state in (State.SPEAKING, State.PROCESSING, State.EXECUTING):
            if self._speech_watch: self._speech_watch.cancel()
            await self.state.set(State.STANDBY, "Done")

    def _arm_speech_watchdog(self):
        if self._speech_watch: self._speech_watch.cancel()
        async def watch():
            await asyncio.sleep(90)  # the UI normally reports playback end sooner; this prevents a stuck state
            if self.state.state == State.SPEAKING: await self.state.set(State.STANDBY, "Speech timeout")
        self._speech_watch = asyncio.create_task(watch())

    async def speech_finished(self, error: str | None = None):
        if error: await self.bus.emit("error", message=f"Audio playback failed: {error[:150]}", kind="playback", recoverable=True)
        self._sp["played"] = True
        await self._maybe_idle()

    # ---- wake / audio ------------------------------------------------------------------------------------
    async def set_mic(self, enabled: bool):
        self.voice.mic_enabled = enabled
        if not enabled: self.voice.end_utterance()
        await self.bus.emit("mic", enabled=enabled)
        if not enabled and self.state.state == State.LISTENING: await self.state.set(State.STANDBY, "Microphone off")

    async def wake(self, source: str):
        if not self.voice.mic_enabled:
            await self.bus.emit("error", message="The microphone is off. Turn it on to speak to Jarvis.", kind="mic_off", recoverable=True); return
        if self.state.state in (State.PROCESSING, State.EXECUTING, State.SPEAKING):
            await self.stop(f"barge-in ({source})", relisten=True); return
        if self.state.state == State.LISTENING: return
        await self.bus.emit("wake", source=source)
        if await self.state.set(State.LISTENING, f"Listening ({source})"):
            self.voice.begin_utterance()

    async def feed_audio(self, pcm: bytes):
        for a in self.voice.feed(pcm, self.state.state.value):
            if a["type"] == "wake": await self.wake(a["source"])
            elif a["type"] == "vad": await self.bus.emit("vad", speaking=a["speaking"])
            elif a["type"] == "no_speech":
                await self.bus.emit("log", message="No speech detected; returning to standby.")
                await self.state.set(State.STANDBY, "No speech")
            elif a["type"] == "utterance":
                await self.state.set(State.PROCESSING, "Transcribing")
                await self.tasks.start(lambda cancel, w=a["wav"]: self._voice_turn(w, cancel), "voice request")

    async def _voice_turn(self, wav: bytes, cancel: asyncio.Event):
        v = self.settings["voice"]
        try:
            text = await self.transcriber_factory(v["input_provider"]).transcribe(wav, v["language"])
        except ProviderError as e:
            await self.bus.emit("error", message=str(e), kind=e.kind, recoverable=True)
            await self.state.set(State.ERROR, str(e)[:100]); await asyncio.sleep(2.5)
            if self.state.state == State.ERROR: await self.state.set(State.STANDBY, "Recovered")
            return
        if cancel.is_set(): return
        if not text:
            await self.bus.emit("log", message="Could not recognise any speech.")
            await self.state.set(State.STANDBY, "No speech recognised"); return
        if is_stop_command(text):
            await self.stop("voice stop command"); return
        conv = self.current_conv or self.memory.create_conversation()
        self.current_conv = conv
        await self.bus.emit("transcript_final", text=text, source="voice", conversation_id=conv)
        await self._turn(text, conv, cancel)

    # ---- stopping ----------------------------------------------------------------------------------------
    async def stop(self, reason: str = "user", *, emergency: bool = False, relisten: bool = False):
        active = self.state.state in (State.LISTENING, State.PROCESSING, State.EXECUTING, State.SPEAKING)
        if emergency: self.registry.trigger_estop()
        self.confirmations.deny_all()
        if self._speech_watch: self._speech_watch.cancel()
        if self._pipe: self._pipe.cancel()
        self.voice.end_utterance()
        await self.bus.emit("interrupted", reason=reason, emergency=emergency)
        self.tasks.cancel_event.set()                  # cooperative: running loops exit at their next check
        if self.tasks.running and asyncio.current_task() is not self.tasks.current:
            await self.tasks.cancel(reason)            # hard: cancel the task (not ourselves, if a tool called us)
        self.audit.write("stop", reason=reason, emergency=emergency)
        if active:
            await self.state.set(State.INTERRUPTED, reason)
            await asyncio.sleep(0.3)
        elif self.state.state == State.ERROR:
            await self.state.set(State.STANDBY, "Cleared")
        if self.state.state == State.INTERRUPTED:
            if relisten and self.voice.mic_enabled:
                await self.state.set(State.LISTENING, "Listening"); self.voice.begin_utterance()
            else:
                await self.state.set(State.STANDBY, "Stopped")

    # ---- vision ------------------------------------------------------------------------------------------
    async def set_gestures(self, enabled: bool):
        if not self.tracker or self.settings["vision"]["engine"] != "python": return    # default engine runs inside the UI
        if not enabled:
            await asyncio.to_thread(self.tracker.stop); return
        v = self.settings["vision"]
        ok, why = self.tracker.start(v["camera_index"], v["sensitivity"])
        if not ok and not self._gest_warned:
            self._gest_warned = True
            await self.bus.emit("log", message=f"Python gesture engine unavailable: {why}")

    async def on_camera(self, active: bool, error: str | None = None):
        self.camera_active = active
        await self.bus.emit("camera", active=active, error=error)
        if error: await self.bus.emit("error", message=error, kind="camera", recoverable=True)

    async def on_gesture(self, direction: str):
        v = self.settings["vision"]
        target = v["volume_target"]
        if target == "system" and not self.system_volume.available()[0]:
            target = "assistant"                       # no Windows audio API here: control Jarvis' own volume instead
        vc = VolumeController(self.assistant_volume, self.system_volume if target == "system" else None, target, v["volume_step"])
        try:
            r = await asyncio.to_thread(vc.change, direction)
        except Exception as e:
            await self.bus.emit("error", message=f"Volume change failed: {e}", kind="volume", recoverable=True); return
        if r["target"] == "assistant":
            self.settings.update({"voice": {"speech_volume": r["level"]}})
        await self.bus.emit("gesture", direction=direction)
        await self.bus.emit("volume", **r)
        self.audit.write("gesture_volume", **r)

    # ---- computer-control stop that the model can request ------------------------------------------------
    async def confirm(self, cid: str, approved: bool) -> bool:
        return self.confirmations.resolve(cid, approved)
