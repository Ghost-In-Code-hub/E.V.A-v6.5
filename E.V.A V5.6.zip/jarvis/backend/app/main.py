from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
import hmac

from .api import routes, websocket
from .core import config as cfg
from .core.security import RedactingFilter
from .services.assistant_service import AssistantService

MAX_BODY = 1_000_000
PUBLIC_PATHS = {"/api/health"}


def create_app(service: AssistantService | None = None, *, token: str | None = None, port: int | None = None) -> FastAPI:
    port = port or int(os.environ.get("JARVIS_PORT", "8765"))
    origins = [f"http://127.0.0.1:{port}", f"http://localhost:{port}", "http://127.0.0.1:5173", "http://localhost:5173"]

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        app.state.service = service or AssistantService()
        await app.state.service.start()
        yield
        await app.state.service.shutdown()

    app = FastAPI(title="Jarvis", version="6.5.0", lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)
    app.state.token = token or cfg.new_session_token()
    app.state.allowed_origins = origins
    app.state.server_should_exit = lambda: None
    app.add_middleware(CORSMiddleware, allow_origins=origins, allow_methods=["GET", "POST", "PUT", "DELETE"],
                       allow_headers=["X-Jarvis-Token", "Content-Type"], allow_credentials=False)

    @app.middleware("http")
    async def guard(request: Request, call_next):
        p = request.url.path
        if p.startswith("/api/"):
            if int(request.headers.get("content-length") or 0) > MAX_BODY:
                return JSONResponse({"detail": "Request too large"}, 413)
            origin = request.headers.get("origin")
            if origin and origin not in origins:
                return JSONResponse({"detail": "Origin not allowed"}, 403)
            if p not in PUBLIC_PATHS and request.method != "OPTIONS":
                if not hmac.compare_digest(request.headers.get("x-jarvis-token", "").encode(), request.app.state.token.encode()):
                    return JSONResponse({"detail": "Missing or invalid session token"}, 401)
        return await call_next(request)

    app.include_router(routes.router)
    app.include_router(websocket.router)
    dist = Path(os.environ.get("JARVIS_FRONTEND_DIST", cfg.ROOT / "frontend" / "dist"))
    if dist.exists():
        app.mount("/", StaticFiles(directory=dist, html=True), name="ui")
    return app


app = None  # created lazily by run.py / uvicorn factory


def factory() -> FastAPI:
    return create_app()
