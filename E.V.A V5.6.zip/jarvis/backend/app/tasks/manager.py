from __future__ import annotations

import asyncio
import logging
import uuid

log = logging.getLogger("jarvis.tasks")


class ConfirmationManager:
    """Human-in-the-loop approvals. Pending requests are visible in the UI and always cancellable."""

    def __init__(self, bus, timeout: float = 120.0):
        self.bus, self.timeout = bus, timeout
        self._pending: dict[str, asyncio.Future] = {}

    async def request(self, prompt: str, details: dict | None = None) -> bool:
        cid = uuid.uuid4().hex[:8]
        fut = asyncio.get_running_loop().create_future()
        self._pending[cid] = fut
        safe = {k: v for k, v in (details or {}).items() if k != "image_b64"}
        await self.bus.emit("confirmation_request", id=cid, prompt=prompt, details=safe, timeout_s=self.timeout)
        try:
            return await asyncio.wait_for(fut, self.timeout)
        except asyncio.TimeoutError:
            return False  # no answer == no
        finally:
            self._pending.pop(cid, None)
            await self.bus.emit("confirmation_resolved", id=cid, approved=bool(fut.done() and not fut.cancelled() and fut.result()))

    def resolve(self, cid: str, approved: bool) -> bool:
        f = self._pending.get(cid)
        if f and not f.done():
            f.set_result(bool(approved)); return True
        return False

    def deny_all(self) -> None:
        for f in list(self._pending.values()):
            if not f.done(): f.set_result(False)

    @property
    def pending(self) -> int:
        return len(self._pending)


class TaskManager:
    """One active assistant task at a time. Starting a new one cancels the obsolete one."""

    def __init__(self, bus):
        self.bus = bus
        self.current: asyncio.Task | None = None
        self.current_id: str | None = None
        self.cancel_event = asyncio.Event()

    async def start(self, coro_fn, label: str) -> str:
        await self.cancel("superseded")
        tid = uuid.uuid4().hex[:8]
        self.cancel_event = asyncio.Event()
        self.current_id = tid
        await self.bus.emit("task", id=tid, status="started", label=label[:120])

        async def runner():
            try:
                await coro_fn(self.cancel_event)
                await self.bus.emit("task", id=tid, status="finished", label=label[:120])
            except asyncio.CancelledError:
                await self.bus.emit("task", id=tid, status="cancelled", label=label[:120])
                raise
            except Exception as e:
                log.exception("task failed")
                await self.bus.emit("task", id=tid, status="failed", label=label[:120], error=str(e)[:200])

        self.current = asyncio.create_task(runner())
        return tid

    async def cancel(self, reason: str = "user") -> bool:
        t = self.current
        if t and not t.done():
            self.cancel_event.set()
            t.cancel()
            try: await t
            except (asyncio.CancelledError, Exception): pass
            return True
        return False

    @property
    def running(self) -> bool:
        return bool(self.current and not self.current.done())
