"""Assistant state machine: the single source of truth for frontend, voice and backend."""
from __future__ import annotations

import asyncio
import logging
from enum import Enum
from typing import Awaitable, Callable

log = logging.getLogger("jarvis.state")


class State(str, Enum):
    STARTING = "STARTING"
    STANDBY = "STANDBY"
    LISTENING = "LISTENING"
    PROCESSING = "PROCESSING"
    EXECUTING = "EXECUTING"
    SPEAKING = "SPEAKING"
    INTERRUPTED = "INTERRUPTED"
    ERROR = "ERROR"


S = State
ALLOWED: dict[State, set[State]] = {
    S.STARTING: {S.STANDBY, S.ERROR},
    S.STANDBY: {S.LISTENING, S.PROCESSING, S.ERROR},
    S.LISTENING: {S.PROCESSING, S.STANDBY, S.INTERRUPTED, S.ERROR},
    S.PROCESSING: {S.EXECUTING, S.SPEAKING, S.STANDBY, S.INTERRUPTED, S.ERROR},
    S.EXECUTING: {S.PROCESSING, S.SPEAKING, S.STANDBY, S.INTERRUPTED, S.ERROR},
    S.SPEAKING: {S.STANDBY, S.LISTENING, S.PROCESSING, S.EXECUTING, S.INTERRUPTED, S.ERROR},
    S.INTERRUPTED: {S.LISTENING, S.STANDBY, S.PROCESSING, S.ERROR},
    S.ERROR: {S.STANDBY, S.LISTENING, S.PROCESSING},
}

Listener = Callable[[State, State, str], Awaitable[None] | None]


class InvalidTransition(Exception):
    pass


class StateMachine:
    def __init__(self) -> None:
        self.state = State.STARTING
        self.detail = ""
        self._listeners: list[Listener] = []

    def subscribe(self, fn: Listener) -> None:
        self._listeners.append(fn)

    def can(self, new: State) -> bool:
        return new == self.state or new in ALLOWED[self.state]

    async def set(self, new: State, detail: str = "", *, strict: bool = False) -> bool:
        """Transition. Illegal transitions are rejected (raise if strict) and logged."""
        if new == self.state:
            self.detail = detail or self.detail
            return True
        if new not in ALLOWED[self.state]:
            msg = f"Illegal transition {self.state.value} -> {new.value}"
            log.warning(msg)
            if strict:
                raise InvalidTransition(msg)
            return False
        old, self.state, self.detail = self.state, new, detail
        for fn in list(self._listeners):
            try:
                r = fn(old, new, detail)
                if asyncio.iscoroutine(r):
                    await r
            except Exception:
                log.exception("state listener failed")
        return True
