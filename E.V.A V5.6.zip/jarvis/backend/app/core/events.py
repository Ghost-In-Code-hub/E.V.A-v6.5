"""In-process event bus. Every frontend-visible event goes through here and is type-checked."""
from __future__ import annotations

import asyncio
import time
from typing import Any

EVENT_TYPES = {
    "state", "transcript_partial", "transcript_final", "response_delta", "response_final",
    "audio", "tool_start", "tool_progress", "tool_result", "task", "screenshot", "error",
    "gesture", "volume", "connection", "log", "wake", "vad", "confirmation_request",
    "confirmation_resolved", "capabilities", "usage", "interrupted", "camera", "mic", "calc", "hand",
}


class EventBus:
    def __init__(self, maxsize: int = 256) -> None:
        self._subs: set[asyncio.Queue] = set()
        self._maxsize = maxsize
        self.seq = 0

    def subscribe(self) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue(self._maxsize)
        self._subs.add(q)
        return q

    def unsubscribe(self, q: asyncio.Queue) -> None:
        self._subs.discard(q)

    def make(self, type_: str, **data: Any) -> dict:
        if type_ not in EVENT_TYPES:
            raise ValueError(f"Unknown event type: {type_}")
        self.seq += 1
        return {"type": type_, "seq": self.seq, "ts": time.time(), **data}

    async def emit(self, type_: str, **data: Any) -> dict:
        ev = self.make(type_, **data)
        for q in list(self._subs):
            if q.full():  # slow consumer: drop oldest rather than block the assistant
                try: q.get_nowait()
                except asyncio.QueueEmpty: pass
            q.put_nowait(ev)
        return ev
