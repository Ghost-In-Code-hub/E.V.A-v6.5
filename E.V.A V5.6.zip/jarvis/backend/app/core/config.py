"""Configuration: .env for secrets (backend only) + data/settings.json for non-secret settings."""
from __future__ import annotations

import copy
import json
import os
import re
import secrets
from pathlib import Path

ROOT = Path(os.environ.get("JARVIS_ROOT", Path(__file__).resolve().parents[3]))
DATA_DIR = Path(os.environ.get("JARVIS_DATA", ROOT / "data"))
ENV_PATH = ROOT / ".env"
SETTINGS_PATH = DATA_DIR / "settings.json"
TOKEN_PATH = DATA_DIR / "session_token"
SECRET_KEYS = ("OPENROUTER_API_KEY", "OPENAI_API_KEY", "ANTHROPIC_API_KEY", "WHATSAPP_TOKEN")
PROVIDERS = ("openrouter", "openai", "anthropic", "ollama")

DEFAULTS: dict = {
    # OpenRouter is the default: one API key, NO model id needed (it auto-routes to a suitable model).
    "ai": {"provider": "openrouter", "timeout_s": 60, "streaming": True,
           "models": {"openrouter": "", "openai": "", "anthropic": "", "ollama": ""}, "max_tool_steps": 8},
    "voice": {"input_provider": "openrouter", "output_provider": "edge", "language": "en", "voice": "",
              "speech_volume": 0.9, "silence_timeout_s": 1.0, "no_speech_timeout_s": 6.0,
              "max_utterance_s": 20.0, "mic_device": "", "speaker_device": "", "speak_responses": True, "auto_mic": True,
              "clap": {"enabled": True, "sensitivity": 0.5, "cooldown_s": 2.0},
              "wake_phrase": {"enabled": False, "phrase": "jarvis"}},
    "vision": {"gestures_enabled": True, "engine": "browser", "camera_index": 0, "sensitivity": 0.5,
               "volume_target": "system", "volume_step": 0.1},
    "computer": {"enabled": True, "browser_enabled": True, "desktop_enabled": True,
                 "files_enabled": True, "whatsapp_enabled": True, "browser_channel": "chrome",
                 "apps": {}, "allowed_dirs": [], "allowed_domains": [], "confirm_all_actions": False},
    "interface": {"quality": "medium", "particle_density": 1.0, "fullscreen": False, "skip_startup": False, "island_overlay": True},
    "memory": {"enabled": True, "retention_days": 30},
    "privacy": {"audit_log": True, "audit_retention_days": 30},
}


def deep_merge(base: dict, over: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def parse_env(text: str) -> dict[str, str]:
    env: dict[str, str] = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        v = v.strip()
        if v[:1] in ("'", '"'):
            v = v.strip("\"'")
        else:
            v = re.sub(r"\s+#.*$", "", v)
        env[k.strip()] = v.strip()
    return env


def load_env(path: Path = ENV_PATH) -> None:
    """Load .env into os.environ without overriding variables already set by the OS."""
    if path.exists():
        for k, v in parse_env(path.read_text(encoding="utf-8")).items():
            if v:
                os.environ.setdefault(k, v)


def write_env_values(updates: dict[str, str], path: Path = ENV_PATH) -> None:
    """Update/insert KEY=VALUE lines in .env (write-only secret workflow). Empty value removes key."""
    for k, v in updates.items():
        if not re.fullmatch(r"[A-Z0-9_]+", k):
            raise ValueError(f"Invalid env name {k}")
        if any(c in v for c in "\r\n"):
            raise ValueError("Value may not contain newlines")
    lines = path.read_text(encoding="utf-8").splitlines() if path.exists() else []
    seen = set()
    for i, line in enumerate(lines):
        key = line.split("=", 1)[0].strip()
        if key in updates and "=" in line and not line.strip().startswith("#"):
            lines[i] = f"{key}={updates[key]}"; seen.add(key)
    for k, v in updates.items():
        if k not in seen:
            lines.append(f"{k}={v}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    for k, v in updates.items():
        if v: os.environ[k] = v
        else: os.environ.pop(k, None)


def validate_settings(s: dict) -> list[str]:
    errs: list[str] = []
    def rng(path, v, lo, hi):
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not lo <= v <= hi:
            errs.append(f"{path} must be a number between {lo} and {hi}")
    if s["ai"]["provider"] not in PROVIDERS:
        errs.append(f"ai.provider must be one of {', '.join(PROVIDERS)}")
    rng("ai.timeout_s", s["ai"]["timeout_s"], 5, 600)
    rng("ai.max_tool_steps", s["ai"]["max_tool_steps"], 1, 20)
    v = s["voice"]
    rng("voice.speech_volume", v["speech_volume"], 0, 1)
    rng("voice.silence_timeout_s", v["silence_timeout_s"], 0.3, 10)
    rng("voice.clap.sensitivity", v["clap"]["sensitivity"], 0, 1)
    rng("voice.clap.cooldown_s", v["clap"]["cooldown_s"], 0.5, 30)
    if v["language"] not in ("en", "ur", "auto"):
        errs.append("voice.language must be en, ur or auto")
    if v["input_provider"] not in ("openrouter", "openai"):
        errs.append("voice.input_provider must be openrouter or openai")
    if v["output_provider"] not in ("edge", "openai", "sapi", "none"):
        errs.append("voice.output_provider must be edge, openai, sapi or none")
    g = s["vision"]
    rng("vision.sensitivity", g["sensitivity"], 0, 1)
    rng("vision.volume_step", g["volume_step"], 0.01, 0.3)
    if g["engine"] not in ("browser", "python"):
        errs.append("vision.engine must be browser or python")
    if g["volume_target"] not in ("assistant", "system"):
        errs.append("vision.volume_target must be assistant or system")
    if s["interface"]["quality"] not in ("low", "medium", "high"):
        errs.append("interface.quality must be low, medium or high")
    rng("interface.particle_density", s["interface"]["particle_density"], 0.2, 2.0)
    rng("memory.retention_days", s["memory"]["retention_days"], 0, 3650)
    return errs


class SettingsStore:
    def __init__(self, path: Path | None = None) -> None:
        self.path = Path(path or SETTINGS_PATH)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.data = deep_merge(DEFAULTS, {})
        if self.path.exists():
            try:
                self.data = deep_merge(DEFAULTS, json.loads(self.path.read_text(encoding="utf-8")))
            except Exception:
                pass
        self._apply_env()

    def _apply_env(self) -> None:
        e = os.environ
        if e.get("AI_PROVIDER") in PROVIDERS:
            self.data["ai"]["provider"] = e["AI_PROVIDER"]
        for p in PROVIDERS:
            m = e.get(f"{p.upper()}_MODEL")
            if m: self.data["ai"]["models"][p] = m
        if e.get("VOICE_OUTPUT_PROVIDER") in ("edge", "openai", "sapi", "none"):
            self.data["voice"]["output_provider"] = e["VOICE_OUTPUT_PROVIDER"]

    def update(self, patch: dict) -> list[str]:
        merged = deep_merge(self.data, patch)
        if isinstance(patch.get("computer"), dict) and isinstance(patch["computer"].get("apps"), dict):
            merged["computer"]["apps"] = dict(patch["computer"]["apps"])   # whole-map edit (allows removals)
        errs = validate_settings(merged)
        if errs:
            return errs
        self.data = merged
        self.path.write_text(json.dumps(self.data, indent=2), encoding="utf-8")
        return []

    def __getitem__(self, k):
        return self.data[k]


def secret_status() -> dict[str, bool]:
    """Booleans only. Secret values are never returned."""
    return {k: bool(os.environ.get(k)) for k in SECRET_KEYS}


def new_session_token() -> str:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    tok = secrets.token_urlsafe(32)
    TOKEN_PATH.write_text(tok, encoding="utf-8")
    try: os.chmod(TOKEN_PATH, 0o600)
    except Exception: pass
    return tok
