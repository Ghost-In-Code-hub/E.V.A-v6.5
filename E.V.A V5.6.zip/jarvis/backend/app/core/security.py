"""Secret redaction, audit logging and path/URL safety helpers (stdlib only)."""
from __future__ import annotations

import json
import logging
import os
import re
import time
from pathlib import Path
from urllib.parse import urlparse

_PATTERNS = [
    re.compile(r"sk-ant-[A-Za-z0-9_\-]{8,}"),
    re.compile(r"sk-[A-Za-z0-9_\-]{12,}"),
    re.compile(r"(?i)bearer\s+[A-Za-z0-9._\-]{12,}"),
    re.compile(r"EA[A-Za-z0-9]{40,}"),  # Meta access tokens
]
_KV = re.compile(r"(?i)(api[_-]?key|token|secret|password)(\"?\s*[:=]\s*\"?)([^\s\"',}]{6,})")
SECRET_ENV_NAMES = ("OPENROUTER_API_KEY", "OPENAI_API_KEY", "ANTHROPIC_API_KEY", "WHATSAPP_TOKEN")


def _known_secret_values() -> list[str]:
    return [v for n in SECRET_ENV_NAMES if (v := os.environ.get(n)) and len(v) >= 8]


def redact(text: str) -> str:
    if not isinstance(text, str):
        text = str(text)
    for v in _known_secret_values():
        text = text.replace(v, "[REDACTED]")
    for p in _PATTERNS:
        text = p.sub("[REDACTED]", text)
    return _KV.sub(lambda m: f"{m.group(1)}{m.group(2)}[REDACTED]", text)


_SECRET_KEY = re.compile(r"(?i)key|token|secret|password")


def redact_obj(obj):
    if isinstance(obj, str):
        return redact(obj)
    if isinstance(obj, dict):
        return {k: ("[REDACTED]" if _SECRET_KEY.search(str(k)) and isinstance(v, str) and v else redact_obj(v))
                for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [redact_obj(v) for v in obj]
    return obj


class RedactingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        try:
            record.msg = redact(record.getMessage())
            record.args = ()
        except Exception:
            pass
        return True


class AuditLog:
    """Append-only JSONL audit trail of tool use. Values are redacted; screenshots never stored."""

    def __init__(self, path: Path, enabled: bool = True):
        self.path, self.enabled = Path(path), enabled
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def write(self, kind: str, **data) -> None:
        if not self.enabled:
            return
        data.pop("image_b64", None)
        rec = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "kind": kind, **redact_obj(data)}
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False)[:4000] + "\n")

    def purge_older_than(self, days: int) -> int:
        if not self.path.exists() or days <= 0:
            return 0
        cutoff = time.time() - days * 86400
        keep, dropped = [], 0
        for line in self.path.read_text(encoding="utf-8").splitlines():
            try:
                ts = time.mktime(time.strptime(json.loads(line)["ts"], "%Y-%m-%dT%H:%M:%S"))
            except Exception:
                keep.append(line); continue
            if ts >= cutoff: keep.append(line)
            else: dropped += 1
        self.path.write_text("\n".join(keep) + ("\n" if keep else ""), encoding="utf-8")
        return dropped


def path_allowed(path: str | Path, allowed_dirs: list[str]) -> Path | None:
    """Return the resolved path if it lies inside an allowed directory, else None."""
    try:
        p = Path(path).expanduser().resolve()
    except Exception:
        return None
    for d in allowed_dirs:
        try:
            if p.is_relative_to(Path(d).expanduser().resolve()):
                return p
        except Exception:
            continue
    return None


def url_allowed(url: str, allowed_domains: list[str] | None = None) -> tuple[bool, str]:
    try:
        u = urlparse(url)
    except Exception:
        return False, "Malformed URL"
    if u.scheme.lower() not in ("http", "https"):
        return False, f"Scheme '{u.scheme}' is not allowed"
    if not u.hostname:
        return False, "URL has no host"
    if allowed_domains:
        host = u.hostname.lower()
        if not any(host == d.lower() or host.endswith("." + d.lower()) for d in allowed_domains):
            return False, f"Domain '{host}' is not in the allowed list"
    return True, ""
