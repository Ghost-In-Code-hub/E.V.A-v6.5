from __future__ import annotations

import json
import os

from .base import Provider, ProviderError, http_error, new_call_id
from .openai_provider import to_openai_tools


def to_ollama_messages(messages: list[dict], system: str | None) -> list[dict]:
    out: list[dict] = [{"role": "system", "content": system}] if system else []
    for m in messages:
        r = m["role"]
        if r == "user":
            msg = {"role": "user", "content": m.get("content", "")}
            if m.get("images"): msg["images"] = m["images"]
            out.append(msg)
        elif r == "assistant":
            msg = {"role": "assistant", "content": m.get("content", "")}
            if m.get("tool_calls"):
                msg["tool_calls"] = [{"function": {"name": c["name"], "arguments": c["arguments"]}} for c in m["tool_calls"]]
            out.append(msg)
        elif r == "tool":
            out.append({"role": "tool", "tool_name": m.get("name", ""), "content": m.get("content", "")})
    return out


class OllamaProvider(Provider):
    name = "ollama"

    @property
    def base(self) -> str:
        return os.environ.get("OLLAMA_BASE_URL", "http://127.0.0.1:11434").rstrip("/")

    def configured(self):
        return True, ""  # no key; reachability is checked at call time

    async def stream(self, messages, tools, system, *, model, timeout):
        import httpx
        if not model: raise ProviderError("OLLAMA_MODEL is not set. Pick an installed model in Settings > AI.", "not_configured")
        body = {"model": model, "messages": to_ollama_messages(messages, system), "stream": True}
        if tools: body["tools"] = to_openai_tools(tools)
        try:
            async with httpx.AsyncClient(timeout=httpx.Timeout(timeout, connect=5)) as c:
                async with c.stream("POST", f"{self.base}/api/chat", json=body) as r:
                    if r.status_code >= 400:
                        raise http_error(r.status_code, (await r.aread()).decode("utf-8", "replace"))
                    async for line in r.aiter_lines():
                        if not line.strip(): continue
                        d = json.loads(line)
                        if d.get("error"): raise ProviderError(str(d["error"])[:300], "server")
                        msg = d.get("message") or {}
                        if msg.get("content"): yield {"type": "text", "text": msg["content"]}
                        for tc in msg.get("tool_calls") or []:
                            fn = tc.get("function", {})
                            args = fn.get("arguments", {})
                            if isinstance(args, str):
                                try: args = json.loads(args)
                                except Exception: args = {}
                            yield {"type": "tool_call", "id": new_call_id(), "name": fn.get("name", ""), "arguments": args}
                        if d.get("done"):
                            yield {"type": "usage", "input_tokens": d.get("prompt_eval_count", 0),
                                   "output_tokens": d.get("eval_count", 0)}
        except httpx.ConnectError as e:
            raise ProviderError(f"Cannot reach Ollama at {self.base}. Is it running?", "network") from e
        except httpx.TimeoutException as e:
            raise ProviderError("Ollama request timed out", "timeout") from e
        yield {"type": "done"}

    async def list_models(self, timeout=15):
        import httpx
        try:
            async with httpx.AsyncClient(timeout=timeout) as c:
                r = await c.get(f"{self.base}/api/tags")
        except httpx.HTTPError as e:
            raise ProviderError(f"Cannot reach Ollama at {self.base}. Is it running?", "network") from e
        if r.status_code >= 400: raise http_error(r.status_code, r.text)
        return [m["name"] for m in r.json().get("models", [])]
