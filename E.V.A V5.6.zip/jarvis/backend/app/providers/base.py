"""Provider interface + shared helpers.

Neutral message format used everywhere inside Jarvis:
  {"role": "user", "content": str, "images": [b64png, ...]?}
  {"role": "assistant", "content": str, "tool_calls": [{"id","name","arguments":dict}]?}
  {"role": "tool", "tool_call_id": str, "name": str, "content": str}
Tool spec: {"name","description","parameters": <JSON schema>}
Stream events yielded by providers:
  {"type":"text","text":str} | {"type":"tool_call","id","name","arguments":dict}
  {"type":"usage","input_tokens":int,"output_tokens":int} | {"type":"done"}
"""
from __future__ import annotations

import json
import uuid
from typing import AsyncIterator


class ProviderError(Exception):
    def __init__(self, message: str, kind: str = "error"):
        super().__init__(message)
        self.kind = kind  # not_configured | auth | rate_limit | timeout | network | bad_request | server | error


def parse_args(raw) -> dict:
    if isinstance(raw, dict):
        return raw
    if not raw:
        return {}
    try:
        v = json.loads(raw)
        return v if isinstance(v, dict) else {"value": v}
    except json.JSONDecodeError:
        return {"_parse_error": str(raw)[:200]}


def new_call_id() -> str:
    return "call_" + uuid.uuid4().hex[:16]


def http_error(status: int, body: str) -> ProviderError:
    body = (body or "")[:300]
    if status in (401, 403):
        return ProviderError(f"Authentication failed ({status}). Check the API key. {body}", "auth")
    if status == 429:
        return ProviderError(f"Rate limited or quota exceeded (429). {body}", "rate_limit")
    if 400 <= status < 500:
        return ProviderError(f"Request rejected ({status}): {body}", "bad_request")
    return ProviderError(f"Provider server error ({status}): {body}", "server")


async def sse_lines(resp) -> AsyncIterator[tuple[str | None, str]]:
    """Yield (event_name, data) pairs from an httpx streaming response (SSE)."""
    ev = None
    async for line in resp.aiter_lines():
        if not line:
            ev = None
            continue
        if line.startswith("event:"):
            ev = line[6:].strip()
        elif line.startswith("data:"):
            yield ev, line[5:].strip()


class Provider:
    name = "base"
    needs_model = True
    _client = None

    def client(self):
        """One long-lived HTTP client per provider: keep-alive connections avoid a TLS handshake on every request."""
        import httpx
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(limits=httpx.Limits(max_keepalive_connections=4, keepalive_expiry=120),
                                             timeout=httpx.Timeout(60, connect=10))
        return self._client

    async def warm(self) -> None:
        """Best-effort connection pre-warm (never raises)."""

    def configured(self) -> tuple[bool, str]:
        raise NotImplementedError

    async def stream(self, messages, tools, system, *, model: str, timeout: float) -> AsyncIterator[dict]:
        raise NotImplementedError
        yield {}  # pragma: no cover

    async def list_models(self, timeout: float = 15) -> list[str]:
        raise NotImplementedError
