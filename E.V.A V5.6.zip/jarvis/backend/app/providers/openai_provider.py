from __future__ import annotations

import json
import os

from .base import Provider, ProviderError, http_error, new_call_id, parse_args, sse_lines


def to_openai_messages(messages: list[dict], system: str | None) -> list[dict]:
    out: list[dict] = []
    if system:
        out.append({"role": "system", "content": system})
    for m in messages:
        r = m["role"]
        if r == "user":
            if m.get("images"):
                parts = [{"type": "text", "text": m.get("content", "")}]
                parts += [{"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b}"}} for b in m["images"]]
                out.append({"role": "user", "content": parts})
            else:
                out.append({"role": "user", "content": m.get("content", "")})
        elif r == "assistant":
            msg: dict = {"role": "assistant", "content": m.get("content") or None}
            if m.get("tool_calls"):
                msg["tool_calls"] = [{"id": c["id"], "type": "function",
                                      "function": {"name": c["name"], "arguments": json.dumps(c["arguments"])}}
                                     for c in m["tool_calls"]]
            out.append(msg)
        elif r == "tool":
            out.append({"role": "tool", "tool_call_id": m["tool_call_id"], "content": m.get("content", "")})
    return out


def to_openai_tools(tools: list[dict]) -> list[dict]:
    return [{"type": "function", "function": {"name": t["name"], "description": t["description"],
                                              "parameters": t["parameters"]}} for t in tools]


class OpenAIStreamParser:
    """Accumulates Chat Completions streaming chunks into neutral events."""

    def __init__(self) -> None:
        self.calls: dict[int, dict] = {}

    def feed(self, chunk: dict) -> list[dict]:
        evs: list[dict] = []
        if chunk.get("error"):                      # OpenRouter reports mid-stream failures as an `error` object
            e = chunk["error"]
            raise ProviderError(str(e.get("message", e))[:300] if isinstance(e, dict) else str(e)[:300], "server")
        if chunk.get("usage"):
            u = chunk["usage"]
            evs.append({"type": "usage", "input_tokens": u.get("prompt_tokens", 0),
                        "output_tokens": u.get("completion_tokens", 0)})
        for ch in chunk.get("choices") or []:
            d = ch.get("delta") or {}
            if d.get("content"):
                evs.append({"type": "text", "text": d["content"]})
            for tc in d.get("tool_calls") or []:
                slot = self.calls.setdefault(tc.get("index", 0), {"id": "", "name": "", "args": ""})
                if tc.get("id"): slot["id"] = tc["id"]
                fn = tc.get("function") or {}
                if fn.get("name"): slot["name"] += fn["name"]
                if fn.get("arguments"): slot["args"] += fn["arguments"]
        return evs

    def finish(self) -> list[dict]:
        out = [{"type": "tool_call", "id": c["id"] or new_call_id(), "name": c["name"],
                "arguments": parse_args(c["args"])} for _, c in sorted(self.calls.items()) if c["name"]]
        self.calls = {}
        return out


class OpenAIProvider(Provider):
    name = "openai"

    @property
    def base(self) -> str:
        return os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")

    def configured(self):
        if not os.environ.get("OPENAI_API_KEY"):
            return False, "OPENAI_API_KEY is not set"
        return True, ""

    def _headers(self):
        return {"Authorization": f"Bearer {os.environ.get('OPENAI_API_KEY','')}", "Content-Type": "application/json"}

    async def stream(self, messages, tools, system, *, model, timeout):
        import httpx
        ok, why = self.configured()
        if not ok: raise ProviderError(why, "not_configured")
        if not model: raise ProviderError("OPENAI_MODEL is not set. Choose a model in Settings > AI.", "not_configured")
        body = {"model": model, "messages": to_openai_messages(messages, system), "stream": True,
                "stream_options": {"include_usage": True}}
        if tools: body["tools"] = to_openai_tools(tools)
        parser = OpenAIStreamParser()
        try:
            async with self.client().stream("POST", f"{self.base}/chat/completions", headers=self._headers(), json=body,
                                            timeout=httpx.Timeout(timeout, connect=10)) as r:
                if r.status_code >= 400:
                    raise http_error(r.status_code, (await r.aread()).decode("utf-8", "replace"))
                async for _, data in sse_lines(r):
                    if data == "[DONE]": break
                    for ev in parser.feed(json.loads(data)): yield ev
        except httpx.TimeoutException as e:
            raise ProviderError("Provider request timed out", "timeout") from e
        except httpx.HTTPError as e:
            raise ProviderError(f"Network error: {type(e).__name__}", "network") from e
        for ev in parser.finish(): yield ev
        yield {"type": "done"}

    async def list_models(self, timeout=15):
        ok, why = self.configured()
        if not ok: raise ProviderError(why, "not_configured")
        import httpx
        try:
            async with httpx.AsyncClient(timeout=timeout) as c:
                r = await c.get(f"{self.base}/models", headers=self._headers())
        except httpx.HTTPError as e:
            raise ProviderError(f"Network error: {type(e).__name__}", "network") from e
        if r.status_code >= 400: raise http_error(r.status_code, r.text)
        return sorted(m["id"] for m in r.json().get("data", []))
