from __future__ import annotations

from .anthropic_provider import AnthropicProvider
from .base import Provider, ProviderError
from .ollama_provider import OllamaProvider
from .openai_provider import OpenAIProvider
from .openrouter_provider import OpenRouterProvider


class ProviderGateway:
    def __init__(self, settings, providers: dict[str, Provider] | None = None):
        self.settings = settings
        self.providers = providers or {"openrouter": OpenRouterProvider(), "openai": OpenAIProvider(), "anthropic": AnthropicProvider(), "ollama": OllamaProvider()}

    @property
    def active_name(self) -> str:
        return self.settings["ai"]["provider"]

    def active(self) -> Provider:
        p = self.providers.get(self.active_name)
        if not p: raise ProviderError(f"Unknown provider '{self.active_name}'", "not_configured")
        return p

    def model(self, name: str | None = None) -> str:
        return self.settings["ai"]["models"].get(name or self.active_name, "")

    def status(self) -> dict:
        out = {}
        for n, p in self.providers.items():
            ok, why = p.configured()
            out[n] = {"configured": ok, "reason": why, "model": self.model(n), "active": n == self.active_name}
        return out

    def ready(self) -> tuple[bool, str]:
        ok, why = self.active().configured()
        if not ok: return False, why
        if self.active().needs_model and not self.model():
            return False, f"{self.active_name}: set {self.active_name.upper()}_MODEL in .env (or use OpenRouter, which needs no model)"
        return True, ""

    async def stream(self, messages, tools, system):
        ok, why = self.ready()
        if not ok: raise ProviderError(why, "not_configured")
        ai = self.settings["ai"]
        async for ev in self.active().stream(messages, tools, system, model=self.model(), timeout=float(ai["timeout_s"])):
            yield ev

    async def warm(self) -> None:
        await self.active().warm()

    async def test(self, name: str | None = None) -> dict:
        p = self.providers[name or self.active_name]
        try:
            if p.name == "openrouter":
                info = await p.validate_key()
                return {"ok": True, "provider": p.name, "models": [], "model_found": None, "label": info.get("label")}
            models = await p.list_models()
            m = self.model(p.name)
            return {"ok": True, "provider": p.name, "models": models[:200],
                    "model_found": (m in models) if m else None}
        except ProviderError as e:
            return {"ok": False, "provider": p.name, "error": str(e), "kind": e.kind}
