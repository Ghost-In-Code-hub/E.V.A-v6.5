from __future__ import annotations

import json
import os

from .base import Provider, ProviderError, http_error, new_call_id, parse_args, sse_lines

API_VERSION = "2023-06-01"


def to_anthropic_messages(messages: list[dict]) -> list[dict]:
    out: list[dict] = []

    def push(role: str, blocks: list[dict]):
        if out and out[-1]["role"] == role:  # API requires alternating roles: merge neighbours
            out[-1]["content"].extend(blocks)
        else:
            out.append({"role": role, "content": blocks})

    for m in messages:
        r = m["role"]
        if r == "user":
            blocks = [{"type": "image", "source": {"type": "base64", "media_type": "image/png", "data": b}}
                      for b in m.get("images", [])]
            blocks.append({"type": "text", "text": m.get("content") or "(empty)"})
            push("user", blocks)
        elif r == "assistant":
            blocks = []
            if m.get("content"): blocks.append({"type": "text", "text": m["content"]})
            for c in m.get("tool_calls") or []:
                blocks.append({"type": "tool_use", "id": c["id"], "name": c["name"], "input": c["arguments"]})
            if blocks: push("assistant", blocks)
        elif r == "tool":
            push("user", [{"type": "tool_result", "tool_use_id": m["tool_call_id"], "content": m.get("content", "")}])
    return out


def to_anthropic_tools(tools: list[dict]) -> list[dict]:
    return [{"name": t["name"], "description": t["description"], "input_schema": t["parameters"]} for t in tools]


class AnthropicStreamParser:
    def __init__(self) -> None:
        self.blocks: dict[int, dict] = {}
        self.in_tokens = 0

    def feed(self, event: str | None, d: dict) -> list[dict]:
        t = d.get("type", event)
        if t == "message_start":
            self.in_tokens = (d.get("message", {}).get("usage") or {}).get("input_tokens", 0)
        elif t == "content_block_start":
            cb = d.get("content_block", {})
            if cb.get("type") == "tool_use":
                self.blocks[d["index"]] = {"id": cb.get("id") or new_call_id(), "name": cb.get("name", ""), "json": ""}
        elif t == "content_block_delta":
            dl = d.get("delta", {})
            if dl.get("type") == "text_delta":
                return [{"type": "text", "text": dl.get("text", "")}]
            if dl.get("type") == "input_json_delta" and d["index"] in self.blocks:
                self.blocks[d["index"]]["json"] += dl.get("partial_json", "")
        elif t == "content_block_stop":
            b = self.blocks.pop(d.get("index"), None)
            if b:
                return [{"type": "tool_call", "id": b["id"], "name": b["name"], "arguments": parse_args(b["json"])}]
        elif t == "message_delta":
            u = d.get("usage") or {}
            return [{"type": "usage", "input_tokens": self.in_tokens, "output_tokens": u.get("output_tokens", 0)}]
        elif t == "error":
            raise ProviderError(d.get("error", {}).get("message", "Anthropic stream error"), "server")
        return []


class AnthropicProvider(Provider):
    name = "anthropic"
    base = "https://api.anthropic.com/v1"

    def configured(self):
        if not os.environ.get("ANTHROPIC_API_KEY"):
            return False, "ANTHROPIC_API_KEY is not set"
        return True, ""

    def _headers(self):
        return {"x-api-key": os.environ.get("ANTHROPIC_API_KEY", ""), "anthropic-version": API_VERSION,
                "content-type": "application/json"}

    async def stream(self, messages, tools, system, *, model, timeout):
        import httpx
        ok, why = self.configured()
        if not ok: raise ProviderError(why, "not_configured")
        if not model: raise ProviderError("ANTHROPIC_MODEL is not set. Choose a model in Settings > AI.", "not_configured")
        body = {"model": model, "max_tokens": 4096, "messages": to_anthropic_messages(messages), "stream": True}
        if system: body["system"] = system
        if tools: body["tools"] = to_anthropic_tools(tools)
        parser = AnthropicStreamParser()
        try:
            async with httpx.AsyncClient(timeout=httpx.Timeout(timeout, connect=10)) as c:
                async with c.stream("POST", f"{self.base}/messages", headers=self._headers(), json=body) as r:
                    if r.status_code >= 400:
                        raise http_error(r.status_code, (await r.aread()).decode("utf-8", "replace"))
                    async for ev, data in sse_lines(r):
                        for out in parser.feed(ev, json.loads(data)): yield out
        except httpx.TimeoutException as e:
            raise ProviderError("Provider request timed out", "timeout") from e
        except httpx.HTTPError as e:
            raise ProviderError(f"Network error: {type(e).__name__}", "network") from e
        yield {"type": "done"}

    async def list_models(self, timeout=15):
        ok, why = self.configured()
        if not ok: raise ProviderError(why, "not_configured")
        import httpx
        try:
            async with httpx.AsyncClient(timeout=timeout) as c:
                r = await c.get(f"{self.base}/models", headers=self._headers(), params={"limit": 100})
        except httpx.HTTPError as e:
            raise ProviderError(f"Network error: {type(e).__name__}", "network") from e
        if r.status_code >= 400: raise http_error(r.status_code, r.text)
        return [m["id"] for m in r.json().get("data", [])]
