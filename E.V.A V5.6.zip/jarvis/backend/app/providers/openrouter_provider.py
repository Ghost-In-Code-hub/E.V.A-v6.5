"""OpenRouter: OpenAI-compatible chat API with ONE key and NO model id.

`openrouter/auto` lets OpenRouter pick a suitable model per request (tool calling works with the routed model).
`provider.sort = "latency"` asks for the fastest endpoint. Advanced users may pin a model with OPENROUTER_MODEL
in .env, but nothing in the UI asks for one."""
from __future__ import annotations

import json
import os

from .base import ProviderError, http_error, sse_lines
from .openai_provider import OpenAIProvider, OpenAIStreamParser, to_openai_messages, to_openai_tools

DEFAULT_MODELS = ("openrouter/auto", "openrouter/auto-beta")   # tried in order if the first slug is rejected


def candidate_models(pinned: str = "") -> list[str]:
    env = os.environ.get("OPENROUTER_MODEL", "").strip()
    return [m for m in (pinned.strip(), env) if m][:1] or list(DEFAULT_MODELS)


def build_body(messages, tools, system, model: str) -> dict:
    body = {"model": model, "messages": to_openai_messages(messages, system), "stream": True,
            "usage": {"include": True}, "provider": {"sort": "latency"}}
    if tools:
        body["tools"] = to_openai_tools(tools)
    return body


class OpenRouterProvider(OpenAIProvider):
    name = "openrouter"
    needs_model = False
    base = "https://openrouter.ai/api/v1"

    def configured(self):
        return (True, "") if os.environ.get("OPENROUTER_API_KEY") else (False, "Add your OpenRouter API key in Settings")

    def _headers(self):
        return {"Authorization": f"Bearer {os.environ.get('OPENROUTER_API_KEY', '')}", "Content-Type": "application/json",
                "HTTP-Referer": "https://github.com/jarvis-desktop", "X-Title": "JARVIS"}

    async def stream(self, messages, tools, system, *, model, timeout):
        import httpx
        ok, why = self.configured()
        if not ok: raise ProviderError(why, "not_configured")
        last: ProviderError | None = None
        for slug in candidate_models(model):
            parser, started = OpenAIStreamParser(), False
            try:
                async with self.client().stream("POST", f"{self.base}/chat/completions", headers=self._headers(),
                                                json=build_body(messages, tools, system, slug),
                                                timeout=httpx.Timeout(timeout, connect=10)) as r:
                    if r.status_code in (400, 404) and slug in DEFAULT_MODELS:
                        last = http_error(r.status_code, (await r.aread()).decode("utf-8", "replace"))
                        continue                                  # slug retired -> try the next auto router
                    if r.status_code >= 400:
                        raise http_error(r.status_code, (await r.aread()).decode("utf-8", "replace"))
                    async for _, data in sse_lines(r):
                        if data == "[DONE]": break
                        for ev in parser.feed(json.loads(data)):
                            started = True
                            yield ev
            except httpx.TimeoutException as e:
                raise ProviderError("The AI took too long to answer. Try again.", "timeout") from e
            except httpx.HTTPError as e:
                raise ProviderError(f"Network error: {type(e).__name__}. Check your internet connection.", "network") from e
            for ev in parser.finish(): yield ev
            yield {"type": "done"}
            return
        raise last or ProviderError("OpenRouter rejected the request", "bad_request")

    async def validate_key(self, timeout=15) -> dict:
        import httpx
        ok, why = self.configured()
        if not ok: raise ProviderError(why, "not_configured")
        try:
            r = await self.client().get(f"{self.base}/key", headers=self._headers(), timeout=timeout)
        except httpx.HTTPError as e:
            raise ProviderError(f"Network error: {type(e).__name__}", "network") from e
        if r.status_code >= 400: raise http_error(r.status_code, r.text)
        return r.json().get("data", {})

    async def list_models(self, timeout=15):
        await self.validate_key(timeout)
        return []                                                  # nothing to choose: routing is automatic

    async def warm(self):
        try:
            if self.configured()[0]: await self.validate_key(8)
        except Exception:
            pass
