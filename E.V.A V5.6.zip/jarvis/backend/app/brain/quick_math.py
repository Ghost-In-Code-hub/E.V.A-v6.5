"""Instant local arithmetic: "3428*897", "3428 times 897", "what is twelve plus five", "write 10".
Answered without calling the AI at all (zero network latency). Uses the same safe AST evaluator as the calculator tool."""
from __future__ import annotations

import re
from dataclasses import dataclass

from ..tools.calculator import safe_eval

_ONES = {"zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10, "eleven": 11,
         "twelve": 12, "thirteen": 13, "fourteen": 14, "fifteen": 15, "sixteen": 16, "seventeen": 17, "eighteen": 18, "nineteen": 19}
_TENS = {"twenty": 20, "thirty": 30, "forty": 40, "fifty": 50, "sixty": 60, "seventy": 70, "eighty": 80, "ninety": 90}
_SCALE = {"hundred": 100, "thousand": 1_000, "million": 1_000_000, "billion": 1_000_000_000}
_NUMWORD = set(_ONES) | set(_TENS) | set(_SCALE) | {"and"}

_OPS = [  # order matters (longest phrases first)
    (r"\b(?:multiplied by|multiply by|times|multiplied|into|star)\b", "*"), (r"\b(?:divided by|divide by|over)\b", "/"),
    (r"\b(?:to the power of|raised to the power of|raised to|power)\b", "**"), (r"\b(?:plus|add|and)\b(?=\s*[\d(])", "+"),
    (r"\b(?:minus|subtract|less)\b", "-"), (r"\b(?:modulo|mod|remainder)\b", "%"), (r"\bsquared\b", "**2"), (r"\bcubed\b", "**3"),
    (r"[×✕✖]", "*"), (r"[÷]", "/"), (r"(?<=\d)\s*[xX]\s*(?=\d)", "*"), (r"\^", "**"),
]
_FILLER = re.compile(r"\b(?:jarvis|please|hey|what\s+is|what's|whats|calculate|compute|solve|tell me|how much is|find|write|type|say|equals?|is)\b|[=?!]|\bthe (?:answer|result)\b", re.I)


def words_to_numbers(text: str) -> str:
    """'twenty five times three hundred' -> '25 times 300';  'two thousand five hundred' -> '2500'."""
    toks, out = text.split(), []
    total = cur = 0
    have = False

    def flush():
        nonlocal total, cur, have
        if have: out.append(str(total + cur))
        total = cur = 0; have = False

    for i, raw in enumerate(toks):
        t = raw.lower().strip(",.")
        if t in _ONES: cur += _ONES[t]; have = True
        elif t in _TENS: cur += _TENS[t]; have = True
        elif t == "hundred" and have: cur = (cur or 1) * 100
        elif t in ("thousand", "million", "billion") and have: total += (cur or 1) * _SCALE[t]; cur = 0
        elif t == "and" and have and i + 1 < len(toks) and toks[i + 1].lower().strip(",.") in (set(_ONES) | set(_TENS)): continue
        else: flush(); out.append(raw)
    flush()
    return " ".join(out)


@dataclass
class MathResult:
    expression: str   # pretty, e.g. "3,428 × 897"
    value: float | int
    display: str      # e.g. "3,074,916"
    text: str         # written reply
    spoken: str = ""  # TTS-friendly sentence


def _fmt(v) -> str:
    if isinstance(v, float):
        if v == int(v) and abs(v) < 1e15: v = int(v)
        else: return f"{v:,.10g}" if abs(v) < 1e15 else f"{v:.6e}"
    return f"{v:,}"


def _pretty(expr: str) -> str:
    e = expr.replace("**2", "²").replace("**3", "³").replace("**", "^").replace("*", " × ").replace("/", " ÷ ")
    e = re.sub(r"\s+", " ", re.sub(r"(\d)\s*([+\-])\s*(\d)", r"\1 \2 \3", e)).strip()
    return re.sub(r"\b\d{4,}\b", lambda m: f"{int(m.group()):,}", e)


def quick_math(text: str) -> MathResult | None:
    if not text or len(text) > 160:
        return None
    t = text.lower().strip()
    has_write = bool(re.match(r"^\s*(?:jarvis[, ]+)?(?:please\s+)?(?:write|type|say)\b", t))
    t = _FILLER.sub(" ", t)
    t = words_to_numbers(t)
    t = re.sub(r"(?<=\d),(?=\d{3}\b)", "", t)                       # 3,428 -> 3428
    t = re.sub(r"[,;:]", " ", t)
    pm = re.search(r"(\d+(?:\.\d+)?)\s*(?:percent|%)\s*of\s*(\d+(?:\.\d+)?)", t)
    t = re.sub(r"(\d+(?:\.\d+)?)\s*(?:percent|%)\s*of\s*(\d+(?:\.\d+)?)", r"(\1/100*\2)", t)   # 15 percent of 200
    for pat, rep in _OPS: t = re.sub(pat, f" {rep} ", t)
    t = re.sub(r"\s+", " ", t).strip().rstrip(".")
    if not t or re.search(r"[^\d\s+\-*/%().]", t): return None
    has_op = bool(re.search(r"\d\s*(?:\*\*|[+\-*/%])\s*[\d(]|\(.*\)", t))
    if not has_op and not (has_write and re.fullmatch(r"-?\d+(?:\.\d+)?", t)): return None
    try:
        v = safe_eval(t)
    except Exception:
        return None
    if isinstance(v, float) and (v != v or abs(v) == float("inf")): return None
    disp, expr = _fmt(v), (f"{pm.group(1)}% of {pm.group(2)}" if pm else _pretty(t))
    spoken_expr = (expr.replace("×", " times ").replace("÷", " divided by ").replace("²", " squared").replace("³", " cubed")
                   .replace("^", " to the power of ").replace("%", " percent").replace(" - ", " minus ").replace(" + ", " plus "))
    spoken_expr = re.sub(r"\s+", " ", spoken_expr).strip()
    return MathResult(expr, v, disp, disp if not has_op else f"{expr} = {disp}", f"{disp}." if not has_op else f"{spoken_expr} equals {disp}.")
