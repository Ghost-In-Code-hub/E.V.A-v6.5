"""Voice session: routes microphone frames to the right local analyser depending on assistant state.

STANDBY   -> ClapDetector (local only; nothing is recorded or transmitted)
LISTENING -> UtteranceCollector (audio kept in RAM until the utterance ends, then sent to STT)
SPEAKING  -> ClapDetector only (clap acts as an interrupt)
"""
from __future__ import annotations

import numpy as np

from .voice_activity import UtteranceCollector, float_to_wav, pcm16_to_float
from .wake_detector import ClapDetector


class VoiceSession:
    def __init__(self, settings):
        self.settings = settings
        v = settings["voice"]
        self.clap = ClapDetector(v["clap"]["sensitivity"], v["clap"]["cooldown_s"])
        self.collector: UtteranceCollector | None = None
        self.mic_enabled = False
        self._last_speaking = False

    def apply_settings(self):
        c = self.settings["voice"]["clap"]
        self.clap.set_sensitivity(c["sensitivity"]); self.clap.cooldown_s = c["cooldown_s"]

    def begin_utterance(self):
        v = self.settings["voice"]
        self.collector = UtteranceCollector(v["silence_timeout_s"], v["no_speech_timeout_s"], v["max_utterance_s"])
        self.clap.reset()

    def end_utterance(self):
        self.collector = None

    def feed(self, pcm: bytes, state: str) -> list[dict]:
        """Returns list of actions: {'type':'wake','source':'clap'} | {'type':'utterance','wav':bytes} |
        {'type':'no_speech'} | {'type':'vad','speaking':bool}"""
        if not self.mic_enabled:
            return []
        x = pcm16_to_float(pcm)
        out: list[dict] = []
        if state == "LISTENING" and self.collector:
            st = self.collector.feed(x)
            sp = self.collector.speaking
            if sp != self._last_speaking:
                self._last_speaking = sp
                out.append({"type": "vad", "speaking": sp})
            if st == "done":
                wav = float_to_wav(self.collector.audio()); self.collector = None
                out.append({"type": "utterance", "wav": wav})
            elif st == "no_speech":
                self.collector = None
                out.append({"type": "no_speech"})
        elif state in ("STANDBY", "SPEAKING") and self.settings["voice"]["clap"]["enabled"]:
            if self.clap.process(x):
                out.append({"type": "wake", "source": "clap"})
        return out
