"""Streaming text-to-speech: speaks sentence-by-sentence WHILE the model is still generating.

feed(delta) splits the growing text into sentences; each sentence is synthesised concurrently (bounded) and
emitted strictly in order. Time-to-first-audio = first sentence only, not the whole answer."""
from __future__ import annotations

import asyncio
import re

from ..providers.base import ProviderError
from .synthesis import clean_for_speech

_END = re.compile(r"(?<=[.!?؟۔…])[\"')\]]*\s+|\n+")
FIRST_MIN, NEXT_MIN, MAX_LEN = 14, 28, 260


def split_sentences(buf: str, first: bool, final: bool = False) -> tuple[list[str], str]:
    """Return (complete sentences, remainder). Short fragments are merged so we never speak 'Sure.' alone twice."""
    out, last, pending = [], 0, ""
    for m in _END.finditer(buf):
        chunk = buf[last:m.end()]
        if len((pending + chunk).strip()) >= (FIRST_MIN if first and not out else NEXT_MIN):
            out.append((pending + chunk).strip()); pending = ""
        else:
            pending += chunk
        last = m.end()
    rest = pending + buf[last:]
    if len(rest) > MAX_LEN:                                   # no punctuation for a long time: cut at a space
        cut = rest.rfind(" ", 0, MAX_LEN)
        if cut > 40:
            out.append(rest[:cut].strip()); rest = rest[cut:]
    if final and rest.strip():
        out.append(rest.strip()); rest = ""
    return out, rest


class SpeechPipeline:
    def __init__(self, synth, language: str, voice: str, emit_audio, on_error, max_parallel: int = 2):
        self.synth, self.language, self.voice = synth, language, voice
        self.emit_audio, self.on_error = emit_audio, on_error
        self._buf, self._sem = "", asyncio.Semaphore(max_parallel)
        self._q: asyncio.Queue = asyncio.Queue()
        self._n = 0
        self._failed = False
        self.emitted = 0
        self._consumer = asyncio.create_task(self._consume())

    def feed(self, delta: str) -> None:
        if self._failed: return
        self._buf += delta
        sents, self._buf = split_sentences(self._buf, first=self._n == 0)
        for s in sents: self._submit(s)

    def _submit(self, sentence: str) -> None:
        text = clean_for_speech(sentence)
        if len(text) < 2: return
        task = asyncio.create_task(self._synth(text))
        self._q.put_nowait((self._n, text, task)); self._n += 1

    async def _synth(self, text: str):
        async with self._sem:
            return await asyncio.wait_for(self.synth.synth(text, self.language, self.voice), 30)

    async def _consume(self):
        while True:
            item = await self._q.get()
            if item is None: return
            seq, text, task = item
            if self._failed:
                task.cancel(); continue
            try:
                audio, mime = await task
            except asyncio.CancelledError:
                raise
            except (ProviderError, asyncio.TimeoutError, Exception) as e:
                self._failed = True
                await self.on_error(str(e) if isinstance(e, ProviderError) else f"Speech synthesis failed ({type(e).__name__})")
                continue
            self.emitted += 1
            await self.emit_audio(seq, audio, mime, text, False)

    async def finish(self) -> int:
        """Flush the tail, wait for everything to be emitted, send the end marker. Returns chunks emitted."""
        if not self._failed:
            sents, self._buf = split_sentences(self._buf, first=self._n == 0, final=True)
            for s in sents: self._submit(s)
        self._q.put_nowait(None)
        await self._consumer
        if self.emitted: await self.emit_audio(self._n, b"", "", "", True)
        return self.emitted

    def cancel(self) -> None:
        self._failed = True
        self._consumer.cancel()
        while not self._q.empty():
            it = self._q.get_nowait()
            if it: it[2].cancel()
