"""Energy-based voice activity detection + utterance collection with silence timeout (numpy)."""
from __future__ import annotations

import numpy as np


class VoiceActivityDetector:
    def __init__(self, sample_rate: int = 16000, start_ratio: float = 3.0, min_rms: float = 0.012):
        self.frame = int(sample_rate * 0.03)
        self.floor, self.start_ratio, self.min_rms = 0.005, start_ratio, min_rms
        self._buf = np.zeros(0, dtype=np.float32)
        self.speaking = False

    def process(self, x: np.ndarray) -> list[bool]:
        self._buf = np.concatenate([self._buf, np.asarray(x, dtype=np.float32)])
        out = []
        while len(self._buf) >= self.frame:
            fr, self._buf = self._buf[:self.frame], self._buf[self.frame:]
            rms = float(np.sqrt(np.mean(fr * fr)))
            speech = rms > max(self.min_rms, self.floor * self.start_ratio)
            if not speech:
                self.floor = 0.95 * self.floor + 0.05 * max(rms, 0.001)
            out.append(speech)
        return out


class UtteranceCollector:
    """Collects PCM after a wake event. Ends on `silence_s` of quiet after speech, `no_speech_s` without
    any speech, or `max_s`. Result states: 'collecting' | 'done' | 'no_speech'."""

    def __init__(self, silence_s=1.4, no_speech_s=6.0, max_s=20.0, sr=16000):
        self.silence_s, self.no_speech_s, self.max_s, self.sr = silence_s, no_speech_s, max_s, sr
        self.vad = VoiceActivityDetector(sr)
        self.chunks: list[np.ndarray] = []
        self.elapsed = 0.0
        self.silent_for = 0.0
        self.heard = False
        self.status = "collecting"

    def feed(self, x: np.ndarray) -> str:
        if self.status != "collecting":
            return self.status
        self.chunks.append(np.asarray(x, dtype=np.float32))
        for sp in self.vad.process(x):
            self.elapsed += 0.03
            if sp:
                self.heard, self.silent_for = True, 0.0
            else:
                self.silent_for += 0.03
        if self.heard and self.silent_for >= self.silence_s:
            self.status = "done"
        elif not self.heard and self.elapsed >= self.no_speech_s:
            self.status = "no_speech"
        elif self.elapsed >= self.max_s:
            self.status = "done"
        return self.status

    @property
    def speaking(self) -> bool:
        return self.heard and self.silent_for < 0.15

    def audio(self) -> np.ndarray:
        return np.concatenate(self.chunks) if self.chunks else np.zeros(0, dtype=np.float32)


def pcm16_to_float(b: bytes) -> np.ndarray:
    return np.frombuffer(b[: len(b) // 2 * 2], dtype="<i2").astype(np.float32) / 32768.0


def float_to_wav(x: np.ndarray, sr: int = 16000) -> bytes:
    import io, wave
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes((np.clip(x, -1, 1) * 32767).astype("<i2").tobytes())
    return buf.getvalue()
