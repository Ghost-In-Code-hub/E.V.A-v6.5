"""Local clap detector. Pure numpy, no audio leaves the machine.

A loud sound alone is NOT a clap. A candidate must satisfy ALL of:
  1. onset: frame RMS exceeds an adaptive ambient floor by a sensitivity-dependent ratio AND an absolute minimum
  2. broadband: >= hf_min of its spectral energy lies above 2 kHz (speech, hum and music are low-frequency heavy)
  3. impulsive: energy decays below 30% of its peak within max_duration (sustained noise / speech never decays)
  4. short:     time spent above 50% of peak <= 120 ms
Then a cooldown window suppresses repeats (debounce)."""
from __future__ import annotations

import numpy as np

SR = 16000
FRAME = 320  # 20 ms


class ClapDetector:
    def __init__(self, sensitivity: float = 0.5, cooldown_s: float = 2.0, sample_rate: int = SR,
                 hf_min: float = 0.35, max_duration_ms: int = 220, abs_min_rms: float = 0.035):
        self.sr = sample_rate
        self.frame = int(sample_rate * 0.02)
        self.cooldown_s, self.hf_min = cooldown_s, hf_min
        self.max_frames = max_duration_ms // 20
        self.abs_min_rms = abs_min_rms
        self.set_sensitivity(sensitivity)
        self.floor = 0.01
        self._buf = np.zeros(0, dtype=np.float32)
        self._cand: list[float] | None = None
        self._hold = False      # after a sustained sound, ignore everything until it has fully ended
        self._t = 0.0           # stream time (s)
        self._last_trigger = -1e9
        self.rejected = {"quiet": 0, "narrowband": 0, "sustained": 0, "cooldown": 0}

    def set_sensitivity(self, s: float) -> None:
        s = min(1.0, max(0.0, s))
        self.ratio = 10.0 - 6.5 * s                 # 10x ambient (low) .. 3.5x ambient (high)
        self.abs_min = self.abs_min_rms * (1.6 - 1.0 * s)

    def reset(self) -> None:
        self._buf = np.zeros(0, dtype=np.float32); self._cand = None; self._hold = False

    def _hf_ratio(self, x: np.ndarray) -> float:
        spec = np.abs(np.fft.rfft(x * np.hanning(len(x)))) ** 2
        freqs = np.fft.rfftfreq(len(x), 1 / self.sr)
        tot = spec.sum()
        return float(spec[freqs >= 2000].sum() / tot) if tot > 0 else 0.0

    def process(self, samples: np.ndarray) -> list[float]:
        """Feed float32 samples in [-1,1]. Returns stream timestamps (s) of detected claps."""
        x = np.asarray(samples, dtype=np.float32)
        self._buf = np.concatenate([self._buf, x])
        hits: list[float] = []
        while len(self._buf) >= self.frame:
            fr, self._buf = self._buf[:self.frame], self._buf[self.frame:]
            self._t += 0.02
            rms = float(np.sqrt(np.mean(fr * fr)))
            thr = max(self.abs_min, self.floor * self.ratio)
            if self._hold:
                if rms < 0.5 * thr:
                    self._hold = False
                continue
            if self._cand is None:
                if rms > max(self.abs_min, self.floor * self.ratio):
                    if self._hf_ratio(fr) >= self.hf_min:
                        self._cand = [rms]
                        continue
                    self.rejected["narrowband"] += 1
                # ambient tracking: rises slowly (so sustained noise raises the floor), falls faster
                a = 0.02 if rms > self.floor else 0.1
                self.floor = max(0.0015, (1 - a) * self.floor + a * min(rms, self.floor * 3 + 0.01))
            else:
                self._cand.append(rms)
                peak = max(self._cand)
                if rms < 0.3 * peak and len(self._cand) >= 2:
                    above = sum(1 for r in self._cand if r > 0.5 * peak) * 20
                    self._cand = None
                    if above > 120:
                        self.rejected["sustained"] += 1; self._hold = True
                    elif self._t - self._last_trigger < self.cooldown_s:
                        self.rejected["cooldown"] += 1
                    else:
                        self._last_trigger = self._t
                        hits.append(self._t)
                elif len(self._cand) > self.max_frames:
                    self._cand = None; self._hold = True
                    self.rejected["sustained"] += 1
        return hits
