from __future__ import annotations

import os

from ..providers.base import ProviderError, http_error

LANG_HINT = {"en": "en", "ur": "ur"}
URDU_PROMPT = "The speaker may mix English and Urdu (including Roman Urdu). Transcribe faithfully."


class OpenAITranscriber:
    """OpenAI-compatible /audio/transcriptions (works with OPENAI_BASE_URL overrides)."""
    name = "openai"

    def configured(self):
        return (True, "") if os.environ.get("OPENAI_API_KEY") else (False, "OPENAI_API_KEY is not set (needed for speech recognition)")

    async def transcribe(self, wav: bytes, language: str = "en", timeout: float = 60) -> str:
        import httpx
        ok, why = self.configured()
        if not ok: raise ProviderError(why, "not_configured")
        base = os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
        data = {"model": os.environ.get("OPENAI_STT_MODEL", "whisper-1"), "response_format": "json"}
        if language in LANG_HINT: data["language"] = LANG_HINT[language]
        if language in ("ur", "auto"): data["prompt"] = URDU_PROMPT
        try:
            async with httpx.AsyncClient(timeout=timeout) as c:
                r = await c.post(f"{base}/audio/transcriptions", headers={"Authorization": f"Bearer {os.environ['OPENAI_API_KEY']}"},
                                 data=data, files={"file": ("speech.wav", wav, "audio/wav")})
        except httpx.TimeoutException as e:
            raise ProviderError("Speech recognition timed out", "timeout") from e
        except httpx.HTTPError as e:
            raise ProviderError(f"Speech recognition network error: {type(e).__name__}", "network") from e
        if r.status_code >= 400: raise http_error(r.status_code, r.text)
        return (r.json().get("text") or "").strip()


_OR = None


def get_transcriber(name: str):
    global _OR
    if name == "openrouter":
        _OR = _OR or OpenRouterTranscriber()
        return _OR
    if name == "openai": return OpenAITranscriber()
    raise ProviderError(f"Unknown speech input provider '{name}'", "not_configured")


def pick_stt_model(models: list[str]) -> str:
    """Choose a transcription model automatically (the user never types a model id)."""
    for pref in ("whisper", "transcribe", "stt"):
        for m in models:
            if pref in m.lower(): return m
    return models[0] if models else "openai/whisper-1"


def build_openrouter_stt_body(wav: bytes, model: str, language: str) -> dict:
    import base64
    body = {"model": model, "input_audio": {"data": base64.b64encode(wav).decode(), "format": "wav"}}
    if language in LANG_HINT: body["language"] = LANG_HINT[language]
    return body


class OpenRouterTranscriber:
    """OpenRouter /audio/transcriptions with the same key as chat. Model is discovered automatically."""
    name = "openrouter"
    base = "https://openrouter.ai/api/v1"
    _model: str | None = None
    _client = None

    def configured(self):
        return (True, "") if os.environ.get("OPENROUTER_API_KEY") else (False, "Add your OpenRouter API key in Settings (also used for speech recognition)")

    def _c(self):
        import httpx
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=httpx.Timeout(45, connect=10))
        return self._client

    async def _resolve_model(self, headers) -> str:
        if self._model: return self._model
        try:
            r = await self._c().get(f"{self.base}/models", params={"output_modalities": "transcription"}, headers=headers, timeout=10)
            ids = [m["id"] for m in r.json().get("data", [])] if r.status_code < 400 else []
        except Exception:
            ids = []
        self.__class__._model = pick_stt_model(ids)
        return self._model

    async def transcribe(self, wav: bytes, language: str = "en", timeout: float = 45) -> str:
        import httpx
        ok, why = self.configured()
        if not ok: raise ProviderError(why, "not_configured")
        h = {"Authorization": f"Bearer {os.environ['OPENROUTER_API_KEY']}", "Content-Type": "application/json"}
        body = build_openrouter_stt_body(wav, await self._resolve_model(h), language)
        try:
            r = await self._c().post(f"{self.base}/audio/transcriptions", headers=h, json=body, timeout=timeout)
        except httpx.TimeoutException as e:
            raise ProviderError("Speech recognition timed out", "timeout") from e
        except httpx.HTTPError as e:
            raise ProviderError(f"Speech recognition network error: {type(e).__name__}", "network") from e
        if r.status_code >= 400: raise http_error(r.status_code, r.text)
        return (r.json().get("text") or "").strip()
