"""Text-to-speech providers. All return (audio_bytes, mime). The frontend plays them through a Web Audio
AnalyserNode so the core animation is driven by the real signal amplitude."""
from __future__ import annotations

import asyncio
import os
import re
import tempfile

from ..providers.base import ProviderError, http_error

EDGE_DEFAULT = {"en": "en-GB-RyanNeural", "ur": "ur-PK-AsadNeural"}


def detect_language(text: str, setting: str) -> str:
    if setting in ("en", "ur"): return setting
    return "ur" if re.search(r"[\u0600-\u06FF]", text) else "en"


class EdgeSynth:
    name = "edge"

    def configured(self):
        try:
            import edge_tts  # noqa: F401
            return True, ""
        except Exception:
            return False, "edge-tts is not installed (run setup.bat). It also needs internet access."

    async def synth(self, text: str, language: str, voice: str = "", **_):
        import edge_tts
        v = voice or EDGE_DEFAULT[detect_language(text, language)]
        chunks = []
        try:
            async for ch in edge_tts.Communicate(text, v).stream():
                if ch["type"] == "audio": chunks.append(ch["data"])
        except Exception as e:
            raise ProviderError(f"edge-tts failed: {type(e).__name__}: {str(e)[:120]}", "network") from e
        if not chunks: raise ProviderError("edge-tts returned no audio", "server")
        return b"".join(chunks), "audio/mpeg"


class OpenAISynth:
    name = "openai"

    def configured(self):
        return (True, "") if os.environ.get("OPENAI_API_KEY") else (False, "OPENAI_API_KEY is not set (needed for OpenAI speech)")

    async def synth(self, text: str, language: str, voice: str = "", **_):
        import httpx
        ok, why = self.configured()
        if not ok: raise ProviderError(why, "not_configured")
        base = os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
        body = {"model": os.environ.get("OPENAI_TTS_MODEL", "tts-1"), "input": text, "voice": voice or "onyx", "response_format": "mp3"}
        try:
            async with httpx.AsyncClient(timeout=60) as c:
                r = await c.post(f"{base}/audio/speech", headers={"Authorization": f"Bearer {os.environ['OPENAI_API_KEY']}"}, json=body)
        except httpx.HTTPError as e:
            raise ProviderError(f"Speech synthesis network error: {type(e).__name__}", "network") from e
        if r.status_code >= 400: raise http_error(r.status_code, r.text)
        return r.content, "audio/mpeg"


class SapiSynth:
    """Offline Windows voices through pyttsx3 (SAPI5), rendered to a WAV file."""
    name = "sapi"

    def configured(self):
        try:
            import pyttsx3  # noqa: F401
            return True, ""
        except Exception:
            return False, "pyttsx3 is not installed (run setup.bat)."

    async def synth(self, text: str, language: str, voice: str = "", **_):
        def work():
            import pyttsx3
            fd, path = tempfile.mkstemp(suffix=".wav"); os.close(fd)
            try:
                e = pyttsx3.init()
                if voice:
                    for v in e.getProperty("voices"):
                        if voice.lower() in v.name.lower(): e.setProperty("voice", v.id)
                e.save_to_file(text, path); e.runAndWait()
                with open(path, "rb") as f: return f.read()
            finally:
                try: os.remove(path)
                except OSError: pass
        data = await asyncio.to_thread(work)
        if not data: raise ProviderError("SAPI produced no audio", "server")
        return data, "audio/wav"


def get_synth(name: str):
    return {"edge": EdgeSynth, "openai": OpenAISynth, "sapi": SapiSynth}[name]() if name in ("edge", "openai", "sapi") else None


def clean_for_speech(text: str, limit: int = 1200) -> str:
    t = re.sub(r"```.*?```", " code omitted. ", text, flags=re.S)
    t = re.sub(r"[*_`#>]+", "", t)
    t = re.sub(r"https?://\S+", "link", t)
    return re.sub(r"\s+", " ", t).strip()[:limit]
