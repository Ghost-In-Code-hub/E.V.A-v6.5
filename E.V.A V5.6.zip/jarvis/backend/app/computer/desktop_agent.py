"""Desktop automation: Windows UI Automation (pywinauto) + mss screenshots + pyautogui keyboard.
Everything blocking runs in a worker thread so the event loop stays responsive."""
from __future__ import annotations

import asyncio
import re

from .verification import ScreenshotCache, downscale_png, fingerprint

BLOCKED_HOTKEY_KEYS = {"win", "windows", "cmd", "super"}
MODIFIERS = {"ctrl", "shift", "alt"}


class DesktopError(Exception):
    pass


def validate_hotkey(keys: list[str]) -> str | None:
    ks = [k.lower() for k in keys]
    if not ks or len(ks) > 4: return "Provide 1-4 keys"
    if any(k in BLOCKED_HOTKEY_KEYS for k in ks): return "Shortcuts using the Windows key are not allowed"
    if "alt" in ks and "f4" in ks: return "Alt+F4 is blocked (use the confirmation-gated close action instead)"
    if "delete" in ks and "ctrl" in ks and "alt" in ks: return "Blocked shortcut"
    return None


class DesktopAgent:
    def __init__(self, settings):
        self.settings = settings
        self.cache = ScreenshotCache()

    def available(self) -> tuple[bool, str]:
        try:
            import pywinauto  # noqa: F401
            return True, ""
        except Exception:
            return False, "pywinauto is not available (Windows only; run setup.bat)."

    def screen_available(self) -> tuple[bool, str]:
        try:
            import mss  # noqa: F401
            return True, ""
        except Exception:
            return False, "mss is not installed (run setup.bat)."

    def _desktop(self):
        from pywinauto import Desktop
        return Desktop(backend="uia")

    async def list_windows(self, title_re: str = ".*") -> list[str]:
        def work():
            return [w.window_text() for w in self._desktop().windows(title_re=title_re, visible_only=True) if w.window_text()]
        return await asyncio.to_thread(work)

    def _window(self, title: str):
        d = self._desktop()
        ws = [w for w in d.windows(visible_only=True) if w.window_text() and title.lower() in w.window_text().lower()]
        if not ws: raise DesktopError(f"No visible window containing '{title}'")
        if len(ws) > 1:
            exact = [w for w in ws if w.window_text().lower() == title.lower()]
            if len(exact) == 1: return exact[0]
            raise DesktopError(f"'{title}' matches {len(ws)} windows: " + "; ".join(w.window_text()[:50] for w in ws[:5]))
        return ws[0]

    def _tree(self, win, limit=200) -> list[tuple[str, str]]:
        out = []
        for c in win.descendants()[:limit * 3]:
            try:
                n = c.window_text()
                if n: out.append((c.element_info.control_type or "", n[:80]))
            except Exception:
                pass
            if len(out) >= limit: break
        return out

    async def inspect(self, window: str) -> dict:
        def work():
            w = self._window(window); tree = self._tree(w, 80)
            return {"title": w.window_text(), "controls": [f"{t}: {n}" for t, n in tree]}
        return await asyncio.to_thread(work)

    async def focus(self, window: str) -> dict:
        def work():
            w = self._window(window); w.set_focus()
            return {"title": w.window_text(), "verified": w.has_focus() if hasattr(w, "has_focus") else None}
        return await asyncio.to_thread(work)

    async def click(self, window: str, control: str) -> dict:
        def work():
            w = self._window(window)
            before = fingerprint(w.window_text(), *[f"{t}:{n}" for t, n in self._tree(w)])
            matches = [c for c in w.descendants() if c.window_text().strip().lower() == control.strip().lower() and c.is_visible()]
            if not matches:
                matches = [c for c in w.descendants() if control.strip().lower() in c.window_text().strip().lower() and c.is_visible()]
            if not matches: raise DesktopError(f"No visible control named '{control}' in '{w.window_text()}'")
            if len(matches) > 1:
                raise DesktopError(f"Control '{control}' is ambiguous ({len(matches)} matches)")
            c = matches[0]
            try: c.invoke()
            except Exception: c.click_input()
            import time; time.sleep(0.5)
            w2 = self._window(window)
            after = fingerprint(w2.window_text(), *[f"{t}:{n}" for t, n in self._tree(w2)])
            return {"ui_changed": before != after}
        return await asyncio.to_thread(work)

    async def type_text(self, window: str, text: str) -> dict:
        def work():
            w = self._window(window); w.set_focus()
            import pyautogui, time
            time.sleep(0.2)
            if text.isascii():
                pyautogui.write(text, interval=0.01)
            else:  # non-ASCII (e.g. Urdu): pywinauto sends unicode key events
                from pywinauto.keyboard import send_keys
                send_keys(re.sub(r"([{}^%+~()])", r"{\1}", text), with_spaces=True, pause=0.01)
            return {"typed_chars": len(text)}
        return await asyncio.to_thread(work)

    async def hotkey(self, window: str, keys: list[str]) -> dict:
        err = validate_hotkey(keys)
        if err: raise DesktopError(err)
        def work():
            w = self._window(window); w.set_focus()
            import pyautogui
            pyautogui.hotkey(*[k.lower() for k in keys])
            return {"sent": "+".join(keys)}
        return await asyncio.to_thread(work)

    async def scroll(self, direction: str, clicks: int = 5) -> dict:
        def work():
            import pyautogui
            pyautogui.scroll(clicks * 120 if direction == "up" else -clicks * 120)
            return {"scrolled": direction}
        return await asyncio.to_thread(work)

    async def screenshot(self) -> dict:
        ok, why = self.screen_available()
        if not ok: raise DesktopError(why)
        def work():
            import mss, mss.tools
            with mss.mss() as s:
                shot = s.grab(s.monitors[1])
                return mss.tools.to_png(shot.rgb, shot.size)
        png = downscale_png(await asyncio.to_thread(work))
        return {"png": png, "new": self.cache.is_new("screen", png)}
