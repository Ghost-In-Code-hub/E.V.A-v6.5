"""Verification helpers: evidence-based outcome checks (never 'a click was issued, therefore success')."""
from __future__ import annotations

import base64
import hashlib
import io


def fingerprint(*parts: str) -> str:
    return hashlib.sha1("\x1f".join(parts).encode("utf-8", "replace")).hexdigest()[:16]


def diff_state(before: dict, after: dict) -> dict:
    changed = [k for k in after if before.get(k) != after.get(k)]
    return {"changed": bool(changed), "fields": changed}


class ScreenshotCache:
    """Avoid re-sending identical screenshots to the model (saves tokens, bandwidth)."""

    def __init__(self) -> None:
        self._last: dict[str, str] = {}

    def is_new(self, source: str, png: bytes) -> bool:
        h = hashlib.sha1(png).hexdigest()
        if self._last.get(source) == h:
            return False
        self._last[source] = h
        return True


def downscale_png(png: bytes, max_width: int = 1280) -> bytes:
    try:
        from PIL import Image
    except Exception:
        return png
    im = Image.open(io.BytesIO(png))
    if im.width > max_width:
        im = im.resize((max_width, int(im.height * max_width / im.width)))
    out = io.BytesIO()
    im.convert("RGB").save(out, format="PNG", optimize=True)
    return out.getvalue()


def b64(png: bytes) -> str:
    return base64.b64encode(png).decode()
