"""Browser automation with Playwright. Prefers accessible roles/labels over coordinates.
Page content is UNTRUSTED data and is always wrapped before being shown to the model."""
from __future__ import annotations

import asyncio
import logging
from pathlib import Path

from ..core.security import path_allowed, url_allowed
from .verification import ScreenshotCache, b64, downscale_png, fingerprint

log = logging.getLogger("jarvis.browser")
MAX_TEXT = 6000
ROLES = ("button", "link", "textbox", "searchbox", "checkbox", "combobox", "menuitem", "tab", "radio")


class BrowserError(Exception):
    pass


class BrowserAgent:
    def __init__(self, settings, data_dir: Path):
        self.settings, self.data_dir = settings, Path(data_dir)
        self._pw = self._ctx = None
        self.page = None
        self.cache = ScreenshotCache()
        self._lock = asyncio.Lock()

    def available(self) -> tuple[bool, str]:
        try:
            import playwright  # noqa: F401
            return True, ""
        except Exception:
            return False, "Playwright is not installed (run setup.bat)."

    async def ensure(self):
        ok, why = self.available()
        if not ok: raise BrowserError(why)
        if self.page and not self.page.is_closed():
            return
        from playwright.async_api import async_playwright
        if not self._pw:
            self._pw = await async_playwright().start()
        channel = self.settings["computer"]["browser_channel"] or None  # 'chrome' | 'msedge' | None=bundled chromium
        profile = self.data_dir / "browser_profile"
        try:
            self._ctx = await self._pw.chromium.launch_persistent_context(
                str(profile), channel=channel, headless=False, accept_downloads=True,
                viewport={"width": 1280, "height": 800})
        except Exception as e:
            raise BrowserError(f"Could not launch browser '{channel}': {str(e)[:200]}. Install Chrome/Edge or run 'playwright install chromium'.")
        self.page = self._ctx.pages[0] if self._ctx.pages else await self._ctx.new_page()

    async def close(self):
        try:
            if self._ctx: await self._ctx.close()
            if self._pw: await self._pw.stop()
        except Exception:
            pass
        self._ctx = self._pw = self.page = None

    # ---- observation -------------------------------------------------------------------------------
    async def snapshot(self, with_elements: bool = True) -> dict:
        await self.ensure()
        p = self.page
        try:
            text = (await p.inner_text("body", timeout=3000))[:MAX_TEXT]
        except Exception:
            text = ""
        snap = {"url": p.url, "title": await p.title(), "text": text, "text_hash": fingerprint(text)}
        if with_elements:
            els = []
            for role in ("button", "link", "textbox", "searchbox", "checkbox", "combobox"):
                try:
                    loc = p.get_by_role(role)
                    for i in range(min(await loc.count(), 25)):
                        el = loc.nth(i)
                        if await el.is_visible():
                            if role in ("button", "link"):
                                name = (await el.get_attribute("aria-label")) or (await el.inner_text())
                            else:
                                name = (await el.get_attribute("aria-label")) or (await el.get_attribute("placeholder")) or ""

                            els.append({"role": role, "name": (name or "").strip()[:80]})
                except Exception:
                    continue
            snap["elements"] = [e for e in els if e["name"]][:60]
        return snap

    @staticmethod
    def wrap(snap: dict) -> str:
        els = "\n".join(f"- {e['role']}: {e['name']}" for e in snap.get("elements", []))
        return (f"URL: {snap['url']}\nTitle: {snap['title']}\n"
                f"<untrusted_page_content>\n{snap['text']}\n</untrusted_page_content>\n"
                f"Interactive elements:\n{els}")

    # ---- actions -----------------------------------------------------------------------------------
    async def open_url(self, url: str) -> dict:
        ok, why = url_allowed(url, self.settings["computer"]["allowed_domains"])
        if not ok: raise BrowserError(why)
        await self.ensure()
        resp = await self.page.goto(url, wait_until="domcontentloaded", timeout=20000)
        snap = await self.snapshot(with_elements=False)
        status = resp.status if resp else None
        verified = status is not None and status < 400 and snap["url"].startswith(("http://", "https://"))
        return {"snapshot": snap, "status": status, "verified": verified}

    async def _find(self, target: str, kinds=ROLES):
        """Locate exactly one visible element. Ambiguity is an error, never a guess."""
        p = self.page
        funcs = []
        for r in kinds: funcs.append(lambda r=r: p.get_by_role(r, name=target, exact=True))
        for r in kinds: funcs.append(lambda r=r: p.get_by_role(r, name=target))
        funcs += [lambda: p.get_by_label(target), lambda: p.get_by_placeholder(target),
                  lambda: p.get_by_text(target, exact=True), lambda: p.get_by_text(target)]
        for f in funcs:
            loc = f()
            try:
                n = await loc.count()
            except Exception:
                continue
            vis = [loc.nth(i) for i in range(min(n, 10)) if await loc.nth(i).is_visible()]
            if len(vis) == 1:
                return vis[0]
            if len(vis) > 1:
                names = []
                for v in vis[:5]:
                    names.append(((await v.inner_text()) or (await v.get_attribute("aria-label")) or "?")[:50].strip())
                raise BrowserError(f"'{target}' is ambiguous: {len(vis)} visible matches ({'; '.join(names)}). Ask the user or use a more specific name.")
        raise BrowserError(f"No visible element matching '{target}'. Use browser_read_page to see available elements.")

    async def click(self, target: str) -> dict:
        await self.ensure()
        before = await self.snapshot(False)
        el = await self._find(target)
        pages_before = len(self._ctx.pages)
        await el.click(timeout=5000)
        try: await self.page.wait_for_load_state("domcontentloaded", timeout=3000)
        except Exception: pass
        await asyncio.sleep(0.4)
        if len(self._ctx.pages) > pages_before:
            self.page = self._ctx.pages[-1]
        after = await self.snapshot(False)
        changed = [k for k in ("url", "title", "text_hash") if before[k] != after[k]]
        return {"snapshot": after, "page_changed": bool(changed), "changed_fields": changed}

    async def type_text(self, target: str, text: str, submit: bool = False) -> dict:
        await self.ensure()
        el = await self._find(target, ("textbox", "searchbox", "combobox"))
        await el.fill(text, timeout=5000)
        value = await el.input_value()
        verified = value == text
        if submit and verified:
            before = await self.snapshot(False)
            await el.press("Enter")
            try: await self.page.wait_for_load_state("domcontentloaded", timeout=4000)
            except Exception: pass
            await asyncio.sleep(0.4)
            after = await self.snapshot(False)
            return {"verified": verified, "submitted": True, "page_changed": before["text_hash"] != after["text_hash"] or before["url"] != after["url"], "snapshot": after}
        return {"verified": verified, "submitted": False}

    async def scroll(self, direction: str, amount: int = 600) -> dict:
        await self.ensure()
        y0 = await self.page.evaluate("window.scrollY")
        await self.page.mouse.wheel(0, amount if direction == "down" else -amount)
        await asyncio.sleep(0.3)
        y1 = await self.page.evaluate("window.scrollY")
        return {"moved": y1 != y0, "scroll_y": y1}

    async def screenshot(self) -> dict:
        await self.ensure()
        png = downscale_png(await self.page.screenshot(type="png"))
        return {"png": png, "new": self.cache.is_new("browser", png)}

    async def tabs(self, action: str, index: int | None = None) -> dict:
        await self.ensure()
        if action == "new":
            self.page = await self._ctx.new_page()
        elif action == "switch" and index is not None and 0 <= index < len(self._ctx.pages):
            self.page = self._ctx.pages[index]
            await self.page.bring_to_front()
        elif action == "close" and len(self._ctx.pages) > 1:
            await self.page.close(); self.page = self._ctx.pages[-1]
        elif action != "list":
            raise BrowserError("Invalid tab action or index")
        out = []
        for i, pg in enumerate(self._ctx.pages):
            out.append({"index": i, "url": pg.url, "title": await pg.title(), "active": pg == self.page})
        return {"tabs": out}

    async def download(self, target: str) -> dict:
        dirs = self.settings["computer"]["allowed_dirs"]
        if not dirs: raise BrowserError("No allowed directory configured for downloads.")
        await self.ensure()
        el = await self._find(target)
        async with self.page.expect_download(timeout=30000) as dl:
            await el.click()
        d = await dl.value
        dest = path_allowed(Path(dirs[0]) / d.suggested_filename, dirs)
        if not dest: raise BrowserError("Download filename resolved outside the allowed directory.")
        await d.save_as(str(dest))
        return {"path": str(dest), "verified": dest.exists() and dest.stat().st_size > 0}
