from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    text: str = Field(min_length=1, max_length=4000)
    conversation_id: str | None = Field(default=None, max_length=32)


class StopRequest(BaseModel):
    emergency: bool = False


class SettingsPatch(BaseModel):
    patch: dict


class SecretsUpdate(BaseModel):
    """Write-only. Empty string removes a value. Values are never returned by any endpoint."""
    OPENROUTER_API_KEY: str | None = Field(default=None, max_length=300)
    OPENAI_API_KEY: str | None = Field(default=None, max_length=300)
    ANTHROPIC_API_KEY: str | None = Field(default=None, max_length=300)
    WHATSAPP_TOKEN: str | None = Field(default=None, max_length=600)
    WHATSAPP_PHONE_NUMBER_ID: str | None = Field(default=None, max_length=40, pattern=r"^[0-9]*$")
    OLLAMA_BASE_URL: str | None = Field(default=None, max_length=200, pattern=r"^$|^https?://[^\s]+$")
    OPENAI_BASE_URL: str | None = Field(default=None, max_length=200, pattern=r"^$|^https?://[^\s]+$")


class ProviderTest(BaseModel):
    provider: Literal["openrouter", "openai", "anthropic", "ollama"] | None = None


class ConfirmBody(BaseModel):
    approved: bool


class ClientMessage(BaseModel):
    type: Literal["chat", "stop", "emergency_stop", "wake", "mic", "speech_finished", "confirm", "ping", "refresh", "gesture", "camera"]
    text: str | None = Field(default=None, max_length=4000)
    conversation_id: str | None = Field(default=None, max_length=32)
    enabled: bool | None = None
    id: str | None = Field(default=None, max_length=16)
    approved: bool | None = None
    error: str | None = Field(default=None, max_length=300)
    source: str | None = Field(default="button", max_length=16)
    direction: Literal["up", "down"] | None = None
