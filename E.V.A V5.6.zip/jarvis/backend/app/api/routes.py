from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request

from ..core import config as cfg
from .schemas import ChatRequest, ConfirmBody, ProviderTest, SecretsUpdate, SettingsPatch, StopRequest

router = APIRouter(prefix="/api")
svc = lambda r: r.app.state.service


@router.get("/health")
async def health(request: Request):
    """Unauthenticated, minimal: used by run.bat and the splash screen to detect a live Jarvis backend."""
    return svc(request).health()


@router.get("/status")
async def status(request: Request):
    return svc(request).capabilities()


@router.post("/chat")
async def chat(body: ChatRequest, request: Request):
    return await svc(request).handle_text(body.text, body.conversation_id, "text")


@router.post("/stop")
async def stop(body: StopRequest, request: Request):
    await svc(request).stop("stop button" if not body.emergency else "EMERGENCY STOP", emergency=body.emergency)
    return {"ok": True}


@router.get("/settings")
async def get_settings(request: Request):
    return {"settings": svc(request).settings.data, "secrets": cfg.secret_status()}


@router.put("/settings")
async def put_settings(body: SettingsPatch, request: Request):
    errs = await svc(request).update_settings(body.patch)
    if errs:
        raise HTTPException(422, detail=errs)
    return {"settings": svc(request).settings.data}


@router.put("/secrets")
async def put_secrets(body: SecretsUpdate, request: Request):
    vals = {k: v for k, v in body.model_dump().items() if v is not None}
    if any(("\n" in v or "\r" in v) for v in vals.values()):
        raise HTTPException(422, detail=["Values may not contain line breaks"])
    await svc(request).set_secrets(vals)
    return {"secrets": cfg.secret_status()}  # booleans only


@router.post("/providers/test")
async def test_provider(body: ProviderTest, request: Request):
    return await svc(request).gateway.test(body.provider)


@router.get("/conversations")
async def conversations(request: Request):
    return {"conversations": svc(request).memory.list_conversations()}


@router.get("/conversations/{cid}/messages")
async def conv_messages(cid: str, request: Request):
    return {"messages": [m for m in svc(request).memory.messages(cid, 200) if m["role"] in ("user", "assistant") and m.get("content")]}


@router.delete("/conversations/{cid}")
async def del_conv(cid: str, request: Request):
    s = svc(request)
    s.orch.history.pop(cid, None)
    return {"deleted": s.memory.delete_conversation(cid)}


@router.delete("/conversations")
async def del_all(request: Request):
    s = svc(request)
    s.memory.delete_all(); s.orch.history.clear(); s.current_conv = None
    return {"deleted": True}


@router.post("/confirmations/{cid}")
async def confirm(cid: str, body: ConfirmBody, request: Request):
    if not await svc(request).confirm(cid, body.approved):
        raise HTTPException(404, "No such pending confirmation")
    return {"ok": True}


@router.post("/shutdown")
async def shutdown(request: Request):
    request.app.state.server_should_exit()
    return {"ok": True}
