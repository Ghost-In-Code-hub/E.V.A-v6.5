from __future__ import annotations

import asyncio
import hmac
import logging

from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from pydantic import ValidationError

from .schemas import ClientMessage

log = logging.getLogger("jarvis.ws")
router = APIRouter()
MAX_AUDIO_FRAME = 64 * 1024


def ws_authorized(ws: WebSocket) -> bool:
    tok = ws.query_params.get("token", "")
    ok_origin = ws.headers.get("origin") in (None, *ws.app.state.allowed_origins)
    return ok_origin and hmac.compare_digest(tok.encode(), ws.app.state.token.encode())


@router.websocket("/ws")
async def events_ws(ws: WebSocket):
    if not ws_authorized(ws):
        await ws.close(code=4401); return
    await ws.accept()
    svc = ws.app.state.service
    q = svc.bus.subscribe()
    await ws.send_json(svc.bus.make("connection", status="connected"))
    await ws.send_json(svc.bus.make("state", state=svc.state.state.value, previous=svc.state.state.value, detail=svc.state.detail))
    await ws.send_json(svc.bus.make("capabilities", **svc.capabilities()))

    async def pump():
        while True:
            await ws.send_json(await q.get())

    pump_task = asyncio.create_task(pump())
    try:
        while True:
            try:
                m = ClientMessage.model_validate(await ws.receive_json())
            except ValidationError:
                await ws.send_json(svc.bus.make("error", message="Malformed client message", kind="protocol", recoverable=True)); continue
            t = m.type
            if t == "chat" and m.text: await svc.handle_text(m.text, m.conversation_id, "text")
            elif t == "stop": await svc.stop("stop button")
            elif t == "emergency_stop": await svc.stop("EMERGENCY STOP", emergency=True)
            elif t == "wake": await svc.wake(m.source or "button")
            elif t == "mic": await svc.set_mic(bool(m.enabled))
            elif t == "speech_finished": await svc.speech_finished(m.error)
            elif t == "confirm" and m.id is not None: await svc.confirm(m.id, bool(m.approved))
            elif t == "refresh": await svc.push_capabilities()
            elif t == "gesture" and m.direction: await svc.on_gesture(m.direction)          # detected locally in the UI (MediaPipe in the renderer)
            elif t == "camera": await svc.on_camera(bool(m.enabled), m.error)
    except WebSocketDisconnect:
        pass
    except Exception:
        log.exception("ws error")
    finally:
        pump_task.cancel()
        svc.bus.unsubscribe(q)
        # losing the UI must never leave a hot microphone or pending approvals behind
        await svc.set_mic(False)
        svc.confirmations.deny_all()


@router.websocket("/ws/audio")
async def audio_ws(ws: WebSocket):
    """Binary little-endian int16 mono 16 kHz PCM from the renderer microphone. Analysed locally in RAM."""
    if not ws_authorized(ws):
        await ws.close(code=4401); return
    await ws.accept()
    svc = ws.app.state.service
    try:
        while True:
            msg = await ws.receive()
            if msg.get("type") == "websocket.disconnect": break
            b = msg.get("bytes")
            if b and len(b) <= MAX_AUDIO_FRAME:
                await svc.feed_audio(b)
    except WebSocketDisconnect:
        pass
