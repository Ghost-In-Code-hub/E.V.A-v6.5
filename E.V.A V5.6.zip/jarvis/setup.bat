@echo off
rem ============================================================================================
rem  J.A.R.V.I.S - optional first-time setup. Installs EVERYTHING (core + optional features),
rem  builds the interface and reports exactly which optional packages could not be installed.
rem  run.bat works without this for the core app; run this to enable voice, browser, vision, etc.
rem ============================================================================================
setlocal EnableExtensions
title J.A.R.V.I.S Setup

set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"
cd /d "%ROOT%" || goto :err_cd
set "BACKEND=%ROOT%\backend"
set "FRONT=%ROOT%\frontend"
set "VENV=%ROOT%\.venv"
set "VPY=%VENV%\Scripts\python.exe"
set "DATA=%ROOT%\data"
set "FAILS=%DATA%\setup_failures.txt"
set "PYTHONUTF8=1"

echo.
echo   J.A.R.V.I.S setup in "%ROOT%"
echo.
if not exist "%DATA%" mkdir "%DATA%"
if exist "%FAILS%" del /q "%FAILS%"
if not exist "%ROOT%\.env" if exist "%ROOT%\.env.example" copy /y "%ROOT%\.env.example" "%ROOT%\.env" >nul

if exist "%VPY%" goto :have_venv
set "PY="
call :try_py "py -3.12"
call :try_py "py -3.11"
call :try_py "py -3.10"
call :try_py "python"
if not defined PY goto :err_python
echo [1/4] Creating virtual environment using: %PY%
%PY% -m venv "%VENV%"
if errorlevel 1 goto :err_venv
:have_venv

echo [2/4] Installing core backend dependencies ...
"%VPY%" -m pip install --disable-pip-version-check --upgrade pip >nul 2>&1
"%VPY%" -m pip install --disable-pip-version-check -r "%BACKEND%\requirements.txt"
if errorlevel 1 goto :err_pip
copy /y "%BACKEND%\requirements.txt" "%VENV%\requirements.installed.txt" >nul

echo [3/4] Installing optional features one by one (a failure here does not stop setup) ...
for /f "usebackq eol=# tokens=*" %%L in ("%BACKEND%\requirements-extras.txt") do call :extra "%%L"

echo [4/4] Installing the interface, downloading the hand model, building ...
where node >nul 2>&1
if errorlevel 1 goto :err_node
where npm >nul 2>&1
if errorlevel 1 goto :err_node
pushd "%FRONT%"
call npm install --no-audit --no-fund
if errorlevel 1 popd & goto :err_npm
popd
copy /y "%FRONT%\package.json" "%FRONT%\node_modules\.package.installed.json" >nul
if not exist "%FRONT%\public\models" mkdir "%FRONT%\public\models"
if exist "%FRONT%\public\models\hand_landmarker.task" goto :model_ready
curl.exe -L -f -s -S -o "%FRONT%\public\models\hand_landmarker.task" "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"
if errorlevel 1 echo [warn] Hand model download failed - gestures stay off until you rerun setup.bat with internet. & del /q "%FRONT%\public\models\hand_landmarker.task" >nul 2>&1
:model_ready
pushd "%FRONT%"
call npm run build
if errorlevel 1 popd & goto :err_build
popd

echo.
echo ============================================================
echo  Setup finished.
if exist "%FAILS%" echo  These optional packages FAILED to install (the matching features will show as unavailable):
if exist "%FAILS%" type "%FAILS%"
if not exist "%FAILS%" echo  All optional packages installed.
echo.
echo  Next:  1) double-click run.bat
echo         2) open Settings (gear icon) and add your AI API key
echo  Hand gestures run inside the app (no Python package needed). Browser control uses your installed Chrome/Edge. To use bundled Chromium instead run:
echo         .venv\Scripts\python.exe -m playwright install chromium
echo ============================================================
pause
endlocal
exit /b 0

:extra
echo        - "%~1"
"%VPY%" -m pip install --disable-pip-version-check "%~1" >nul 2>&1
if errorlevel 1 >>"%FAILS%" echo "%~1"
exit /b 0

:try_py
if defined PY exit /b 0
%~1 -c "import sys; sys.exit(0 if (3,10) <= sys.version_info[:2] <= (3,12) else 1)" >nul 2>&1
if not errorlevel 1 set "PY=%~1"
exit /b 0

:err_cd
echo ERROR: cannot enter "%ROOT%".
goto :fail
:err_python
echo ERROR: Python 3.10-3.12 not found. Install Python 3.12 from https://www.python.org/downloads/ and tick "Add to PATH".
goto :fail
:err_venv
echo ERROR: could not create the virtual environment.
goto :fail
:err_pip
echo ERROR: installing core dependencies failed (see above).
goto :fail
:err_node
echo ERROR: Node.js LTS is required to build the interface: https://nodejs.org/
goto :fail
:err_npm
echo ERROR: npm install failed (see above).
goto :fail
:err_build
echo ERROR: interface build failed (see above).
goto :fail
:fail
echo.
pause
endlocal
exit /b 1
