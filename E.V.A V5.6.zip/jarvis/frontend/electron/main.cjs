// Electron shell. run.bat owns the backend; this process only displays the UI.
//  - Main window: frameless + transparent. It opens FULL SCREEN for the intro (see-through background), then maximises.
//  - Island window: tiny transparent always-on-top overlay at the top-centre of the screen, shown ONLY while the main window
//    is minimised/hidden (and only if "Dynamic Island when minimised" is enabled). It is click-through except over the pill.
const { app, BrowserWindow, ipcMain, globalShortcut, Tray, Menu, session, nativeImage, screen } = require("electron");
const fs = require("fs");
const path = require("path");
const http = require("http");

const ROOT = path.resolve(__dirname, "..", "..");
const DATA = process.env.JARVIS_DATA || path.join(ROOT, "data");
const PORT = process.env.JARVIS_PORT || "8765";
const ORIGIN = process.env.JARVIS_DEV_URL || `http://127.0.0.1:${PORT}`;
let win = null, island = null, tray = null, quitting = false, islandEnabled = true, introFinished = false;

const readToken = () => { try { return fs.readFileSync(path.join(DATA, "session_token"), "utf8").trim(); } catch { return ""; } };
const post = (p, token, body = "{}") => new Promise((res) => { const r = http.request({ host: "127.0.0.1", port: PORT, path: p, method: "POST", headers: { "X-Jarvis-Token": token, "Content-Type": "application/json" } }, (m) => { m.resume(); res(m.statusCode); }); r.on("error", () => res(0)); r.setTimeout(1500, () => r.destroy()); r.end(body); });

if (!app.requestSingleInstanceLock()) app.quit();
app.on("second-instance", () => { if (win) { if (win.isMinimized()) win.restore(); win.show(); win.focus(); } });

const prefs = (extra = {}) => ({ preload: path.join(__dirname, "preload.cjs"), contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false, ...extra });

function createWindow() {
  win = new BrowserWindow({
    width: 1360, height: 860, minWidth: 760, minHeight: 560, title: "J.A.R.V.I.S", autoHideMenuBar: true, show: false,
    frame: false, transparent: true, backgroundColor: "#00000000", hasShadow: false, fullscreen: true, resizable: true, webPreferences: prefs(),
  });
  win.once("ready-to-show", () => win.show());
  win.loadURL(ORIGIN);
  win.webContents.setWindowOpenHandler(() => ({ action: "deny" }));
  win.webContents.on("will-navigate", (e, url) => { if (!url.startsWith(ORIGIN)) e.preventDefault(); });
  win.on("minimize", showIsland); win.on("hide", showIsland);
  win.on("restore", hideIsland); win.on("show", hideIsland); win.on("focus", hideIsland);
  win.on("closed", () => { win = null; quitting = true; if (island) island.destroy(); app.quit(); });
}

function createIsland() {
  const W = 520, H = 270, { workArea } = screen.getPrimaryDisplay();
  island = new BrowserWindow({
    width: W, height: H, x: Math.round(workArea.x + (workArea.width - W) / 2), y: workArea.y + 2, show: false, frame: false, transparent: true, backgroundColor: "#00000000",
    resizable: false, movable: false, minimizable: false, maximizable: false, skipTaskbar: true, focusable: false, hasShadow: false, alwaysOnTop: true, webPreferences: prefs(),
  });
  island.setAlwaysOnTop(true, "screen-saver");
  island.setIgnoreMouseEvents(true, { forward: true });            // click-through everywhere except the pill (see island-hover)
  island.loadURL(`${ORIGIN}/?island=1`);
  island.on("closed", () => { island = null; });
}

function showIsland() {
  if (!islandEnabled || quitting || !introFinished) return;
  if (!island) createIsland();
  const place = () => { const { workArea } = screen.getDisplayNearestPoint(screen.getCursorScreenPoint()); const [w] = island.getSize(); island.setPosition(Math.round(workArea.x + (workArea.width - w) / 2), workArea.y + 2); island.showInactive(); };
  island.webContents.isLoading() ? island.webContents.once("did-finish-load", place) : place();
}
function hideIsland() { if (island && !island.isDestroyed()) island.hide(); }

function createTray() {
  const icon = nativeImage.createFromDataURL("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAK0lEQVQ4jWNkYGD4z0ABYBw1gHE0DBgZGBj+U8UARmoZMBoGoy4YdQEBAABzYAMRb/FbYQAAAABJRU5ErkJggg==");
  tray = new Tray(icon); tray.setToolTip("J.A.R.V.I.S");
  const restore = () => { if (!win) return; if (win.isMinimized()) win.restore(); win.show(); win.focus(); };
  tray.setContextMenu(Menu.buildFromTemplate([{ label: "Show Jarvis", click: restore }, { label: "Quit", click: () => { quitting = true; app.quit(); } }]));
  tray.on("click", restore);
}

app.whenReady().then(() => {
  const ses = session.defaultSession;
  // Only the main window on our own origin may use microphone/camera (the camera only while hand gestures are enabled; the UI shows CAM LIVE).
  ses.setPermissionRequestHandler((wc, perm, cb, details) => cb(perm === "media" && wc === (win && win.webContents) && (details.requestingUrl || "").startsWith(ORIGIN)));
  ses.setPermissionCheckHandler((wc, perm) => perm === "media" && wc === (win && win.webContents));

  ipcMain.handle("token", () => readToken());
  ipcMain.on("minimize", () => win && win.minimize());
  ipcMain.on("toggle-maximize", () => { if (!win) return; if (win.isFullScreen()) win.setFullScreen(false); else if (win.isMaximized()) win.unmaximize(); else win.maximize(); });
  ipcMain.on("fullscreen", (_e, v) => win && win.setFullScreen(!!v));
  ipcMain.on("hide", () => win && win.hide());
  ipcMain.on("close", () => { quitting = true; app.quit(); });
  ipcMain.on("quit", () => { quitting = true; app.quit(); });
  ipcMain.on("intro-done", (_e, keepFullscreen) => { introFinished = true; if (win && !keepFullscreen) { win.setFullScreen(false); win.maximize(); } });
  ipcMain.on("island-enabled", (_e, v) => { islandEnabled = !!v; if (!islandEnabled) hideIsland(); });
  ipcMain.on("level", (_e, m) => { if (island && !island.isDestroyed() && island.isVisible()) island.webContents.send("level", m); });
  ipcMain.on("island-hover", (_e, over) => { if (island && !island.isDestroyed()) island.setIgnoreMouseEvents(!over, { forward: true }); });
  ipcMain.on("island-action", (_e, a) => {
    if (!win) return;
    if (a === "open") { if (win.isMinimized()) win.restore(); win.show(); win.focus(); }
    else win.webContents.send("island-action", a);          // "mic" | "wake" are performed by the main window (it owns the microphone)
  });

  createWindow(); createTray();
  // Global emergency stop: works while another app has focus (e.g. during computer control).
  globalShortcut.register("CommandOrControl+Alt+S", async () => { await post("/api/stop", readToken(), JSON.stringify({ emergency: true })).catch(() => 0); win && win.webContents.send("emergency-stop"); });
});

app.on("before-quit", () => { quitting = true; });
app.on("will-quit", () => globalShortcut.unregisterAll());
app.on("window-all-closed", () => app.quit());
