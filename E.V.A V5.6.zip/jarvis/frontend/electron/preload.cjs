const { contextBridge, ipcRenderer } = require("electron");
contextBridge.exposeInMainWorld("jarvis", {
  getToken: () => ipcRenderer.invoke("token"),
  minimize: () => ipcRenderer.send("minimize"),
  toggleMaximize: () => ipcRenderer.send("toggle-maximize"),
  setFullscreen: (v) => ipcRenderer.send("fullscreen", v),
  hideToTray: () => ipcRenderer.send("hide"),
  close: () => ipcRenderer.send("close"),
  quit: () => ipcRenderer.send("quit"),
  introDone: (keepFullscreen) => ipcRenderer.send("intro-done", !!keepFullscreen),
  onEmergencyStop: (cb) => ipcRenderer.on("emergency-stop", () => cb()),
  // dynamic island
  setIslandOverlay: (v) => ipcRenderer.send("island-enabled", !!v),
  sendLevel: (m) => ipcRenderer.send("level", m),
  onLevel: (cb) => ipcRenderer.on("level", (_e, m) => cb(m)),
  islandHover: (over) => ipcRenderer.send("island-hover", !!over),
  islandAction: (a) => ipcRenderer.send("island-action", a),
  onIslandAction: (cb) => ipcRenderer.on("island-action", (_e, a) => cb(a)),
});
