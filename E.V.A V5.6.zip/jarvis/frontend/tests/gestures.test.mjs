// Run with:  npm test      (node >= 22; no dependencies)
import test from "node:test";
import assert from "node:assert/strict";
import { GestureEngine, classifyPose } from "../src/vision/gestures.ts";

function hand(cx, cy, open = true) {
  const lm = Array.from({ length: 21 }, () => [cx, cy]);
  lm[0] = [cx, cy + 0.12];
  [[5, -0.06], [9, -0.02], [13, 0.02], [17, 0.06]].forEach(([b, dx]) => { lm[b] = [cx + dx, cy + 0.02]; lm[b + 1] = [cx + dx, cy - 0.03]; lm[b + 3] = open ? [cx + dx, cy - 0.14] : [cx + dx, cy + 0.03]; });
  return lm;
}
function sweep(e, y0, y1, secs, start = 0, fps = 30) {
  const out = [], n = Math.round(secs * fps);
  for (let i = 0; i <= n; i++) { const r = e.update(hand(0.5, y0 + ((y1 - y0) * i) / n), start + i / fps); if (r) out.push(r); }
  return [out, start + secs];
}

test("pose classification", () => { assert.equal(classifyPose(hand(.5, .5, true)), "open_palm"); assert.equal(classifyPose(hand(.5, .5, false)), "fist"); assert.equal(classifyPose(null), "none"); });
test("up and down", () => { assert.deepEqual(sweep(new GestureEngine(), .7, .3, .6)[0], ["up"]); assert.deepEqual(sweep(new GestureEngine(), .3, .7, .6)[0], ["down"]); });
test("jitter never triggers", () => { const e = new GestureEngine(); for (let i = 0; i < 300; i++) assert.equal(e.update(hand(.5, .5 + (i % 2 ? .006 : -.006)), i / 30), null); });
test("a single noisy frame does not trigger", () => { const e = new GestureEngine(); for (let i = 0; i < 10; i++) e.update(hand(.5, .7), i / 30); assert.equal(e.update(hand(.5, .2), 10 / 30), null); });
test("fist movement ignored", () => { const e = new GestureEngine(); for (let i = 0; i < 30; i++) assert.equal(e.update(hand(.5, .7 - i * .015, false), i / 30), null); });
test("one sweep gives exactly one event", () => { assert.deepEqual(sweep(new GestureEngine(), .8, .2, 1.2)[0], ["up"]); });
test("needs re-arm before the next gesture", () => {
  const e = new GestureEngine(); let [r, t] = sweep(e, .7, .3, .5); assert.deepEqual(r, ["up"]);
  [r, t] = sweep(e, .3, .7, .5, t + .05); assert.deepEqual(r, []);
  for (let i = 0; i < 25; i++) e.update(hand(.5, .7), t + .1 + i / 30);
  assert.deepEqual(sweep(e, .7, .3, .5, t + 2)[0], ["up"]);
});
test("hand leaving the frame re-arms", () => { const e = new GestureEngine(); sweep(e, .7, .3, .5); for (let i = 0; i < 30; i++) e.update(null, 1 + i / 30); assert.deepEqual(sweep(e, .3, .7, .5, 3)[0], ["down"]); });
test("sensitivity changes the required travel", () => {
  assert.deepEqual(sweep(new GestureEngine({ sensitivity: 0 }), .55, .40, .5)[0], []);
  assert.deepEqual(sweep(new GestureEngine({ sensitivity: 1 }), .55, .40, .5)[0], ["up"]);
});
