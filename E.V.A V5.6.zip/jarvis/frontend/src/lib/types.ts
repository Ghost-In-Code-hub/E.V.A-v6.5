export type AState = "STARTING" | "STANDBY" | "LISTENING" | "PROCESSING" | "EXECUTING" | "SPEAKING" | "INTERRUPTED" | "ERROR";

export interface Caps {
  version: string; state: AState;
  ai: { provider: string; configured: boolean; reason: string; model: string; providers: Record<string, { configured: boolean; reason: string; model: string; active: boolean }> };
  stt: { provider: string; configured: boolean; reason: string };
  tts: { provider: string; configured: boolean; reason: string };
  browser: { available: boolean; reason: string; enabled: boolean };
  desktop: { available: boolean; reason: string; enabled: boolean };
  screen: { available: boolean; reason: string };
  gestures: { available: boolean; reason: string; enabled: boolean; camera_active: boolean; engine: string };
  system_volume: { available: boolean; reason: string };
  whatsapp: { cloud_api_configured: boolean; missing: string[] };
  clap: { enabled: boolean };
  wake_phrase: { available: boolean; reason: string };
  mic: { enabled: boolean };
  tools: string[];
  secrets: Record<string, boolean>;
  settings: Settings;
}

export interface Settings {
  ai: { provider: string; timeout_s: number; streaming: boolean; models: Record<string, string>; max_tool_steps: number };
  voice: { input_provider: string; output_provider: string; language: string; voice: string; speech_volume: number; silence_timeout_s: number;
    no_speech_timeout_s: number; max_utterance_s: number; mic_device: string; speaker_device: string; speak_responses: boolean; auto_mic: boolean;
    clap: { enabled: boolean; sensitivity: number; cooldown_s: number }; wake_phrase: { enabled: boolean; phrase: string } };
  vision: { gestures_enabled: boolean; engine: "browser" | "python"; camera_index: number; sensitivity: number; volume_target: "assistant" | "system"; volume_step: number };
  computer: { enabled: boolean; browser_enabled: boolean; desktop_enabled: boolean; files_enabled: boolean; whatsapp_enabled: boolean;
    browser_channel: string; apps: Record<string, string>; allowed_dirs: string[]; allowed_domains: string[]; confirm_all_actions: boolean };
  interface: { quality: "low" | "medium" | "high"; particle_density: number; fullscreen: boolean; skip_startup: boolean; island_overlay: boolean };
  memory: { enabled: boolean; retention_days: number };
  privacy: { audit_log: boolean; audit_retention_days: number };
}

export interface Confirmation { id: string; prompt: string; details: Record<string, unknown>; timeout_s: number; at: number }
export interface LogLine { id: number; ts: number; kind: "info" | "tool" | "error" | "user" | "assistant"; text: string; ok?: boolean }

export interface LevelMsg { level: number; mic: number }

declare global {
  interface Window {
    jarvis?: {
      getToken: () => Promise<string>;
      minimize: () => void; toggleMaximize: () => void; setFullscreen: (v: boolean) => void; close: () => void; quit: () => void; hideToTray: () => void;
      introDone: (keepFullscreen: boolean) => void;
      onEmergencyStop: (cb: () => void) => void;
      // dynamic island (separate overlay window shown only while the main window is minimised)
      setIslandOverlay: (enabled: boolean) => void; sendLevel: (m: LevelMsg) => void; onLevel: (cb: (m: LevelMsg) => void) => void;
      islandHover: (over: boolean) => void; islandAction: (a: "mic" | "wake" | "open") => void; onIslandAction: (cb: (a: string) => void) => void;
    };
  }
}
