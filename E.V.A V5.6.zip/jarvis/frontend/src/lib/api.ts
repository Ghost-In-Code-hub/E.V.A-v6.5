let tokenPromise: Promise<string> | null = null;

export function getToken(): Promise<string> {
  if (!tokenPromise) {
    tokenPromise = (async () => {
      if (window.jarvis) return window.jarvis.getToken();           // Electron: read from the local token file by the main process
      return new URLSearchParams(location.search).get("token") ?? ""; // dev-in-browser: http://127.0.0.1:5173/?token=...
    })();
  }
  return tokenPromise;
}

export class ApiError extends Error {
  status: number; detail: unknown;
  constructor(status: number, detail: unknown) { super(typeof detail === "string" ? detail : JSON.stringify(detail)); this.status = status; this.detail = detail; }
}

export async function api<T = any>(path: string, method = "GET", body?: unknown): Promise<T> {
  const r = await fetch(path, { method, headers: { "X-Jarvis-Token": await getToken(), "Content-Type": "application/json" }, body: body === undefined ? undefined : JSON.stringify(body) });
  let data: any = null;
  try { data = await r.json(); } catch { /* empty */ }
  if (!r.ok) throw new ApiError(r.status, data?.detail ?? r.statusText);
  return data as T;
}

export const health = async () => (await fetch("/api/health")).json();

export function wsUrl(path: string, token: string): string {
  const proto = location.protocol === "https:" ? "wss" : "ws";
  return `${proto}://${location.host}${path}?token=${encodeURIComponent(token)}`;
}
