/** Human-readable status for a REAL tool call (name + arguments come from backend tool_start events). */
const up = (s: unknown, n = 22) => String(s ?? "").trim().toUpperCase().slice(0, n);
const host = (u: unknown) => { try { return new URL(String(u)).hostname.replace(/^www\./, ""); } catch { return String(u ?? "").slice(0, 24); } };

export function describeTool(name: string, a: Record<string, unknown> = {}): string {
  switch (name) {
    case "open_application": return `OPENING ${up(a.name)}`;
    case "list_applications": return "CHECKING APPS";
    case "browser_open_url": return `OPENING ${up(host(a.url), 26)}`;
    case "web_search": return `SEARCHING ${up(a.query, 20)}`;
    case "browser_read_page": return "READING PAGE";
    case "browser_click": return `CLICKING ${up(a.target)}`;
    case "browser_type": return a.submit ? "SUBMITTING TEXT" : "TYPING IN BROWSER";
    case "browser_scroll": return "SCROLLING PAGE";
    case "browser_screenshot": return "CAPTURING PAGE";
    case "browser_tabs": return "MANAGING TABS";
    case "browser_download": return "DOWNLOADING FILE";
    case "screen_capture": return "READING SCREEN";
    case "desktop_list_windows": case "desktop_inspect": return "INSPECTING WINDOWS";
    case "desktop_focus": return `FOCUSING ${up(a.window)}`;
    case "desktop_click": return `CLICKING ${up(a.control)}`;
    case "desktop_type": return `TYPING IN ${up(a.window, 16)}`;
    case "desktop_hotkey": return "SENDING SHORTCUT";
    case "desktop_scroll": return "SCROLLING";
    case "read_file": case "list_directory": return "READING FILES";
    case "write_file": return "EDITING DOCUMENT";
    case "delete_file": return "DELETING FILE";
    case "whatsapp_prepare_message": return `PREPARING WHATSAPP`;
    case "whatsapp_send_prepared": return "SENDING WHATSAPP";
    case "whatsapp_status": return "CHECKING WHATSAPP";
    case "calculator": return "CALCULATING";
    case "get_datetime": return "CHECKING TIME";
    case "search_conversations": case "remember_preference": return "USING MEMORY";
    case "stop_computer_control": return "STOPPING";
    default: return up(name.replace(/_/g, " "), 24);
  }
}

export const isComputerTool = (name: string) => /^(open_application|browser_|web_search|screen_capture|desktop_|write_file|delete_file|whatsapp_)/.test(name);
