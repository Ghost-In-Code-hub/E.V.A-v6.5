// Fast-changing data lives OUTSIDE React state so the 3D scene / island read it every frame without re-rendering.
export interface HandState { present: boolean; x: number; y: number; open: boolean; fist: boolean; t: number; lm: [number, number][] | null }
export const live = { level: 0, micLevel: 0, bands: [0, 0, 0] as number[], vadAt: 0,
  hand: { present: false, x: 0.5, y: 0.5, open: false, fist: false, t: 0, lm: null } as HandState };
