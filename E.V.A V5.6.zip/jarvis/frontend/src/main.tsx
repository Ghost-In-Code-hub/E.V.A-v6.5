import React, { useEffect } from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import { Island } from "./components/Island";
import { IS_ISLAND, useStore } from "./store";
import { live } from "./lib/live";
import "./styles.css";

class Boundary extends React.Component<{ children: React.ReactNode }, { err: string | null }> {
  state = { err: null as string | null };
  static getDerivedStateFromError(e: Error) { return { err: e.message }; }
  render() { return this.state.err ? <div style={{ padding: 32, color: "#ff8a8a", fontFamily: "monospace" }}>UI error: {this.state.err}<br /><button onClick={() => location.reload()}>Reload</button></div> : this.props.children; }
}

/** Overlay window: ONLY the island. It has its own backend connection (real events) and receives audio levels from the main window. */
function IslandWindow() {
  useEffect(() => { useStore.getState().connect(); window.jarvis?.onLevel((m) => { live.level = m.level; live.micLevel = m.mic; }); }, []);
  return <Island overlay />;
}

if (IS_ISLAND) document.documentElement.dataset.island = "1";
ReactDOM.createRoot(document.getElementById("root")!).render(<Boundary>{IS_ISLAND ? <IslandWindow /> : <App />}</Boundary>);
