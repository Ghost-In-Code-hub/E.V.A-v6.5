import { getToken, wsUrl } from "../lib/api";

/** Microphone capture: 16 kHz mono PCM is streamed ONLY to the local backend (loopback) while the mic is switched on.
 *  Nothing is uploaded anywhere until the backend's local wake detector fires and an utterance has been collected. */
class Mic {
  private ctx: AudioContext | null = null;
  private stream: MediaStream | null = null;
  private ws: WebSocket | null = null;

  get active() { return !!this.stream; }

  async start(deviceId: string, onLevel: (l: number) => void) {
    this.stop();
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: { deviceId: deviceId ? { exact: deviceId } : undefined, channelCount: 1, echoCancellation: true, noiseSuppression: false, autoGainControl: false },
    });
    const token = await getToken();
    const ws = new WebSocket(wsUrl("/ws/audio", token)); ws.binaryType = "arraybuffer";
    await new Promise<void>((res, rej) => { ws.onopen = () => res(); ws.onerror = () => rej(new Error("audio channel failed")); });
    const ctx = new AudioContext({ sampleRate: 16000 });
    await ctx.audioWorklet.addModule(new URL("capture-worklet.js", document.baseURI).href);   // same-origin file (CSP forbids blob scripts)
    const src = ctx.createMediaStreamSource(stream), node = new AudioWorkletNode(ctx, "cap");
    node.port.onmessage = (e: MessageEvent<Float32Array>) => {
      const f = e.data; let s = 0; const pcm = new Int16Array(f.length);
      for (let i = 0; i < f.length; i++) { s += f[i] * f[i]; pcm[i] = Math.max(-1, Math.min(1, f[i])) * 32767; }
      onLevel(Math.min(1, Math.sqrt(s / f.length) * 6));
      if (ws.readyState === WebSocket.OPEN && ws.bufferedAmount < 256_000) ws.send(pcm.buffer);
    };
    src.connect(node);
    stream.getAudioTracks()[0].addEventListener("ended", () => this.stop());   // device unplugged
    ws.onclose = () => { if (this.ws === ws) this.stop(); };
    this.ctx = ctx; this.stream = stream; this.ws = ws;
  }

  stop() {
    this.stream?.getTracks().forEach((t) => t.stop()); this.stream = null;
    this.ws?.close(); this.ws = null;
    this.ctx?.close().catch(() => {}); this.ctx = null;
  }
}

export const mic = new Mic();
