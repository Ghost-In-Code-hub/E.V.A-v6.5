import { live } from "../lib/live";

/** Gapless streamed playback. Speech arrives sentence-by-sentence; each chunk is decoded and scheduled right behind the previous
 *  one on the Web Audio clock. A real AnalyserNode measures amplitude/spectrum 30x per second to drive the orb and the island. */
class Player {
  private ctx: AudioContext | null = null;
  private gain!: GainNode;
  private an!: AnalyserNode;
  private sources = new Set<AudioBufferSourceNode>();
  private nextTime = 0;
  private chain: Promise<void> = Promise.resolve();
  private gen = 0;
  private endSeen = false;
  private meterId: number | null = null;
  volume = 0.9;
  onDrain: () => void = () => {};
  onError: (e: string) => void = () => {};

  private ensure() {
    if (!this.ctx) {
      this.ctx = new AudioContext({ latencyHint: "interactive" });
      this.gain = this.ctx.createGain(); this.gain.gain.value = this.volume;
      this.an = this.ctx.createAnalyser(); this.an.fftSize = 512; this.an.smoothingTimeConstant = 0.5;
      this.an.connect(this.gain); this.gain.connect(this.ctx.destination);
    }
    return this.ctx;
  }

  setVolume(v: number) { this.volume = v; if (this.gain) this.gain.gain.setTargetAtTime(v, this.ctx!.currentTime, 0.03); }
  async setSink(deviceId: string) { try { await (this.ensure() as any).setSinkId?.(deviceId || ""); } catch { /* unsupported */ } }

  /** Queue one synthesized chunk (base64 audio). Order is preserved even though decoding is asynchronous. */
  enqueue(b64: string, volume?: number) {
    const g = this.gen;
    if (volume !== undefined && !this.sources.size) this.setVolume(volume);
    this.chain = this.chain.then(async () => {
      if (g !== this.gen) return;
      try {
        const ctx = this.ensure(); if (ctx.state === "suspended") await ctx.resume();
        const bytes = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
        const buf = await ctx.decodeAudioData(bytes.buffer.slice(0));
        if (g !== this.gen) return;
        const src = ctx.createBufferSource(); src.buffer = buf; src.connect(this.an);
        const at = Math.max(ctx.currentTime + 0.015, this.nextTime);
        src.start(at); this.nextTime = at + buf.duration;
        this.sources.add(src); this.startMeter();
        src.onended = () => { this.sources.delete(src); this.check(); };
      } catch (e: any) { if (g === this.gen) this.onError(String(e?.message ?? e)); }
    });
  }

  /** Server says no more chunks are coming. */
  markEnd() { const g = this.gen; this.chain = this.chain.then(() => { if (g === this.gen) { this.endSeen = true; this.check(); } }); }

  private check() {
    if (this.endSeen && this.sources.size === 0) { this.reset(); this.onDrain(); }
  }

  stop() { this.reset(); }

  private reset() {
    this.gen++; this.endSeen = false; this.nextTime = 0; this.chain = Promise.resolve();
    for (const s of this.sources) { s.onended = null; try { s.stop(); } catch { /* already stopped */ } }
    this.sources.clear(); this.stopMeter();
  }

  private startMeter() {
    if (this.meterId !== null) return;
    const data = new Uint8Array(this.an.fftSize), freq = new Uint8Array(this.an.frequencyBinCount);
    this.meterId = window.setInterval(() => {                       // setInterval (not rAF) so it keeps running while minimised
      this.an.getByteTimeDomainData(data); this.an.getByteFrequencyData(freq);
      let sum = 0; for (let i = 0; i < data.length; i++) { const v = (data[i] - 128) / 128; sum += v * v; }
      live.level += (Math.min(1, Math.sqrt(sum / data.length) * 3.4) - live.level) * 0.5;
      const band = (a: number, b: number) => { let t = 0; for (let i = a; i < b; i++) t += freq[i]; return t / ((b - a) * 255); };
      live.bands = [band(1, 8), band(8, 40), band(40, 120)];
    }, 33);
  }
  private stopMeter() { if (this.meterId !== null) clearInterval(this.meterId); this.meterId = null; live.level = 0; live.bands = [0, 0, 0]; }
}

export const player = new Player();
