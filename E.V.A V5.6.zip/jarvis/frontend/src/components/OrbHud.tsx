/** Thin HUD rings around the orb (reference-1 style): rotating tick ring, dashed arcs, crosshair, corner marks. Pure SVG, GPU-cheap. */
export function OrbHud() {
  const ticks = Array.from({ length: 90 }, (_, i) => i);
  return (
    <svg className="orb-hud" viewBox="-100 -100 200 200" aria-hidden>
      <circle r="47" className="r1" /><circle r="39" className="r2" />
      <g className="spin-slow">{ticks.map((i) => <line key={i} y1="-47.5" y2={i % 5 === 0 ? -44.5 : -46} transform={`rotate(${i * 4})`} />)}</g>
      <g className="spin-rev"><circle r="43" className="dash a" /></g>
      <g className="spin-mid"><circle r="35" className="dash b" /></g>
      <path className="cross" d="M-49 0H-43M43 0H49M0 -49V-43M0 43V49" />
    </svg>
  );
}
