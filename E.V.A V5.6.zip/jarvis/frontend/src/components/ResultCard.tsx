import { useEffect, useState } from "react";
import { useStore } from "../store";

/** Instant arithmetic result ("3428*897"): shown big, answered locally with no AI round-trip. */
export function ResultCard() {
  const calc = useStore((s) => s.calc), [, tick] = useState(0);
  useEffect(() => { if (!calc) return; const t = setTimeout(() => tick((n) => n + 1), 12500); return () => clearTimeout(t); }, [calc]);
  if (!calc || Date.now() - calc.at > 12000) return null;
  return (
    <div key={calc.at} className="result-card" role="status">
      <div className="rc-label">RESULT</div>
      <div className="rc-expr">{calc.expr}</div>
      <div className="rc-value">{calc.value}</div>
    </div>
  );
}
