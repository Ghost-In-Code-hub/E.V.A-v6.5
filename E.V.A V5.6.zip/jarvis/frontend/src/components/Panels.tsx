import { useEffect, useRef, useState } from "react";
import { useStore } from "../store";

export function Panel({ title, children, className = "" }: { title: string; children: React.ReactNode; className?: string }) {
  return <section className={`panel ${className}`}><header>{title}</header><div className="panel-body">{children}</div></section>;
}

export function LogPanel() {
  const log = useStore((s) => s.log), ref = useRef<HTMLDivElement>(null);
  useEffect(() => { ref.current?.scrollTo({ top: 1e6 }); }, [log.length]);
  return (
    <Panel title="ACTIVITY LOG" className="log">
      <div ref={ref} className="log-scroll">
        {log.length === 0 && <div className="dim">No activity yet.</div>}
        {log.map((l) => <div key={l.id} className={`ln k-${l.kind} ${l.ok === false ? "bad" : ""}`}><time>{new Date(l.ts).toLocaleTimeString([], { hour12: false })}</time>{l.text}</div>)}
      </div>
    </Panel>
  );
}

export function TaskPanel() {
  const { taskLabel, toolLine, state, detail } = useStore();
  const exec = state === "EXECUTING";
  return (
    <Panel title="CURRENT TASK">
      <div className="task">{state === "STANDBY" ? <span className="dim">Idle</span> : taskLabel || detail}</div>
      <div className="kv"><span>MODE</span><b>{exec ? "COMPUTER ACTION" : state === "PROCESSING" ? "AI PROCESSING" : state === "SPEAKING" ? "SPEAKING" : state}</b></div>
      {toolLine && <div className="kv tool"><span>TOOL</span><b>{toolLine}</b></div>}
    </Panel>
  );
}

export function ConversationPanel() {
  const { userText, response, spoken, vad, state } = useStore();
  return (
    <Panel title="TRANSCRIPT" className="convo">
      <div className="lbl">YOU {state === "LISTENING" && <i className={vad ? "dot on" : "dot"} />}</div>
      <div className="txt">{state === "LISTENING" ? (vad ? "Listening… (voice detected)" : "Listening…") : userText || <span className="dim">—</span>}</div>
      <div className="lbl">JARVIS</div>
      <div className="txt resp">{response || <span className="dim">—</span>}</div>
      {state === "SPEAKING" && spoken && <div className="lbl small">SPEAKING · {spoken.length} chars</div>}
    </Panel>
  );
}

export function SysPanel() {
  const { caps, usage, connected } = useStore();
  const row = (k: string, v: string) => <div className="kv" key={k}><span>{k}</span><b>{v}</b></div>;
  return (
    <Panel title="SYSTEM">
      {row("LINK", connected ? "ONLINE" : "OFFLINE")}
      {row("AI", caps?.ai.configured ? `${caps.ai.provider}` : "NOT CONFIGURED")}
      {row("MODEL", caps?.ai.model || "—")}
      {row("TOKENS", `${usage.i} in / ${usage.o} out`)}
      {row("WAKE", caps?.clap.enabled ? "CLAP + BUTTON" : "BUTTON")}
    </Panel>
  );
}

export function Confirmations() {
  const { confirmations, confirm } = useStore();
  const [, tick] = useState(0);
  useEffect(() => { const i = setInterval(() => tick((n) => n + 1), 500); return () => clearInterval(i); }, []);
  const c = confirmations[0];
  if (!c) return null;
  const left = Math.max(0, Math.round(c.timeout_s - (Date.now() - c.at) / 1000));
  return (
    <div className="modal-bg" role="dialog" aria-modal>
      <div className="modal">
        <h3>CONFIRMATION REQUIRED</h3>
        <p className="prompt">{c.prompt}</p>
        <pre className="details">{JSON.stringify(c.details, null, 2)}</pre>
        <div className="row"><button className="btn ok" autoFocus onClick={() => confirm(c.id, true)}>APPROVE</button><button className="btn danger" onClick={() => confirm(c.id, false)}>DENY</button></div>
        <div className="dim small">Auto-denies in {left}s · {confirmations.length > 1 ? `${confirmations.length - 1} more pending` : "no more pending"}</div>
      </div>
    </div>
  );
}
