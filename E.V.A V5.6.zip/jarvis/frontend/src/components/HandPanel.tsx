import { useEffect, useRef } from "react";
import { live } from "../lib/live";
import { useStore } from "../store";
import { Panel } from "./Panels";

const BONES = [[0, 1], [1, 2], [2, 3], [3, 4], [0, 5], [5, 6], [6, 7], [7, 8], [5, 9], [9, 10], [10, 11], [11, 12], [9, 13], [13, 14], [14, 15], [15, 16], [13, 17], [17, 18], [18, 19], [19, 20], [0, 17]];

/** Live skeleton of the tracked hand (drawn from the real landmarks) + the last recognised gesture. */
export function HandPanel() {
  const ref = useRef<HTMLCanvasElement>(null), { camOn, caps, settings } = useStore();
  useEffect(() => {
    const cv = ref.current!, ctx = cv.getContext("2d")!; let raf = 0;
    const draw = () => {
      const w = cv.width, h = cv.height, css = getComputedStyle(cv), c1 = css.getPropertyValue("--c1") || "#2cc4ff";
      ctx.clearRect(0, 0, w, h);
      const hd = live.hand; if (hd.present && hd.lm && performance.now() - hd.t < 500) {
        ctx.strokeStyle = c1; ctx.fillStyle = c1; ctx.lineWidth = 1.6; ctx.shadowColor = c1; ctx.shadowBlur = 6;
        for (const [a, b] of BONES) { ctx.beginPath(); ctx.moveTo((1 - hd.lm[a][0]) * w, hd.lm[a][1] * h); ctx.lineTo((1 - hd.lm[b][0]) * w, hd.lm[b][1] * h); ctx.stroke(); }
        for (const p of hd.lm) { ctx.beginPath(); ctx.arc((1 - p[0]) * w, p[1] * h, 2.2, 0, 7); ctx.fill(); }
      }
      raf = requestAnimationFrame(draw);
    };
    draw(); return () => cancelAnimationFrame(raf);
  }, []);
  const on = settings?.vision.gestures_enabled;
  return (
    <Panel title="HAND CONTROL" className="hand">
      <canvas ref={ref} width={260} height={150} className="hand-cv" />
      <div className="kv"><span>CAMERA</span><b>{camOn ? "LIVE" : on ? "STARTING…" : "OFF"}</b></div>
      <div className="kv"><span>CONTROLS</span><b>{settings?.vision.volume_target === "system" ? "WINDOWS VOLUME" : "JARVIS VOLUME"}</b></div>
      <div className="dim small">{caps && !caps.gestures.available ? caps.gestures.reason : "Open palm ↑ / ↓ = volume · the orb follows your hand"}</div>
    </Panel>
  );
}
