import { useEffect, useState } from "react";
import { api } from "../lib/api";
import { useStore } from "../store";

type Tab = "AI" | "Voice" | "Vision" | "Computer" | "Interface" | "Memory";
const TABS: Tab[] = ["AI", "Voice", "Vision", "Computer", "Interface", "Memory"];

function Row({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return <label className="srow"><span>{label}{hint && <small>{hint}</small>}</span><div>{children}</div></label>;
}
const Toggle = ({ v, on }: { v: boolean; on: (b: boolean) => void }) => <input type="checkbox" checked={v} onChange={(e) => on(e.target.checked)} />;
const Slider = ({ v, min, max, step, on }: { v: number; min: number; max: number; step: number; on: (n: number) => void }) => (
  <span className="slider"><input type="range" min={min} max={max} step={step} value={v} onChange={(e) => on(+e.target.value)} /><b>{v}</b></span>
);

function ListEditor({ items, on, placeholder }: { items: string[]; on: (l: string[]) => void; placeholder: string }) {
  const [v, setV] = useState("");
  return (
    <div className="list">
      {items.map((it, i) => <div key={i} className="li"><code>{it}</code><button onClick={() => on(items.filter((_, j) => j !== i))}>✕</button></div>)}
      <div className="li add"><input value={v} placeholder={placeholder} onChange={(e) => setV(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && v.trim()) { on([...items, v.trim()]); setV(""); } }} />
        <button onClick={() => { if (v.trim()) { on([...items, v.trim()]); setV(""); } }}>ADD</button></div>
    </div>
  );
}

function AppsEditor({ apps, on }: { apps: Record<string, string>; on: (a: Record<string, string>) => void }) {
  const [n, setN] = useState(""), [p, setP] = useState("");
  return (
    <div className="list">
      {Object.entries(apps).map(([k, v]) => <div key={k} className="li"><code>{k} → {v}</code><button onClick={() => { const c = { ...apps }; delete c[k]; on(c); }}>✕</button></div>)}
      <div className="li add"><input value={n} placeholder="name (e.g. obsidian)" onChange={(e) => setN(e.target.value)} style={{ flex: "0 0 38%" }} />
        <input value={p} placeholder="C:\Path With Spaces\app.exe" onChange={(e) => setP(e.target.value)} />
        <button onClick={() => { if (n.trim() && p.trim()) { on({ ...apps, [n.trim().toLowerCase()]: p.trim() }); setN(""); setP(""); } }}>ADD</button></div>
    </div>
  );
}

export function SettingsPanel() {
  const { settings: s, caps, setSettingsOpen, patchSettings, stop } = useStore();
  const [tab, setTab] = useState<Tab>("AI"), [errs, setErrs] = useState<string[]>([]), [note, setNote] = useState("");
  const [testing, setTesting] = useState(false), [test, setTest] = useState<string>("");
  const [keys, setKeys] = useState<Record<string, string>>({}), [devs, setDevs] = useState<MediaDeviceInfo[]>([]);
  useEffect(() => { navigator.mediaDevices?.enumerateDevices().then(setDevs).catch(() => {}); }, []);
  if (!s || !caps) return null;

  const patch = async (p: unknown) => { const e = await patchSettings(p); setErrs(e); setNote(e.length ? "" : "Saved"); if (!e.length) setTimeout(() => setNote(""), 1200); };
  const saveKeys = async (names: string[]) => {
    const body: Record<string, string> = {}; names.forEach((n) => { if (keys[n] !== undefined) body[n] = keys[n]; });
    try { await api("/api/secrets", "PUT", body); setKeys((k) => { const c = { ...k }; names.forEach((n) => delete c[n]); return c; }); setNote("Saved (stored on the backend only)"); setErrs([]); }
    catch (e: any) { setErrs(Array.isArray(e.detail) ? e.detail.map((d: any) => d.msg ?? String(d)) : [String(e.message)]); }
  };
  const runTest = async () => {
    setTesting(true); setTest("");
    try { const r = await api("/api/providers/test", "POST", { provider: "openrouter" }); setTest(r.ok ? "✓ Key works" : `✗ ${r.error}`); }
    catch (e: any) { setTest(`✗ ${e.message}`); } finally { setTesting(false); }
  };
  const keyField = (name: string, label: string) => (
    <Row label={label} hint={caps.secrets[name] ? "saved on backend — value hidden" : "not set"}>
      <input type="password" autoComplete="off" value={keys[name] ?? ""} placeholder={caps.secrets[name] ? "••••••••  (enter to replace)" : "paste key"} onChange={(e) => setKeys({ ...keys, [name]: e.target.value })} />
      <button className="mini" disabled={keys[name] === undefined} onClick={() => saveKeys([name])}>SAVE</button>
      {caps.secrets[name] && <button className="mini danger" onClick={() => { setKeys({ ...keys, [name]: "" }); api("/api/secrets", "PUT", { [name]: "" }).then(() => setNote("Removed")); }}>REMOVE</button>}
    </Row>
  );
  const mics = devs.filter((d) => d.kind === "audioinput"), spk = devs.filter((d) => d.kind === "audiooutput"), cams = devs.filter((d) => d.kind === "videoinput");
  const c = s.computer;

  return (
    <div className="modal-bg" onClick={() => setSettingsOpen(false)}>
      <div className="settings" onClick={(e) => e.stopPropagation()}>
        <header><h2>SETTINGS</h2><span className="note">{note}</span><button onClick={() => setSettingsOpen(false)}>✕</button></header>
        <nav>{TABS.map((t) => <button key={t} className={t === tab ? "on" : ""} onClick={() => setTab(t)}>{t.toUpperCase()}</button>)}</nav>
        {errs.length > 0 && <ul className="errs">{errs.map((e, i) => <li key={i}>{e}</li>)}</ul>}
        <div className="sbody">
          {tab === "AI" && <>
            {keyField("OPENROUTER_API_KEY", "OpenRouter API key")}
            <div className="actions"><button className="btn" disabled={testing} onClick={runTest}>{testing ? "TESTING…" : "TEST KEY"}</button><span className={test.startsWith("✓") ? "okt" : "badt"}>{test}</span></div>
            <p className="dim">No model needs to be chosen: OpenRouter picks the best fast model for every request automatically, and the same key is used for speech recognition.
              Get a key at openrouter.ai/keys. (Advanced: other providers and a pinned model can be set in <code>.env</code>.)</p>
            <Row label="Request timeout (s)"><Slider v={s.ai.timeout_s} min={5} max={300} step={5} on={(n) => patch({ ai: { timeout_s: n } })} /></Row>
            <Row label="Max tool steps"><Slider v={s.ai.max_tool_steps} min={1} max={20} step={1} on={(n) => patch({ ai: { max_tool_steps: n } })} /></Row>
          </>}

          {tab === "Voice" && <>
            <Row label="Microphone"><select value={s.voice.mic_device} onChange={(e) => patch({ voice: { mic_device: e.target.value } })}><option value="">System default</option>
              {mics.map((d, i) => <option key={d.deviceId} value={d.deviceId}>{d.label || `Microphone ${i + 1}`}</option>)}</select></Row>
            <Row label="Speaker"><select value={s.voice.speaker_device} onChange={(e) => patch({ voice: { speaker_device: e.target.value } })}><option value="">System default</option>
              {spk.map((d, i) => <option key={d.deviceId} value={d.deviceId}>{d.label || `Speaker ${i + 1}`}</option>)}</select></Row>
            <Row label="Speech recognition" hint={caps.stt.configured ? "ready (uses your OpenRouter key)" : caps.stt.reason}><span className="dim">automatic</span></Row>
            <Row label="Start microphone automatically" hint="shows MIC LIVE while on"><Toggle v={s.voice.auto_mic} on={(b) => patch({ voice: { auto_mic: b } })} /></Row>
            <Row label="Speech output" hint={caps.tts.configured ? "ready" : caps.tts.reason}><select value={s.voice.output_provider} onChange={(e) => patch({ voice: { output_provider: e.target.value } })}>
              <option value="edge">Edge neural voices (free, online, supports Urdu)</option><option value="openai">OpenAI TTS</option><option value="sapi">Windows SAPI (offline)</option><option value="none">Off (text only)</option></select></Row>
            <Row label="Language"><select value={s.voice.language} onChange={(e) => patch({ voice: { language: e.target.value } })}><option value="en">English</option><option value="ur">Urdu / Roman Urdu</option><option value="auto">Auto-detect</option></select></Row>
            <Row label="Voice" hint="optional voice id, e.g. ur-PK-UzmaNeural"><input value={s.voice.voice} onChange={(e) => patch({ voice: { voice: e.target.value } })} /></Row>
            <Row label="Speak responses"><Toggle v={s.voice.speak_responses} on={(b) => patch({ voice: { speak_responses: b } })} /></Row>
            <Row label="Speech volume"><Slider v={s.voice.speech_volume} min={0} max={1} step={0.05} on={(n) => patch({ voice: { speech_volume: n } })} /></Row>
            <Row label="Silence timeout (s)" hint="end of speech"><Slider v={s.voice.silence_timeout_s} min={0.4} max={5} step={0.1} on={(n) => patch({ voice: { silence_timeout_s: n } })} /></Row>
            <h4>WAKE</h4>
            <Row label="Clap detector" hint="local analysis only; off by default"><Toggle v={s.voice.clap.enabled} on={(b) => patch({ voice: { clap: { enabled: b } } })} /></Row>
            <Row label="Clap sensitivity"><Slider v={s.voice.clap.sensitivity} min={0} max={1} step={0.05} on={(n) => patch({ voice: { clap: { sensitivity: n } } })} /></Row>
            <Row label="Clap cooldown (s)"><Slider v={s.voice.clap.cooldown_s} min={0.5} max={10} step={0.5} on={(n) => patch({ voice: { clap: { cooldown_s: n } } })} /></Row>
            <Row label="Wake phrase" hint={caps.wake_phrase.reason}><input disabled value={s.voice.wake_phrase.phrase} /></Row>
          </>}

          {tab === "Vision" && <>
            <Row label="Gesture recognition" hint={caps.gestures.available ? "uses the webcam only while enabled" : caps.gestures.reason}><Toggle v={s.vision.gestures_enabled} on={(b) => patch({ vision: { gestures_enabled: b } })} /></Row>
            <Row label="Engine" hint="in-app = no Python packages needed (needs the 8 MB hand model downloaded by setup.bat/run.bat)"><select value={s.vision.engine} onChange={(e) => patch({ vision: { engine: e.target.value } })}><option value="browser">In-app (MediaPipe, recommended)</option><option value="python">Python (OpenCV + MediaPipe)</option></select></Row>
            <Row label="Camera" hint="index in system order"><select value={s.vision.camera_index} onChange={(e) => patch({ vision: { camera_index: +e.target.value } })}>
              {(cams.length ? cams : [{ label: "Camera 0" } as MediaDeviceInfo]).map((d, i) => <option key={i} value={i}>{d.label || `Camera ${i}`}</option>)}</select></Row>
            <Row label="Sensitivity"><Slider v={s.vision.sensitivity} min={0} max={1} step={0.05} on={(n) => patch({ vision: { sensitivity: n } })} /></Row>
            <Row label="Gestures control" hint={s.vision.volume_target === "system" && !caps.system_volume.available ? caps.system_volume.reason : ""}><select value={s.vision.volume_target} onChange={(e) => patch({ vision: { volume_target: e.target.value } })}>
              <option value="assistant">Jarvis speech volume</option><option value="system">Windows system volume</option></select></Row>
            <Row label="Step size"><Slider v={s.vision.volume_step} min={0.02} max={0.3} step={0.01} on={(n) => patch({ vision: { volume_step: n } })} /></Row>
            <p className="dim">Open palm moving up = volume up, down = volume down. Gestures never move the mouse or click.</p>
          </>}

          {tab === "Computer" && <>
            <Row label="Allow computer control" hint="master switch"><Toggle v={c.enabled} on={(b) => patch({ computer: { enabled: b } })} /></Row>
            <Row label="Browser" hint={caps.browser.available ? "" : caps.browser.reason}><Toggle v={c.browser_enabled} on={(b) => patch({ computer: { browser_enabled: b } })} /></Row>
            <Row label="Desktop apps & screen" hint={caps.desktop.available ? "" : caps.desktop.reason}><Toggle v={c.desktop_enabled} on={(b) => patch({ computer: { desktop_enabled: b } })} /></Row>
            <Row label="Files" hint="only inside allowed folders"><Toggle v={c.files_enabled} on={(b) => patch({ computer: { files_enabled: b } })} /></Row>
            <Row label="WhatsApp" hint={caps.whatsapp.cloud_api_configured ? "Cloud API configured" : `Cloud API missing: ${caps.whatsapp.missing.join(", ")}`}><Toggle v={c.whatsapp_enabled} on={(b) => patch({ computer: { whatsapp_enabled: b } })} /></Row>
            <Row label="Confirm every action"><Toggle v={c.confirm_all_actions} on={(b) => patch({ computer: { confirm_all_actions: b } })} /></Row>
            <Row label="Browser"><select value={c.browser_channel} onChange={(e) => patch({ computer: { browser_channel: e.target.value } })}><option value="chrome">Google Chrome</option><option value="msedge">Microsoft Edge</option><option value="">Bundled Chromium</option></select></Row>
            <h4>APPROVED APPLICATIONS <small>(chrome, edge, notepad, calculator, vscode are built in)</small></h4>
            <AppsEditor apps={c.apps} on={(a) => patch({ computer: { apps: a } })} />
            <h4>ALLOWED FOLDERS</h4><ListEditor items={c.allowed_dirs} on={(l) => patch({ computer: { allowed_dirs: l } })} placeholder="C:\Users\You\Documents" />
            <h4>ALLOWED WEBSITES <small>(empty = any http/https site)</small></h4><ListEditor items={c.allowed_domains} on={(l) => patch({ computer: { allowed_domains: l } })} placeholder="example.com" />
            <h4>WHATSAPP CLOUD API</h4>{keyField("WHATSAPP_TOKEN", "Access token")}
            <Row label="Phone number ID"><input defaultValue="" placeholder="digits only" onBlur={(e) => e.target.value && api("/api/secrets", "PUT", { WHATSAPP_PHONE_NUMBER_ID: e.target.value }).catch((er) => setErrs([String(er.message)]))} /></Row>
            <div className="actions"><button className="btn estop" onClick={() => stop(true)}>EMERGENCY STOP</button><span className="dim">Ctrl+Alt+S works from anywhere</span></div>
          </>}

          {tab === "Interface" && <>
            <Row label="Graphics quality"><select value={s.interface.quality} onChange={(e) => patch({ interface: { quality: e.target.value } })}><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option></select></Row>
            <Row label="Particle density"><Slider v={s.interface.particle_density} min={0.2} max={2} step={0.1} on={(n) => patch({ interface: { particle_density: n } })} /></Row>
            <Row label="Fullscreen"><Toggle v={s.interface.fullscreen} on={(b) => { patch({ interface: { fullscreen: b } }); window.jarvis?.setFullscreen(b); }} /></Row>
            <Row label="Dynamic Island when minimised" hint="small always-on-top island at the top of the screen, only while Jarvis is minimised"><Toggle v={s.interface.island_overlay} on={(b) => patch({ interface: { island_overlay: b } })} /></Row>
            <Row label="Skip startup animation"><Toggle v={s.interface.skip_startup} on={(b) => patch({ interface: { skip_startup: b } })} /></Row>
          </>}

          {tab === "Memory" && <>
            <Row label="Remember conversations"><Toggle v={s.memory.enabled} on={(b) => patch({ memory: { enabled: b } })} /></Row>
            <Row label="Retention (days)" hint="0 = keep until deleted"><Slider v={s.memory.retention_days} min={0} max={365} step={1} on={(n) => patch({ memory: { retention_days: n } })} /></Row>
            <Row label="Audit log"><Toggle v={s.privacy.audit_log} on={(b) => patch({ privacy: { audit_log: b } })} /></Row>
            <div className="actions"><button className="btn danger" onClick={() => confirm("Delete ALL stored conversations and preferences?") && api("/api/conversations", "DELETE").then(() => setNote("Deleted"))}>DELETE ALL MEMORY</button></div>
            <p className="dim">Raw audio, webcam frames and API keys are never stored.</p>
          </>}
        </div>
      </div>
    </div>
  );
}
