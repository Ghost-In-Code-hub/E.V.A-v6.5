import { useEffect, useRef, useState } from "react";
import { api, health } from "../lib/api";
import type { Caps } from "../lib/types";
import { useStore } from "../store";
import { Radar } from "./Radar";

type Tag = "OK" | "WARN" | "FAIL" | "OFF";
interface Line { label: string; tag: Tag; text: string }

async function countDevices(kind: MediaDeviceKind): Promise<number | null> {
  try { return (await navigator.mediaDevices.enumerateDevices()).filter((d) => d.kind === kind).length; } catch { return null; }
}

/** Every line below is derived from a real check. Nothing is faked; unavailable features are reported as WARN/OFF. */
async function* bootChecks(): AsyncGenerator<Line> {
  let h: any = null;
  for (let i = 0; i < 40 && !h; i++) { try { h = await health(); if (h?.service !== "jarvis") h = null; } catch { /* backend not up yet */ } if (!h) await new Promise((r) => setTimeout(r, 400)); }
  if (!h) { yield { label: "BACKEND LINK", tag: "FAIL", text: "No Jarvis backend answered on this port" }; return; }
  yield { label: "BACKEND LINK", tag: "OK", text: `connected · v${h.version}` };
  let c: Caps;
  try { c = await api<Caps>("/api/status"); yield { label: "SECURE SESSION", tag: "OK", text: "session token accepted" }; }
  catch (e: any) { yield { label: "SECURE SESSION", tag: "FAIL", text: `token rejected (${e.status ?? "?"})` }; return; }
  yield { label: "AI PROVIDER", tag: c.ai.configured ? "OK" : "WARN", text: c.ai.configured ? `${c.ai.provider} · automatic model routing` : `${c.ai.reason || "not configured"}` };
  yield { label: "SPEECH RECOGNITION", tag: c.stt.configured ? "OK" : "WARN", text: c.stt.configured ? c.stt.provider : c.stt.reason };
  yield { label: "SPEECH SYNTHESIS", tag: c.tts.configured ? "OK" : "WARN", text: c.tts.configured ? c.tts.provider : c.tts.reason };
  const mics = await countDevices("audioinput");
  yield { label: "AUDIO INPUT", tag: mics ? "OK" : "WARN", text: mics === null ? "cannot enumerate devices" : mics ? `${mics} device(s) found · mic stays OFF until you enable it` : "no microphone detected" };
  const cams = await countDevices("videoinput");
  yield { label: "VISION", tag: c.gestures.enabled ? (c.gestures.available ? "OK" : "WARN") : "OFF", text: c.gestures.enabled ? (c.gestures.available ? "gesture tracking enabled" : c.gestures.reason) : `gestures disabled · ${cams ?? 0} camera(s) · camera OFF` };
  const ctl = [c.browser.enabled && "browser", c.desktop.enabled && "desktop"].filter(Boolean) as string[];
  yield { label: "COMPUTER CONTROL", tag: ctl.length ? "OK" : "OFF", text: ctl.length ? `${ctl.join(" + ")} enabled` : "disabled (enable in Settings)" };
  yield { label: "WAKE CONDITIONS", tag: c.clap.enabled ? "OK" : "OFF", text: c.clap.enabled ? "clap detector armed · button" : "clap detector off · use the mic button" };
}

export function StartupHUD() {
  const setPhase = useStore((s) => s.setPhase), connect = useStore((s) => s.connect);
  const [lines, setLines] = useState<Line[]>([]), [done, setDone] = useState(false), [failed, setFailed] = useState(false), [pct, setPct] = useState(0);
  const run = useRef(0);

  const start = () => {
    const id = ++run.current; setLines([]); setDone(false); setFailed(false); setPct(0);
    const t0 = performance.now();
    (async () => {
      let n = 0;
      for await (const l of bootChecks()) {
        if (run.current !== id) return;
        setLines((p) => [...p, l]); setPct(Math.min(96, ++n * 11));
        if (l.tag === "FAIL") { setFailed(true); return; }
        await new Promise((r) => setTimeout(r, 120));    // pacing only; results are already real
      }
      connect(); setPct(100); setDone(true);
      const wait = Math.max(0, 2200 - (performance.now() - t0));   // keep the animation readable, never longer than needed
      setTimeout(() => run.current === id && setPhase("main"), wait);
    })();
  };
  useEffect(() => { start(); return () => { run.current++; }; }, []);                       // eslint-disable-line
  useEffect(() => { const k = (e: KeyboardEvent) => { if (done && (e.key === " " || e.key === "Enter")) setPhase("main"); }; addEventListener("keydown", k); return () => removeEventListener("keydown", k); }, [done, setPhase]);

  return (
    <div className="boot" data-tone="blue" onClick={() => done && setPhase("main")}>
      <div className="scanline" /><div className="scan-v" />
      <div className="hud-frame"><i className="c tl" /><i className="c tr" /><i className="c bl" /><i className="c br" /></div>
      <div className="boot-left">
        <h1 className="logo">J.A.R.V.I.S <span>V6.5</span></h1>
        <div className="sub">ASSISTANT CORE · LOCAL CONTROL LAYER</div>
        <ul className="boot-log">
          {lines.map((l, i) => <li key={i} className={`t-${l.tag}`}><b>{l.label}</b><em>[{l.tag}]</em><span>{l.text}</span></li>)}
          {!done && !failed && <li className="cursor">▌</li>}
        </ul>
        <div className="bar"><div style={{ width: `${pct}%` }} /></div>
        <div className="bar-label">{failed ? "INITIALISATION HALTED" : done ? "CORE ONLINE — click or press Space" : "INITIALISING…"}</div>
        {failed && <button className="btn" onClick={start}>RETRY</button>}
      </div>
      <div className="boot-right"><Radar size={720} /><div className="ring-label">SYSTEM RADAR</div></div>
    </div>
  );
}
