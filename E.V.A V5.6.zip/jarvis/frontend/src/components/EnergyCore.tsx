import { Canvas, useFrame } from "@react-three/fiber";
import { useEffect, useMemo, useRef, useState, type MutableRefObject } from "react";
import * as THREE from "three";
import { useStore } from "../store";
import { live } from "../lib/live";
import type { AState } from "../lib/types";

/* ───────────── state → look. Blue/cyan = standby (reference 1); orange/gold = active (reference 2). ───────────── */
interface Look { a: string; b: string; speed: number; energy: number; turb: number; spikes: number; ring: number; pulse: number }
const LOOK: Record<AState, Look> = {
  STARTING:    { a: "#1a8cff", b: "#6ee7ff", speed: 0.6, energy: 0.35, turb: 0.2, spikes: 0.1, ring: 0.5, pulse: 0.5 },
  STANDBY:     { a: "#1469ff", b: "#3fdcff", speed: 0.30, energy: 0.28, turb: 0.12, spikes: 0.08, ring: 0.3, pulse: 0.35 },
  LISTENING:   { a: "#ff7410", b: "#ffd058", speed: 1.15, energy: 0.8, turb: 0.45, spikes: 0.6, ring: 1.1, pulse: 2.2 },
  PROCESSING:  { a: "#ff8c14", b: "#ffe9a3", speed: 2.1, energy: 0.95, turb: 1.0, spikes: 0.9, ring: 2.0, pulse: 3.0 },
  EXECUTING:   { a: "#ffa01c", b: "#fff6d6", speed: 2.6, energy: 1.0, turb: 0.8, spikes: 1.0, ring: 2.8, pulse: 1.6 },
  SPEAKING:    { a: "#ff7410", b: "#ffd058", speed: 1.0, energy: 0.6, turb: 0.35, spikes: 0.5, ring: 1.0, pulse: 0.0 },
  INTERRUPTED: { a: "#ff3b2f", b: "#ffb09e", speed: 0.5, energy: 0.5, turb: 0.9, spikes: 0.4, ring: 0.4, pulse: 4.0 },
  ERROR:       { a: "#e01535", b: "#ff7a8a", speed: 0.4, energy: 0.45, turb: 0.7, spikes: 0.25, ring: 0.3, pulse: 1.0 },
};

const QUALITY = {
  low:    { sphere: 2200, orbits: 5, per: 110, spikes: 10, detail: 1, dpr: 1.25 },
  medium: { sphere: 4200, orbits: 7, per: 200, spikes: 16, detail: 2, dpr: 2 },
  high:   { sphere: 7500, orbits: 9, per: 320, spikes: 22, detail: 2, dpr: 2.5 },
};

/** Smoothed, mutable animation state shared by all parts of the scene (no React re-renders). */
interface Rig { a: THREE.Color; b: THREE.Color; speed: number; energy: number; turb: number; spikes: number; ring: number; t: number; pulse: number; amp: number }
const newRig = (): Rig => ({ a: new THREE.Color(LOOK.STARTING.a), b: new THREE.Color(LOOK.STARTING.b), speed: 0.5, energy: 0.3, turb: 0.2, spikes: 0.1, ring: 0.5, t: 0, pulse: 0, amp: 0 });

function Driver({ rig }: { rig: MutableRefObject<Rig> }) {
  const tgtA = useRef(new THREE.Color()), tgtB = useRef(new THREE.Color());
  useFrame((_, dt0) => {
    const dt = Math.min(dt0, 0.033), r = rig.current, st = useStore.getState().state, L = LOOK[st];
    const k = 1 - Math.exp(-dt * 3.2);                       // ~0.8 s smooth colour/behaviour transitions
    tgtA.current.set(L.a); tgtB.current.set(L.b);
    r.a.lerp(tgtA.current, k); r.b.lerp(tgtB.current, k);
    r.speed += (L.speed - r.speed) * k; r.energy += (L.energy - r.energy) * k; r.turb += (L.turb - r.turb) * k;
    r.spikes += (L.spikes - r.spikes) * k; r.ring += (L.ring - r.ring) * k;
    r.t += dt * r.speed;
    // amplitude: REAL speech output level when speaking, REAL microphone level when listening, slow breathing otherwise
    const breathe = 0.5 + 0.5 * Math.sin(performance.now() / 1000 * L.pulse * Math.PI);
    const sig = st === "SPEAKING" ? live.level : st === "LISTENING" ? Math.max(live.micLevel * 0.9, useStore.getState().vad ? 0.35 : 0) : 0;
    r.amp += (sig - r.amp) * (1 - Math.exp(-dt * 14));
    r.pulse = st === "SPEAKING" ? r.amp : Math.max(r.amp, breathe * 0.35 * L.energy);
  });
  return null;
}

/* ───────────── shaders ───────────── */
const SPHERE_VS = /* glsl */ `
uniform float uT, uTurb, uAmp, uSize, uPx; attribute float aSeed; attribute float aSize; varying float vSeed; varying float vGlow; varying float vDepth;
void main(){
  vec3 p = position; float s = aSeed * 40.0;
  float w = sin(uT*1.7 + s) * 0.04 * uTurb + sin(uT*3.1 + s*1.7) * 0.025 * uTurb;
  float speech = uAmp * (0.14 * sin(uT*9.0 + s*2.0) + 0.1);
  p *= 1.0 + w + speech * (0.5 + aSeed);
  float ang = uT * 0.18; float c = cos(ang), sn = sin(ang);
  p = vec3(c*p.x + sn*p.z, p.y, -sn*p.x + c*p.z);
  vec4 mv = modelViewMatrix * vec4(p, 1.0);
  gl_Position = projectionMatrix * mv;
  gl_PointSize = max(1.3 * uPx, aSize * uSize * uPx * (1.0 + uAmp*0.8) * (13.0 / -mv.z));
  vSeed = aSeed; vGlow = 0.6 + 0.4 * sin(uT*2.0 + s); vDepth = clamp(0.5 + 0.5 * p.z, 0.0, 1.0);
}`;
const POINT_FS = /* glsl */ `
uniform vec3 uA, uB; uniform float uBright; varying float vSeed; varying float vGlow; varying float vDepth;
void main(){
  float d = length(gl_PointCoord - 0.5); if (d > 0.5) discard;
  float edge = smoothstep(0.5, 0.42, d);                 // hard, clean edge (no blur halo)
  float core = smoothstep(0.28, 0.0, d);                 // tiny bright pin-point centre
  vec3 col = mix(uA, uB, fract(vSeed * 7.31)) * (0.55 + 0.35 * vGlow) * (0.45 + 0.55 * vDepth) + vec3(1.0) * core * 0.12;
  gl_FragColor = vec4(min(col * uBright, vec3(1.0)), edge * (0.7 + 0.3 * vDepth));
}`;
const ORBIT_VS = /* glsl */ `
uniform float uT, uRate, uRa, uRb, uAmp, uSize, uPx; attribute float aPhase; attribute float aTrail; attribute float aJit; varying float vTrail;
void main(){
  float ang = aPhase + uT * uRate - aTrail * 0.55;
  vec3 p = vec3(cos(ang) * uRa, sin(ang*2.0) * 0.04 * aJit, sin(ang) * uRb);
  p += vec3(aJit, aJit*0.7, -aJit) * (0.025 + uAmp * 0.08);
  vec4 mv = modelViewMatrix * vec4(p, 1.0); gl_Position = projectionMatrix * mv;
  gl_PointSize = max(1.2 * uPx, uSize * uPx * (1.0 - aTrail * 0.7) * (1.0 + uAmp * 0.8) * (9.5 / -mv.z)); vTrail = aTrail;
}`;
const ORBIT_FS = /* glsl */ `
uniform vec3 uA, uB; uniform float uBright; varying float vTrail;
void main(){ float d = length(gl_PointCoord - 0.5); if (d > 0.5) discard;
  float a = smoothstep(0.5, 0.38, d) * (1.0 - vTrail * 0.8); gl_FragColor = vec4(mix(uB, uA, vTrail) * uBright + vec3(1.0) * smoothstep(0.25, 0.0, d) * 0.15 * (1.0 - vTrail), a * 0.9); }`;
const GLOW_VS = `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`;
const GLOW_FS = /* glsl */ `
uniform vec3 uA, uB; uniform float uI; varying vec2 vUv;
void main(){ float d = length(vUv - 0.5) * 2.0; float core = exp(-d*d*70.0); float halo = exp(-d*6.5) * 0.16;
  vec3 col = mix(uA, uB, core) * halo + vec3(1.0, 0.97, 0.9) * core * 0.9; float a = clamp((core + halo) * uI, 0.0, 1.0);
  gl_FragColor = vec4(col * uI, a); }`;

const additive = { transparent: true, depthWrite: false, blending: THREE.AdditiveBlending } as const;

function ParticleSphere({ rig, count }: { rig: MutableRefObject<Rig>; count: number }) {
  const mat = useRef<THREE.ShaderMaterial>(null!), pts = useRef<THREE.Points>(null!);
  const geo = useMemo(() => {
    const g = new THREE.BufferGeometry(), pos = new Float32Array(count * 3), seed = new Float32Array(count), size = new Float32Array(count);
    const ga = Math.PI * (3 - Math.sqrt(5));
    for (let i = 0; i < count; i++) {
      const y = 1 - (i / (count - 1)) * 2, r = Math.sqrt(1 - y * y), th = ga * i;
      const shell = i % 5 === 0 ? 0.55 + Math.random() * 0.4 : 0.97 + Math.random() * 0.07;   // dense surface + inner fill
      pos.set([Math.cos(th) * r * shell, y * shell, Math.sin(th) * r * shell], i * 3);
      seed[i] = Math.random(); size[i] = 0.5 + Math.random() * 1.6;
    }
    g.setAttribute("position", new THREE.BufferAttribute(pos, 3)); g.setAttribute("aSeed", new THREE.BufferAttribute(seed, 1)); g.setAttribute("aSize", new THREE.BufferAttribute(size, 1));
    return g;
  }, [count]);
  const uniforms = useMemo(() => ({ uT: { value: 0 }, uTurb: { value: 0 }, uAmp: { value: 0 }, uSize: { value: 1 }, uPx: { value: 1 }, uA: { value: new THREE.Color() }, uB: { value: new THREE.Color() }, uBright: { value: 1 } }), []);
  useFrame(({ gl }) => {
    const r = rig.current, u = mat.current.uniforms; u.uPx.value = gl.getPixelRatio();
    u.uT.value = r.t; u.uTurb.value = r.turb; u.uAmp.value = r.pulse; u.uA.value.copy(r.a); u.uB.value.copy(r.b); u.uBright.value = 0.85 + r.energy * 0.3;
    pts.current.rotation.x = Math.sin(r.t * 0.3) * 0.15;
  });
  return <points ref={pts} geometry={geo}><shaderMaterial ref={mat} vertexShader={SPHERE_VS} fragmentShader={POINT_FS} uniforms={uniforms} transparent depthWrite={false} blending={THREE.NormalBlending} /></points>;
}

function Wire({ rig, detail }: { rig: MutableRefObject<Rig>; detail: number }) {
  const ref = useRef<THREE.LineSegments>(null!);
  const geo = useMemo(() => new THREE.WireframeGeometry(new THREE.IcosahedronGeometry(1.0, detail)), [detail]);
  useFrame(() => {
    const r = rig.current, m = ref.current.material as THREE.LineBasicMaterial;
    m.color.copy(r.b); m.opacity = 0.16 + r.energy * 0.2 + r.pulse * 0.2;
    ref.current.rotation.y = r.t * 0.25; ref.current.rotation.x = r.t * 0.11;
    ref.current.scale.setScalar(1 + r.pulse * 0.05);
  });
  return <lineSegments ref={ref} geometry={geo}><lineBasicMaterial transparent opacity={0.2} depthWrite={false} blending={THREE.AdditiveBlending} /></lineSegments>;
}

function OrbitRing({ rig, idx, per, total }: { rig: MutableRefObject<Rig>; idx: number; per: number; total: number }) {
  const g = useRef<THREE.Group>(null!), mat = useRef<THREE.ShaderMaterial>(null!), line = useRef<THREE.LineLoop>(null!);
  const p = useMemo(() => {
    const f = idx / total;
    return { ra: 1.25 + f * 0.95 + Math.random() * 0.15, rb: 1.05 + f * 0.8 + Math.random() * 0.2, rate: (0.35 + Math.random() * 0.55) * (idx % 2 ? 1 : -1),
      tilt: new THREE.Euler(Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI), drift: new THREE.Vector3(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).multiplyScalar(0.12) };
  }, [idx, total]);
  const geo = useMemo(() => {
    const n = per, ph = new Float32Array(n), tr = new Float32Array(n), jt = new Float32Array(n), pos = new Float32Array(n * 3);
    const comets = Math.max(6, Math.floor(n / 14));
    for (let i = 0; i < n; i++) { const c = i % comets; ph[i] = (c / comets) * Math.PI * 2 + Math.random() * 0.2; tr[i] = Math.floor(i / comets) / Math.ceil(n / comets); jt[i] = (Math.random() - 0.5) * 2; }
    const g2 = new THREE.BufferGeometry(); g2.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    g2.setAttribute("aPhase", new THREE.BufferAttribute(ph, 1)); g2.setAttribute("aTrail", new THREE.BufferAttribute(tr, 1)); g2.setAttribute("aJit", new THREE.BufferAttribute(jt, 1));
    g2.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 10); return g2;
  }, [per]);
  const path = useMemo(() => { const a = new Float32Array(97 * 3); for (let i = 0; i < 97; i++) { const t = (i / 96) * Math.PI * 2; a.set([Math.cos(t) * p.ra, 0, Math.sin(t) * p.rb], i * 3); } const g2 = new THREE.BufferGeometry(); g2.setAttribute("position", new THREE.BufferAttribute(a, 3)); return g2; }, [p]);
  const uniforms = useMemo(() => ({ uT: { value: 0 }, uRate: { value: p.rate }, uRa: { value: p.ra }, uRb: { value: p.rb }, uAmp: { value: 0 }, uSize: { value: 2.2 }, uPx: { value: 1 }, uA: { value: new THREE.Color() }, uB: { value: new THREE.Color() }, uBright: { value: 1 } }), [p]);
  useFrame(({ gl }) => {
    const r = rig.current, u = mat.current.uniforms; u.uPx.value = gl.getPixelRatio();
    u.uT.value = r.t * (0.6 + r.ring); u.uAmp.value = r.pulse; u.uA.value.copy(r.a); u.uB.value.copy(r.b); u.uBright.value = 0.75 + r.energy * 0.35;
    g.current.rotation.x += p.drift.x * 0.01 * r.ring; g.current.rotation.y += p.drift.y * 0.01 * r.ring; g.current.rotation.z += p.drift.z * 0.01 * r.ring;
    const lm = line.current.material as THREE.LineBasicMaterial; lm.color.copy(r.a); lm.opacity = 0.07 + r.energy * 0.1;
  });
  return (
    <group ref={g} rotation={p.tilt}>
      <lineLoop ref={line} geometry={path}><lineBasicMaterial transparent opacity={0.1} depthWrite={false} blending={THREE.AdditiveBlending} /></lineLoop>
      <points geometry={geo} frustumCulled={false}><shaderMaterial ref={mat} vertexShader={ORBIT_VS} fragmentShader={ORBIT_FS} uniforms={uniforms} {...additive} /></points>
    </group>
  );
}

function Spikes({ rig, n }: { rig: MutableRefObject<Rig>; n: number }) {
  const ref = useRef<THREE.LineSegments>(null!);
  const dirs = useMemo(() => Array.from({ length: n }, () => ({ d: new THREE.Vector3().randomDirection(), len: 0.6 + Math.random() * 1.4, ph: Math.random() * 6.28, sp: 0.6 + Math.random() * 1.8 })), [n]);
  const geo = useMemo(() => { const g = new THREE.BufferGeometry(); g.setAttribute("position", new THREE.BufferAttribute(new Float32Array(n * 6), 3)); g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 6); return g; }, [n]);
  useFrame(() => {
    const r = rig.current, a = geo.attributes.position.array as Float32Array;
    dirs.forEach((s, i) => {
      const live2 = r.spikes * (0.35 + 0.65 * Math.abs(Math.sin(r.t * s.sp + s.ph))) + r.pulse * 0.9;
      const L = 0.95 + s.len * live2 * 1.15, o = 0.9;
      a.set([s.d.x * o, s.d.y * o, s.d.z * o, s.d.x * L, s.d.y * L, s.d.z * L], i * 6);
    });
    geo.attributes.position.needsUpdate = true;
    const m = ref.current.material as THREE.LineBasicMaterial; m.color.copy(r.a).lerp(r.b, 0.3); m.opacity = Math.min(0.75, 0.08 + r.spikes * 0.4 + r.pulse * 0.3);
    ref.current.rotation.y = r.t * 0.12;
  });
  return <lineSegments ref={ref} geometry={geo}><lineBasicMaterial transparent opacity={0.4} depthWrite={false} blending={THREE.AdditiveBlending} /></lineSegments>;
}

function Glow({ rig }: { rig: MutableRefObject<Rig> }) {
  const m = useRef<THREE.ShaderMaterial>(null!), mesh = useRef<THREE.Mesh>(null!);
  const uniforms = useMemo(() => ({ uA: { value: new THREE.Color() }, uB: { value: new THREE.Color() }, uI: { value: 1 } }), []);
  useFrame(() => { const r = rig.current; m.current.uniforms.uA.value.copy(r.a); m.current.uniforms.uB.value.copy(r.b);
    m.current.uniforms.uI.value = 0.35 + r.energy * 0.3 + r.pulse * 0.4; mesh.current.scale.setScalar(1.7 + r.pulse * 0.6 + r.energy * 0.2); });
  return <mesh ref={mesh}><planeGeometry args={[2, 2]} /><shaderMaterial ref={m} vertexShader={GLOW_VS} fragmentShader={GLOW_FS} uniforms={uniforms} {...additive} /></mesh>;
}

/** Your hand steers the orb: it turns toward the hand, grows when the palm opens and contracts on a fist. */
function Scene({ q, density }: { q: keyof typeof QUALITY; density: number }) {
  const rig = useRef<Rig>(newRig()), Q = QUALITY[q], group = useRef<THREE.Group>(null!), steer = useRef<THREE.Group>(null!);
  const ctl = useRef({ ry: 0, rx: 0, s: 1 });
  useFrame((_, dt0) => {
    const dt = Math.min(dt0, 0.033), h = live.hand, c = ctl.current, on = h.present && performance.now() - h.t < 500, k = 1 - Math.exp(-dt * 7);
    c.ry += ((on ? (h.x - 0.5) * 2.4 : 0) - c.ry) * k; c.rx += ((on ? (h.y - 0.5) * 1.6 : 0) - c.rx) * k;
    c.s += ((on ? (h.open ? 1.14 : h.fist ? 0.86 : 1.0) : 1) - c.s) * k;
    steer.current.rotation.set(c.rx, c.ry, 0); steer.current.scale.setScalar(c.s);
    group.current.rotation.y += dt * 0.05 * rig.current.speed;
  });
  return (
    <>
      <Driver rig={rig} />
      <group ref={steer}>
      <Glow rig={rig} />
      <group ref={group}>
        <ParticleSphere rig={rig} count={Math.round(Q.sphere * density)} />
        <Wire rig={rig} detail={Q.detail} />
        {Array.from({ length: Q.orbits }, (_, i) => <OrbitRing key={i} rig={rig} idx={i} total={Q.orbits} per={Math.round(Q.per * density)} />)}
        <Spikes rig={rig} n={Q.spikes} />
      </group>
      </group>
    </>
  );
}

export function EnergyCore() {
  const quality = useStore((s) => s.settings?.interface.quality ?? "medium"), density = useStore((s) => s.settings?.interface.particle_density ?? 1);
  const [hidden, setHidden] = useState(document.hidden);
  useEffect(() => { const f = () => setHidden(document.hidden); document.addEventListener("visibilitychange", f); return () => document.removeEventListener("visibilitychange", f); }, []);
  return (
    <Canvas className="core-canvas" dpr={[1, QUALITY[quality].dpr]} camera={{ position: [0, 0, 7.2], fov: 40 }} frameloop={hidden ? "never" : "always"}
      gl={{ antialias: true, alpha: true, powerPreference: "high-performance", stencil: false, depth: false }} flat>
      <Scene q={quality} density={density} />
    </Canvas>
  );
}
