import { useState } from "react";
import { api } from "../lib/api";
import { useStore } from "../store";

/** First-run: the ONLY thing needed is an OpenRouter API key. No model id, no provider choice. */
export function KeyPrompt() {
  const dismiss = () => useStore.setState({ keyPromptDismissed: true });
  const [key, setKey] = useState(""), [busy, setBusy] = useState(false), [msg, setMsg] = useState("");
  const save = async () => {
    setBusy(true); setMsg("");
    try {
      await api("/api/secrets", "PUT", { OPENROUTER_API_KEY: key.trim() });
      const r = await api("/api/providers/test", "POST", { provider: "openrouter" });
      if (r.ok) { setMsg("✓ Connected"); setTimeout(dismiss, 600); } else setMsg(`✗ ${r.error}`);
    } catch (e: any) { setMsg(`✗ ${Array.isArray(e.detail) ? e.detail.map((d: any) => d.msg ?? d).join(", ") : e.message}`); }
    finally { setBusy(false); }
  };
  return (
    <div className="modal-bg">
      <div className="modal keyprompt">
        <h3>CONNECT J.A.R.V.I.S</h3>
        <p className="prompt">Paste your <b>OpenRouter API key</b>. That is all — no model needs to be chosen.</p>
        <input type="password" autoFocus autoComplete="off" value={key} placeholder="sk-or-v1-…" onChange={(e) => setKey(e.target.value)} onKeyDown={(e) => e.key === "Enter" && key.trim() && save()} />
        <div className="row"><button className="btn ok" disabled={busy || key.trim().length < 10} onClick={save}>{busy ? "CHECKING…" : "SAVE & CONNECT"}</button><button className="btn" onClick={dismiss}>LATER</button></div>
        <div className={msg.startsWith("✓") ? "okt" : "badt"}>{msg}</div>
        <div className="dim small">Stored only on this PC (backend .env). Get a key at openrouter.ai/keys</div>
      </div>
    </div>
  );
}
