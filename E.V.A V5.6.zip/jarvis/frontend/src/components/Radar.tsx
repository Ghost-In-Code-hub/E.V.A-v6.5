/** Rotating radar: concentric rings, tick marks, sweep wedge, orbiting blips and a glowing centre (blue HUD reference). */
export function Radar({ size = 360 }: { size?: number }) {
  const ticks = Array.from({ length: 72 }, (_, i) => i);
  const blips = [{ r: 118, a: 40, s: 14 }, { r: 86, a: 200, s: 22 }, { r: 140, a: 300, s: 30 }, { r: 60, a: 120, s: 18 }];
  return (
    <svg className="radar" viewBox="-180 -180 360 360" width={size} height={size} aria-hidden>
      <defs>
        <radialGradient id="rcore"><stop offset="0" stopColor="#fff" /><stop offset=".25" stopColor="var(--c2)" /><stop offset="1" stopColor="transparent" /></radialGradient>
        <linearGradient id="sweep" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stopColor="var(--c1)" stopOpacity="0" /><stop offset="1" stopColor="var(--c1)" stopOpacity=".55" /></linearGradient>
        <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse"><path d="M20 0H0V20" fill="none" stroke="var(--c1)" strokeOpacity=".12" /></pattern>
        <clipPath id="disc"><circle r="150" /></clipPath>
      </defs>
      <rect x="-150" y="-150" width="300" height="300" fill="url(#grid)" clipPath="url(#disc)" />
      {[150, 120, 90, 60, 30].map((r) => <circle key={r} r={r} fill="none" stroke="var(--c1)" strokeOpacity={r === 150 ? 0.9 : 0.35} strokeWidth={r === 150 ? 1.5 : 1} />)}
      <path d="M-170 0H170M0 -170V170" stroke="var(--c1)" strokeOpacity=".35" />
      <g className="spin-slow">{ticks.map((i) => <line key={i} x1="0" y1={-158} x2="0" y2={i % 6 === 0 ? -170 : -164} stroke="var(--c1)" strokeOpacity={i % 6 === 0 ? 0.95 : 0.5} transform={`rotate(${i * 5})`} />)}</g>
      <g className="spin-rev"><circle r="136" fill="none" stroke="var(--c2)" strokeWidth="3" strokeDasharray="38 24 8 24" strokeOpacity=".8" /></g>
      <g className="spin-mid"><circle r="104" fill="none" stroke="var(--c1)" strokeWidth="2" strokeDasharray="70 30" strokeOpacity=".7" /></g>
      <g className="sweep"><path d="M0 0 L150 0 A150 150 0 0 0 128 -78 Z" fill="url(#sweep)" /></g>
      {blips.map((b, i) => <g key={i} className="orbit" style={{ animationDuration: `${b.s}s` }}><circle cx={b.r} cy="0" r="3.5" fill="var(--c2)" transform={`rotate(${b.a})`} className="blink" /></g>)}
      <circle r="46" fill="url(#rcore)" opacity=".9" className="pulse" /><circle r="9" fill="#fff" />
    </svg>
  );
}
