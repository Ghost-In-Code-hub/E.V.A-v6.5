import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { IS_ISLAND, useStore } from "../store";
import { live } from "../lib/live";

/** JARVIS Dynamic Island. Every state below is derived from REAL backend events, microphone level and speech amplitude. */
export type Mode = "standby" | "listening" | "processing" | "speaking" | "control" | "done" | "error" | "interrupted";

const SIZE: Record<Mode, [number, number]> = {
  standby: [128, 34], listening: [310, 54], processing: [262, 50], speaking: [310, 54],
  control: [390, 54], done: [266, 50], error: [430, 54], interrupted: [236, 50],
};
const EXPANDED: [number, number] = [468, 232];
const HOVER: [number, number] = [190, 40];
const TONE: Record<Mode, string> = { standby: "#2cc4ff", listening: "#ff9a1f", processing: "#ffb02e", speaking: "#ff9a1f", control: "#ffb02e", done: "#3dffa0", error: "#ff3b4f", interrupted: "#ff6a3d" };

function useMode(): { mode: Mode; label: string; sub: string } {
  const { state, toolLabel, detail, error, doneAt, doneLabel, vad } = useStore();
  const [doneOn, setDoneOn] = useState(false), [intHold, setIntHold] = useState(false);
  useEffect(() => { if (Date.now() - doneAt < 1500 && doneAt) { setDoneOn(true); const t = setTimeout(() => setDoneOn(false), 1800); return () => clearTimeout(t); } }, [doneAt]);
  useEffect(() => { if (state === "INTERRUPTED") { setIntHold(true); const t = setTimeout(() => setIntHold(false), 1300); return () => clearTimeout(t); } }, [state]);
  const active = ["LISTENING", "PROCESSING", "EXECUTING", "SPEAKING"].includes(state);
  if (state === "ERROR") return { mode: "error", label: "ERROR", sub: (error ?? detail ?? "Something went wrong").slice(0, 46) };
  if (state === "LISTENING") return { mode: "listening", label: "LISTENING", sub: vad ? "voice detected" : "speak now" };
  if (state === "EXECUTING" && toolLabel) return { mode: "control", label: toolLabel, sub: "computer control" };
  if (state === "PROCESSING" || state === "EXECUTING") return { mode: "processing", label: state === "EXECUTING" ? "WORKING" : detail.toLowerCase().includes("transcrib") ? "TRANSCRIBING" : "THINKING", sub: "processing" };
  if (state === "SPEAKING") return { mode: "speaking", label: "SPEAKING", sub: "" };
  if (!active && (state === "INTERRUPTED" || intHold)) return { mode: "interrupted", label: "STOPPED", sub: "returning to standby" };
  if (doneOn) return { mode: "done", label: doneLabel, sub: "" };
  return { mode: "standby", label: "STANDBY", sub: "" };
}

function Bars({ source, n = 18 }: { source: "mic" | "speech"; n?: number }) {
  const refs = useRef<(HTMLSpanElement | null)[]>([]), reduce = useReducedMotion();
  useEffect(() => {
    let raf = 0; const t0 = performance.now();
    const tick = () => {
      const t = (performance.now() - t0) / 1000;
      const base = source === "mic" ? Math.max(live.micLevel, useStore.getState().vad ? 0.3 : 0.04) : live.level;
      const [b0, b1, b2] = live.bands;
      for (let i = 0; i < n; i++) {
        const f = i / (n - 1), band = source === "speech" ? (f < 0.33 ? b0 : f < 0.66 ? b1 : b2) * 2.0 : 0;
        const wob = 0.55 + 0.45 * Math.sin(t * 9 + i * 1.7) * Math.cos(t * 5.3 + i * 0.9);
        const v = Math.min(1, base * wob * 1.7 + band * 0.7 + 0.07);
        const el = refs.current[i]; if (el) el.style.transform = `scaleY(${reduce ? Math.min(1, base + 0.1) : v})`;
      }
      raf = requestAnimationFrame(tick);
    };
    tick(); return () => cancelAnimationFrame(raf);
  }, [source, n, reduce]);
  return <div className="bars">{Array.from({ length: n }, (_, i) => <span key={i} ref={(el) => { refs.current[i] = el; }} />)}</div>;
}

const Icon = {
  mic: <svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M12 15a3 3 0 0 0 3-3V6a3 3 0 1 0-6 0v6a3 3 0 0 0 3 3Zm5-3a5 5 0 0 1-10 0H5a7 7 0 0 0 6 6.92V22h2v-3.08A7 7 0 0 0 19 12h-2Z" /></svg>,
  stop: <svg viewBox="0 0 24 24" width="16" height="16"><rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor" /></svg>,
  pc: <svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M3 4h18a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1h-7v2h3v2H7v-2h3v-2H3a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1Zm1 2v9h16V6H4Z" /></svg>,
  check: <svg viewBox="0 0 24 24" width="20" height="20"><path fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" d="m5 13 4 4L19 7" /></svg>,
  warn: <svg viewBox="0 0 24 24" width="20" height="20"><path fill="currentColor" d="M12 2 1 21h22L12 2Zm1 14h-2v-2h2v2Zm0-4h-2V8h2v4Z" /></svg>,
  open: <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M14 3h7v7h-2V6.4l-8.3 8.3-1.4-1.4L17.6 5H14V3ZM5 5h6v2H5v12h12v-6h2v8H3V5h2Z" /></svg>,
};

function Lead({ mode }: { mode: Mode }) {
  switch (mode) {
    case "listening": return <span className="i-ic">{Icon.mic}</span>;
    case "processing": return <svg className="spin" viewBox="0 0 24 24" width="22" height="22"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeOpacity=".25" strokeWidth="3" /><path d="M12 3a9 9 0 0 1 9 9" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" /></svg>;
    case "control": return <span className="i-ic">{Icon.pc}</span>;
    case "done": return <span className="i-ic">{Icon.check}</span>;
    case "error": return <span className="i-ic">{Icon.warn}</span>;
    case "interrupted": return <span className="i-ic">{Icon.stop}</span>;
    default: return <span className="i-dot" />;
  }
}

export function Island({ overlay = false }: { overlay?: boolean }) {
  const { mode, label, sub } = useMode();
  const { micOn, camOn, state, taskLabel, toolLine, log, usage } = useStore();
  const [open, setOpen] = useState(false), [hover, setHover] = useState(false);
  const reduce = useReducedMotion(), leaveT = useRef<number>();
  const color = TONE[mode];

  const wake = () => { const s = useStore.getState(); if (IS_ISLAND) window.jarvis?.islandAction("wake"); else void s.wake(); };
  const micClick = () => {
    const s = useStore.getState();
    if (s.state === "LISTENING") s.stop(false);               // deactivate listening
    else wake();                                              // activate listening (turns the mic on first if needed)
  };
  const micToggle = () => { if (IS_ISLAND) window.jarvis?.islandAction("mic"); else void useStore.getState().toggleMic(); };

  useEffect(() => { if (mode === "error") setOpen(false); }, [mode]);
  const enter = () => { clearTimeout(leaveT.current); setHover(true); if (IS_ISLAND) window.jarvis?.islandHover(true); };
  const leave = () => { setHover(false); if (IS_ISLAND) window.jarvis?.islandHover(false); leaveT.current = window.setTimeout(() => setOpen(false), 5000); };

  const compactHover = mode === "standby" && hover && !open;
  const [w, h] = open ? EXPANDED : compactHover ? HOVER : SIZE[mode];
  const showControls = open || compactHover || (mode !== "standby" && mode !== "done");
  const tools = log.filter((l) => l.kind === "tool").slice(-4);

  return (
    <div className={`island-wrap ${overlay ? "overlay" : ""}`}>
      <motion.div
        className={`island m-${mode}`} data-open={open} style={{ ["--ic" as any]: color }}
        initial={{ width: SIZE.standby[0], height: SIZE.standby[1], opacity: 0, y: -14 }}
        animate={{ width: w, height: h, opacity: 1, y: 0, borderRadius: open ? 26 : h / 2 }}
        transition={reduce ? { duration: 0 } : { type: "spring", stiffness: 420, damping: 34, mass: 0.8 }}
        onClick={() => setOpen((o) => !o)} onMouseEnter={enter} onMouseLeave={leave} role="status" aria-live="polite" aria-label={`Jarvis ${label}`}>
        <div className="i-row">
          <AnimatePresence mode="popLayout" initial={false}>
            <motion.div key={mode} className="i-lead" initial={{ opacity: 0, scale: 0.6 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.6 }} transition={{ duration: 0.16 }}>
              <Lead mode={mode} />
            </motion.div>
          </AnimatePresence>

          {(mode !== "standby" || open || compactHover) && (
            <div className="i-text">
              <AnimatePresence mode="wait" initial={false}>
                <motion.div key={label} className="i-label" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.14 }}>{label}</motion.div>
              </AnimatePresence>
              {sub && <div className="i-sub">{sub}</div>}
            </div>
          )}

          {(mode === "listening" || mode === "speaking") && <Bars source={mode === "listening" ? "mic" : "speech"} />}

          {showControls && (
            <div className="i-ctl" onClick={(e) => e.stopPropagation()}>
              <button className={`i-btn ${mode === "listening" ? "on" : ""}`} onClick={micClick} title={state === "LISTENING" ? "Stop listening" : "Listen"} aria-label="Microphone">{Icon.mic}</button>
              <button className="i-btn stop" onClick={() => useStore.getState().stop(false)} title="Stop" aria-label="Stop">{Icon.stop}</button>
            </div>
          )}
        </div>

        <AnimatePresence>
          {open && (
            <motion.div className="i-panel" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.18, delay: 0.08 }} onClick={(e) => e.stopPropagation()}>
              <div className="i-kv"><span>TASK</span><b>{taskLabel || (state === "STANDBY" ? "Idle" : label)}</b></div>
              <div className="i-kv"><span>STEP</span><b>{toolLine || sub || "—"}</b></div>
              <div className="i-kv"><span>STATE</span><b>{state}</b></div>
              <div className="i-kv"><span>LIVE</span><b>{micOn ? "MIC ● " : "MIC ○ "}{camOn ? "CAM ●" : "CAM ○"} · {usage.i + usage.o} tok</b></div>
              <div className="i-log">{tools.length ? tools.map((t) => <div key={t.id} className={t.ok === false ? "bad" : ""}>{t.text.slice(0, 64)}</div>) : <div className="dim">No actions yet</div>}</div>
              <div className="i-actions">
                <button onClick={micToggle}>{micOn ? "MIC OFF" : "MIC ON"}</button>
                {IS_ISLAND && <button onClick={() => window.jarvis?.islandAction("open")}>{Icon.open} OPEN JARVIS</button>}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
