import { create } from "zustand";
import type { AState, Caps, Confirmation, LogLine, Settings } from "./lib/types";
import { api, getToken, wsUrl } from "./lib/api";
import { player } from "./audio/player";
import { mic } from "./audio/mic";
import { describeTool } from "./lib/tools";

export const IS_ISLAND = new URLSearchParams(location.search).has("island");   // the overlay window renders only the island

type Phase = "boot" | "main";
interface Toast { id: number; text: string; kind: "up" | "down" | "info" }

interface Store {
  phase: Phase; state: AState; detail: string; connected: boolean; caps: Caps | null; settings: Settings | null;
  userText: string; response: string; spoken: string; taskLabel: string; toolLine: string; log: LogLine[];
  confirmations: Confirmation[]; toast: Toast | null; micOn: boolean; camOn: boolean; vad: boolean; usage: { i: number; o: number };
  error: string | null; settingsOpen: boolean; convId: string | null;
  calc: { expr: string; value: string; at: number } | null; toolLabel: string; usedTool: boolean; doneAt: number; doneLabel: string; keyPromptDismissed: boolean;
  setPhase(p: Phase): void; setSettingsOpen(v: boolean): void;
  send(msg: Record<string, unknown>): void; chat(text: string): void; stop(emergency?: boolean): void;
  toggleMic(): Promise<void>; wake(): Promise<void>; confirm(id: string, approved: boolean): void; connect(): void;
  patchSettings(patch: unknown): Promise<string[]>; pushLog(kind: LogLine["kind"], text: string, ok?: boolean): void; clearError(): void;
}

import { live } from "./lib/live";

let ws: WebSocket | null = null, retry = 0, lid = 0, tid = 0;

player.onDrain = () => useStore.getState().send({ type: "speech_finished" });
player.onError = (err) => useStore.getState().send({ type: "speech_finished", error: err });

export const useStore = create<Store>((set, get) => ({
  phase: "boot", state: "STARTING", detail: "", connected: false, caps: null, settings: null,
  userText: "", response: "", spoken: "", taskLabel: "", toolLine: "", log: [], confirmations: [], toast: null,
  micOn: false, camOn: false, vad: false, usage: { i: 0, o: 0 }, error: null, settingsOpen: false, convId: null,
  calc: null, toolLabel: "", usedTool: false, doneAt: 0, doneLabel: "DONE", keyPromptDismissed: false,

  setPhase: (phase) => set({ phase }),
  setSettingsOpen: (settingsOpen) => set({ settingsOpen }),
  clearError: () => set({ error: null }),
  pushLog: (kind, text, ok) => set((s) => ({ log: [...s.log.slice(-79), { id: ++lid, ts: Date.now(), kind, text, ok }] })),
  send: (msg) => { if (ws?.readyState === WebSocket.OPEN) ws.send(JSON.stringify(msg)); },
  chat: (text) => { set({ userText: text, response: "", spoken: "", usedTool: false, calc: null }); get().send({ type: "chat", text, conversation_id: get().convId }); },
  stop: (emergency = false) => { if (!IS_ISLAND) player.stop(); get().send({ type: emergency ? "emergency_stop" : "stop" }); },
  confirm: (id, approved) => { get().send({ type: "confirm", id, approved }); set((s) => ({ confirmations: s.confirmations.filter((c) => c.id !== id) })); },

  toggleMic: async () => {
    if (get().micOn) { mic.stop(); get().send({ type: "mic", enabled: false }); set({ micOn: false }); return; }
    try {
      await mic.start(get().settings?.voice.mic_device || "", (l) => { live.micLevel = l; });
      get().send({ type: "mic", enabled: true }); set({ micOn: true });
    } catch (e: any) {
      // quiet: a missing/blocked microphone must never put a red banner on screen (typing and the TALK button still work)
      get().pushLog("info", e?.name === "NotAllowedError" ? "Microphone blocked by Windows privacy settings." : e?.name === "NotFoundError" ? "No microphone found: using typed commands." : `Microphone unavailable: ${e?.message ?? e}`, false);
    }
  },
  wake: async () => { if (!get().micOn) await get().toggleMic(); if (get().micOn) { player.stop(); get().send({ type: "wake", source: "button" }); } },

  patchSettings: async (patch) => {
    try { const r = await api<{ settings: Settings }>("/api/settings", "PUT", { patch }); set({ settings: r.settings }); return []; }
    catch (e: any) { return Array.isArray(e?.detail) ? e.detail.map(String) : [String(e?.message ?? e)]; }
  },

  connect: () => {
    (async () => {
      const token = await getToken();
      ws = new WebSocket(wsUrl("/ws", token));
      ws.onopen = () => { retry = 0; set({ connected: true }); };
      ws.onclose = () => { set({ connected: false, state: get().state === "STARTING" ? "STARTING" : "ERROR", detail: "Backend connection lost; reconnecting…" }); if (!IS_ISLAND) { mic.stop(); set({ micOn: false }); }
        setTimeout(() => get().connect(), Math.min(5000, 400 * 2 ** retry++)); };
      ws.onmessage = (m) => handle(JSON.parse(m.data), set, get);
    })();
  },
}));

function toast(set: any, text: string, kind: Toast["kind"]) { const id = ++tid; set({ toast: { id, text, kind } }); setTimeout(() => { if (useStore.getState().toast?.id === id) set({ toast: null }); }, 1600); }

function handle(e: any, set: any, get: () => Store) {
  const log = get().pushLog;
  switch (e.type) {
    case "capabilities": { const { type, seq, ts, ...caps } = e; set({ caps, settings: caps.settings, camOn: caps.gestures.camera_active, micOn: IS_ISLAND ? caps.mic.enabled : get().micOn }); if (!IS_ISLAND) player.setVolume(caps.settings.voice.speech_volume); break; }
    case "state": {
      set({ state: e.state, detail: e.detail ?? "" });
      if (e.state === "PROCESSING" && e.previous === "STANDBY") set({ response: "", usedTool: false });
      if (e.state === "STANDBY" || e.state === "ERROR") set({ toolLine: "", toolLabel: "" });
      if (e.state === "STANDBY" && ["SPEAKING", "PROCESSING", "EXECUTING"].includes(e.previous)) set({ doneAt: Date.now(), doneLabel: get().usedTool ? "TASK COMPLETE" : "DONE" });
      break; }
    case "wake": log("info", `Wake: ${e.source}`); break;
    case "vad": set({ vad: e.speaking }); live.vadAt = performance.now(); break;
    case "transcript_final": set({ userText: e.text, convId: e.conversation_id ?? get().convId }); log("user", e.text); break;
    case "response_delta": set((s: Store) => ({ response: s.response + e.text })); break;
    case "response_final": set({ response: e.text }); log("assistant", e.text.slice(0, 160)); break;
    case "audio": if (IS_ISLAND) break; if (e.data) { player.enqueue(e.data, e.volume); set({ spoken: e.text }); } if (e.last) player.markEnd(); break;
    case "interrupted": if (!IS_ISLAND) player.stop(); log("info", `Interrupted (${e.reason})`); break;
    case "task": set({ taskLabel: e.status === "started" ? e.label : get().taskLabel }); if (e.status !== "started") log("info", `Task ${e.status}${e.error ? ": " + e.error : ""}`, e.status === "finished"); break;
    case "tool_start": set({ toolLine: `${e.name} ${Object.values(e.arguments ?? {}).join(" ").slice(0, 60)}`, toolLabel: describeTool(e.name, e.arguments), usedTool: true }); log("tool", `▶ ${e.name}`); break;
    case "tool_result": set({ toolLine: "", toolLabel: "" }); log("tool", `${e.ok ? "✓" : "✗"} ${e.name}: ${e.summary}`, e.ok); break;
    case "screenshot": log("info", e.note); break;
    case "confirmation_request": set((s: Store) => ({ confirmations: [...s.confirmations, { id: e.id, prompt: e.prompt, details: e.details, timeout_s: e.timeout_s, at: Date.now() }] })); break;
    case "confirmation_resolved": set((s: Store) => ({ confirmations: s.confirmations.filter((c) => c.id !== e.id) })); break;
    case "gesture": toast(set, e.direction === "up" ? "VOLUME UP" : "VOLUME DOWN", e.direction); break;
    case "volume": if (!IS_ISLAND) player.setVolume(e.target === "assistant" ? e.level : player.volume); log("info", `Volume ${e.direction} (${e.target}) → ${Math.round(e.level * 100)}%`); break;
    case "camera": set({ camOn: e.active }); break;
    case "mic": set({ micOn: !!e.enabled }); break;
    case "calc": set({ calc: { expr: e.expression, value: e.value, at: Date.now() } }); break;
    case "usage": set((s: Store) => ({ usage: { i: s.usage.i + e.input_tokens, o: s.usage.o + e.output_tokens } })); break;
    case "error":                       // voice/camera/volume hiccups are logged quietly; they must never block the screen
      if (["tts", "playback", "camera", "volume"].includes(e.kind)) { log("info", e.message, false); break; }
      set({ error: e.message }); log("error", e.message, false); break;
    case "log": log("info", e.message); break;
  }
}
