import { useEffect, useRef, useState } from "react";
import { EnergyCore } from "./components/EnergyCore";
import { Island } from "./components/Island";
import { KeyPrompt } from "./components/KeyPrompt";
import { StartupHUD } from "./components/StartupHUD";
import { OrbHud } from "./components/OrbHud";
import { ResultCard } from "./components/ResultCard";
import { HandPanel } from "./components/HandPanel";
import { setSensitivity, startVision, stopVision } from "./vision/controller";
import { Confirmations, ConversationPanel, LogPanel, SysPanel, TaskPanel } from "./components/Panels";
import { SettingsPanel } from "./components/SettingsPanel";
import { useStore } from "./store";
import { live } from "./lib/live";
import { player } from "./audio/player";

const TONE: Record<string, string> = { STARTING: "blue", STANDBY: "blue", LISTENING: "orange", PROCESSING: "orange", EXECUTING: "orange", SPEAKING: "orange", INTERRUPTED: "red", ERROR: "red" };

function Dot({ on, warn }: { on: boolean; warn?: boolean }) { return <i className={`dot ${on ? "on" : warn ? "warn" : ""}`} />; }

export default function App() {
  const s = useStore();
  const [text, setText] = useState("");
  const tone = TONE[s.state], aiOk = !!s.caps?.ai.configured, autoMic = useRef(false);

  useEffect(() => { s.connect(); window.jarvis?.onEmergencyStop(() => useStore.getState().stop(true));
    window.jarvis?.onIslandAction((a) => { const st = useStore.getState(); if (a === "mic") void st.toggleMic(); else if (a === "wake") void st.wake(); }); }, []);   // eslint-disable-line
  useEffect(() => { document.body.dataset.phase = s.phase; }, [s.phase]);
  useEffect(() => { if (s.phase === "main") window.jarvis?.introDone(!!s.settings?.interface.fullscreen); }, [s.phase]);                                    // eslint-disable-line
  useEffect(() => { if (s.settings) window.jarvis?.setIslandOverlay(s.settings.interface.island_overlay); }, [s.settings?.interface.island_overlay]);       // eslint-disable-line
  useEffect(() => { if (s.settings?.voice.speaker_device !== undefined) player.setSink(s.settings.voice.speaker_device); }, [s.settings?.voice.speaker_device]);
  useEffect(() => { if (s.settings?.interface.skip_startup && s.connected && s.phase === "boot") s.setPhase("main"); }, [s.settings, s.connected, s.phase]);   // eslint-disable-line
  // everything "on" by default: microphone starts automatically (visible MIC LIVE indicator; turn off any time)
  useEffect(() => { if (s.phase === "main" && s.connected && s.settings?.voice.auto_mic && !autoMic.current) { autoMic.current = true; void useStore.getState().toggleMic(); } }, [s.phase, s.connected, s.settings?.voice.auto_mic]);
  // relay real audio levels to the overlay island window while the main window is minimised
  useEffect(() => { const id = setInterval(() => { if (window.jarvis && (live.level > 0.001 || live.micLevel > 0.001)) window.jarvis.sendLevel({ level: live.level, mic: live.micLevel }); }, 40); return () => clearInterval(id); }, []);
  // hand gestures: camera + MediaPipe run inside the app only while enabled; the camera stops the moment you switch it off
  const g = s.settings?.vision;
  useEffect(() => {
    if (s.phase !== "main" || !g) return;
    const st = useStore.getState(), hooks = { send: st.send, log: (t: string) => st.pushLog("info", t, false), setCam: (on: boolean) => useStore.setState({ camOn: on }) };
    if (g.gestures_enabled && g.engine === "browser") void startVision(g.camera_index, g.sensitivity, hooks); else stopVision(hooks);
    return () => stopVision(hooks);
  }, [s.phase, g?.gestures_enabled, g?.engine, g?.camera_index, s.connected]);                   // eslint-disable-line
  useEffect(() => { if (g) setSensitivity(g.sensitivity); }, [g?.sensitivity]);                   // eslint-disable-line
  useEffect(() => { const k = (e: KeyboardEvent) => { if (e.key === "Escape") useStore.getState().stop(false); }; addEventListener("keydown", k); return () => removeEventListener("keydown", k); }, []);

  if (s.phase === "boot") return <div className="app" data-tone="blue"><StartupHUD /></div>;

  const submit = () => { const t = text.trim(); if (t) { s.chat(t); setText(""); } };
  const busy = s.state !== "STANDBY" && s.state !== "STARTING";
  const controlActive = s.state === "EXECUTING";

  return (
    <div className="app main" data-tone={tone} data-state={s.state}>
      <div className="bg-grid" /><div className="scanline slow" />
      <div className="hud-frame"><i className="c tl" /><i className="c tr" /><i className="c bl" /><i className="c br" /></div>

      <header className="top">
        <div className="brand">J.A.R.V.I.S <small>V{s.caps?.version?.slice(0, 3) ?? "6.5"}</small></div>
        <div className="chips">
          <span className="chip"><Dot on={s.connected} /><em>BACKEND</em></span>
          <span className="chip" title={s.caps?.ai.reason}><Dot on={aiOk} warn /><em>AI</em></span>
          <span className={`chip ${s.micOn ? "live" : ""}`}><Dot on={s.micOn} /><em>{s.micOn ? "MIC LIVE" : "MIC OFF"}</em></span>
          <span className={`chip ${s.camOn ? "live" : ""}`}><Dot on={s.camOn} /><em>{s.camOn ? "CAM LIVE" : "CAM OFF"}</em></span>
          <span className={`chip ${controlActive ? "live" : ""}`}><Dot on={controlActive} /><em>{controlActive ? "CONTROLLING PC" : "CONTROL"}</em></span>
        </div>
        <div className="win">
          <button title="Settings" onClick={() => s.setSettingsOpen(true)}>⚙</button>
          <button title="Minimise — the Dynamic Island appears" onClick={() => window.jarvis?.minimize()}>—</button>
          <button title="Maximise / restore" onClick={() => window.jarvis?.toggleMaximize()}>▢</button>
          <button className="x" title="Close" onClick={() => window.jarvis?.close()}>✕</button>
        </div>
      </header>

      <Island />

      <aside className="left"><TaskPanel /><LogPanel /></aside>
      <aside className="right"><ConversationPanel /><HandPanel /><SysPanel /></aside>

      <main className="center">
        <div className="core-wrap"><OrbHud /><EnergyCore /></div>
        <ResultCard />
        <div className="state-tag"><span className="state-pill">{s.state}</span><div className="state-detail">{s.error && s.state === "ERROR" ? s.error : s.detail}</div></div>
        {s.toast && <div key={s.toast.id} className={`toast ${s.toast.kind}`}>{s.toast.text}</div>}
      </main>

      {s.error && s.state !== "ERROR" && <div className="banner" onClick={s.clearError}>{s.error}<span>dismiss</span></div>}

      <footer className="dock">
        <button className={`mic ${s.micOn ? "on" : ""}`} onClick={() => (s.state === "LISTENING" ? s.stop(false) : s.micOn ? s.wake() : s.toggleMic())} onContextMenu={(e) => { e.preventDefault(); s.toggleMic(); }}
          title={s.micOn ? "Click to talk · right-click to turn the microphone off" : "Turn microphone on"}>{s.micOn ? "●" : "🎙"}</button>
        {s.micOn && <button className="btn talk" onClick={() => s.wake()}>TALK</button>}
        <input value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit()} placeholder="Type a command, press TALK, or clap…" maxLength={4000} />
        <button className="btn" onClick={submit} disabled={!text.trim()}>SEND</button>
        <button className={`btn stop ${busy ? "armed" : ""}`} onClick={() => s.stop(false)} title="Stop (Esc)">STOP</button>
        <button className="btn estop" onClick={() => s.stop(true)} title="Emergency stop (Ctrl+Alt+S)">E-STOP</button>
      </footer>

      <Confirmations />
      {!aiOk && s.connected && s.caps && !s.keyPromptDismissed && <KeyPrompt />}
      {s.settingsOpen && <SettingsPanel />}
    </div>
  );
}
