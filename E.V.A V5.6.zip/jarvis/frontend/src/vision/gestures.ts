// Hand-gesture logic (pure TypeScript, no camera needed - fully unit-testable). Port of the backend classifier.
// A volume gesture = an OPEN PALM held open, then moved deliberately UP or DOWN. One sweep = one step.
export type Pt = [number, number];
export type Pose = "none" | "open_palm" | "fist" | "other";

const FINGERS: [number, number][] = [[8, 6], [12, 10], [16, 14], [20, 18]]; // [tip, pip]
const PALM = [0, 5, 9, 13, 17];
const dist = (a: Pt, b: Pt) => Math.hypot(a[0] - b[0], a[1] - b[1]);
const clamp01 = (v: number) => Math.min(1, Math.max(0, v));

export function classifyPose(lm: Pt[] | null): Pose {
  if (!lm || lm.length < 21) return "none";
  const w = lm[0];
  const n = FINGERS.filter(([t, p]) => dist(lm[t], w) > dist(lm[p], w) * 1.12).length;
  return n === 4 ? "open_palm" : n === 0 ? "fist" : "other";
}

export function palmCenter(lm: Pt[]): Pt {
  return [PALM.reduce((s, i) => s + lm[i][0], 0) / PALM.length, PALM.reduce((s, i) => s + lm[i][1], 0) / PALM.length];
}

export interface GestureConfig { sensitivity: number; minOpenS: number; windowS: number; cooldownS: number; steadyS: number; lostS: number }
export const defaultConfig = (): GestureConfig => ({ sensitivity: 0.5, minOpenS: 0.25, windowS: 0.7, cooldownS: 1.0, steadyS: 0.35, lostS: 0.4 });
export const travel = (c: GestureConfig) => 0.26 - 0.16 * clamp01(c.sensitivity);

export class GestureEngine {
  cfg: GestureConfig;
  private hist: [number, number][] = [];
  private openSince: number | null = null;
  private lastFire = -1e9;
  private armed = true;
  private lastSeen = -1e9;
  pose: Pose = "none";

  constructor(cfg?: Partial<GestureConfig>) { this.cfg = { ...defaultConfig(), ...cfg }; }

  /** Feed landmarks (or null = no hand) with a timestamp in seconds. Returns "up" | "down" | null. */
  update(lm: Pt[] | null, t: number): "up" | "down" | null {
    const c = this.cfg, pose = (this.pose = classifyPose(lm));
    if (pose === "none") {
      if (t - this.lastSeen > c.lostS) { this.hist = []; this.openSince = null; this.armed = true; }
      return null;
    }
    this.lastSeen = t;
    if (pose !== "open_palm") { this.hist = []; this.openSince = null; if (pose === "fist") this.armed = true; return null; }
    const y = palmCenter(lm!)[1];
    if (this.openSince === null) this.openSince = t;
    this.hist.push([t, y]);
    while (this.hist.length && t - this.hist[0][0] > c.windowS) this.hist.shift();
    if (!this.armed) {
      const steady = this.hist.filter((h) => t - h[0] <= c.steadyS);
      if (steady.length >= 3 && Math.max(...steady.map((h) => h[1])) - Math.min(...steady.map((h) => h[1])) < 0.02 && t - this.lastFire > c.cooldownS) { this.armed = true; this.hist = []; }
      return null;
    }
    if (t - this.openSince < c.minOpenS || t - this.lastFire < c.cooldownS || this.hist.length < 4) return null;
    const dy = this.hist[this.hist.length - 1][1] - this.hist[0][1];
    const steps = this.hist.slice(1).map((h, i) => h[1] - this.hist[i][1]), sign = dy > 0 ? 1 : -1;
    const smooth = Math.max(...steps.map(Math.abs)) <= 0.5 * Math.abs(dy) && steps.filter((s) => s * sign > 0.004).length >= 3;
    if (Math.abs(dy) >= travel(c) && smooth) { this.lastFire = t; this.armed = false; this.hist = []; return dy > 0 ? "down" : "up"; }
    return null;
  }
}
