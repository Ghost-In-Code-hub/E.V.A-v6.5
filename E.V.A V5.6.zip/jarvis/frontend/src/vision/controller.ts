import { live } from "../lib/live";
import { GestureEngine, classifyPose, palmCenter } from "./gestures";
import { HandTracker } from "./handTracker";

const tracker = new HandTracker(), engine = new GestureEngine();
let starting = false;

export interface VisionHooks { send: (m: Record<string, unknown>) => void; log: (t: string) => void; setCam: (on: boolean) => void }

export function setSensitivity(s: number) { engine.cfg.sensitivity = s; }

export async function startVision(cameraIndex: number, sensitivity: number, h: VisionHooks) {
  if (tracker.running || starting) return;
  starting = true; engine.cfg.sensitivity = sensitivity;
  try {
    await tracker.start(cameraIndex, (lm, t) => {
      const pose = classifyPose(lm), now = performance.now();
      if (lm) { const [x, y] = palmCenter(lm); live.hand = { present: true, x: 1 - x, y, open: pose === "open_palm", fist: pose === "fist", t: now, lm }; }
      else if (now - live.hand.t > 400) live.hand = { ...live.hand, present: false, lm: null };
      const g = engine.update(lm, t);
      if (g) h.send({ type: "gesture", direction: g });             // the BACKEND performs the volume change (system or Jarvis volume)
    });
    h.setCam(true); h.send({ type: "camera", enabled: true });
  } catch (e: any) {
    h.setCam(false); h.send({ type: "camera", enabled: false });
    h.log(e?.name === "NotAllowedError" ? "Camera permission denied: gestures are off." : String(e?.message ?? e));   // quiet: never blocks the UI
  } finally { starting = false; }
}

export function stopVision(h?: VisionHooks) {
  if (!tracker.running && !starting) return;
  tracker.stop(); live.hand = { present: false, x: 0.5, y: 0.5, open: false, fist: false, t: 0, lm: null };
  h?.setCam(false); h?.send({ type: "camera", enabled: false });
}
