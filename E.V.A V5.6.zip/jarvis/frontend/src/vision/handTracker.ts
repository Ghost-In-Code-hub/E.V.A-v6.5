import { FilesetResolver, HandLandmarker } from "@mediapipe/tasks-vision";
import type { Pt } from "./gestures";

/** Webcam hand tracking inside the app (MediaPipe Tasks, WASM, CPU). Frames are processed in memory only: never stored or sent anywhere.
 *  Runs ONLY while gestures are enabled; the camera stops the moment they are switched off. */
export class HandTracker {
  private video = document.createElement("video");
  private stream: MediaStream | null = null;
  private lm: HandLandmarker | null = null;
  private timer: number | null = null;
  private lastTime = -1;

  get running() { return this.stream !== null; }

  async start(deviceIndex: number, onFrame: (lm: Pt[] | null, t: number) => void): Promise<void> {
    this.stop();
    const base = document.baseURI;
    if (!this.lm) {
      let fileset;
      try { fileset = await FilesetResolver.forVisionTasks(new URL("wasm", base).href); }
      catch { throw new Error("Hand-tracking runtime is missing. Run setup.bat (or run.bat rebuild)."); }
      try {
        this.lm = await HandLandmarker.createFromOptions(fileset, {
          baseOptions: { modelAssetPath: new URL("models/hand_landmarker.task", base).href, delegate: "CPU" },
          runningMode: "VIDEO", numHands: 1, minHandDetectionConfidence: 0.6, minHandPresenceConfidence: 0.5, minTrackingConfidence: 0.5,
        });
      } catch { throw new Error("Hand model not found. Connect to the internet and run setup.bat (it downloads an 8 MB model once)."); }
    }
    const cams = (await navigator.mediaDevices.enumerateDevices()).filter((d) => d.kind === "videoinput");
    if (!cams.length) throw new Error("No camera found.");
    const id = cams[Math.min(deviceIndex, cams.length - 1)].deviceId;
    this.stream = await navigator.mediaDevices.getUserMedia({ video: { deviceId: id ? { exact: id } : undefined, width: 640, height: 480, frameRate: 30 }, audio: false });
    this.video.srcObject = this.stream; this.video.muted = true; this.video.playsInline = true; await this.video.play();
    this.stream.getVideoTracks()[0].addEventListener("ended", () => { this.stop(); onFrame(null, performance.now() / 1000); });
    this.timer = window.setInterval(() => {                         // ~15 fps is plenty for volume gestures and keeps CPU low
      const v = this.video;
      if (!this.lm || v.readyState < 2 || v.currentTime === this.lastTime) return;
      this.lastTime = v.currentTime;
      const res = this.lm.detectForVideo(v, performance.now());
      const pts = res.landmarks?.[0];
      onFrame(pts ? pts.map((p) => [p.x, p.y] as Pt) : null, performance.now() / 1000);
    }, 66);
  }

  stop() {
    if (this.timer !== null) clearInterval(this.timer); this.timer = null;
    this.stream?.getTracks().forEach((t) => t.stop()); this.stream = null;
    this.video.srcObject = null;
  }
}
