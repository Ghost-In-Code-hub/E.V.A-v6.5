import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Production: the backend serves dist/ on http://127.0.0.1:8765 (same origin as the API).
// Dev (npm run dev): proxy API + websockets to the backend.
export default defineConfig({
  plugins: [react()],
  base: "./",
  server: { port: 5173, host: "127.0.0.1", proxy: { "/api": "http://127.0.0.1:8765", "/ws": { target: "ws://127.0.0.1:8765", ws: true } } },
  build: { outDir: "dist", sourcemap: false, chunkSizeWarningLimit: 1200 },
});
