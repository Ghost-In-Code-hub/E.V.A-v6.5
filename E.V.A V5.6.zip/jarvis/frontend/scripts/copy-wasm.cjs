// Runs before `vite build`: makes MediaPipe's WASM runtime and the build stamp part of the served app (same-origin, offline-capable).
const fs = require("fs"), path = require("path");
const root = path.resolve(__dirname, "..");
const src = path.join(root, "node_modules", "@mediapipe", "tasks-vision", "wasm"), dst = path.join(root, "public", "wasm");
if (fs.existsSync(src)) { fs.mkdirSync(dst, { recursive: true }); for (const f of fs.readdirSync(src)) fs.copyFileSync(path.join(src, f), path.join(dst, f)); console.log("copied MediaPipe wasm ->", dst); }
else console.warn("WARNING: @mediapipe/tasks-vision wasm folder not found; hand tracking will be unavailable");
const v = path.join(root, "..", "VERSION");
if (fs.existsSync(v)) fs.copyFileSync(v, path.join(root, "public", "VERSION"));
